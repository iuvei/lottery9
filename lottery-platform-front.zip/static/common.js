//格式化时间对象
Date.prototype.format =function(format){
	var o = {
	"M+" : this.getMonth()+1, //month
	"d+" : this.getDate(), //day
	"h+" : this.getHours(), //hour
	"m+" : this.getMinutes(), //minute
	"s+" : this.getSeconds(), //second
	"q+" : Math.floor((this.getMonth()+3)/3), //quarter
	"S" : this.getMilliseconds() //millisecond
	}
	if(/(y+)/.test(format)) format=format.replace(RegExp.$1,
	(this.getFullYear()+"").substr(4- RegExp.$1.length));
	for(var k in o)if(new RegExp("("+ k +")").test(format))
	format = format.replace(RegExp.$1,
	RegExp.$1.length==1? o[k] :
	("00"+ o[k]).substr((""+ o[k]).length));
	return format;
};
/*//格式化金额
function money_format(money,po) {
	var digit = po || 3;
	var num = (!money?0/1:money/1).toFixed(digit);
	return num;
};
//判断数组中是否包含该元素
function isNoRepeat(arr , s){
	if($.inArray(s, arr)>-1){
		return false;
	}
		return true;
};
//获得一组随机数
function MathArray(length,minNum,maxNum){
	var shang = [];
	while(true){
		if(shang.length==length){
			break;
		}
		var x=parseInt(Math.random()*(maxNum+1));
		if(isNoRepeat(shang,(x/1))&&(x/1)>=(minNum/1)){
			shang.push(x/1);
		}
	}
	return shang;
};

function Ripple(className){
	this.obj = className;
};

Ripple.prototype.generate = function(){
	var _this = this;
	$("body").on("click",this.obj,function(ev){
		var childObj = $('<div class="ripple_div"></div>');
		$(this).append(childObj);
		var size = $(this).outerWidth()>=$(this).outerHeight()?$(this).outerWidth()<=$(this).outerHeight()*1.5?$(this).outerWidth()*1.5:$(this).outerWidth():$(this).outerHeight()<=$(this).outerWidth()*1.5?$(this).outerHeight()*1.5:$(this).outerHeight();
		var l = ev.pageX-$(this).offset().left;
		var t = ev.pageY-$(this).offset().top;
		childObj.css({
			top:t+"px",
			left:l+"px",
		});
		setTimeout(function(){
			childObj.css({
				transform:"scale("+(size/2)+")",
				opacity:0.2
			});
			setTimeout(function(){
				childObj.css({
					opacity:0
				});
				setTimeout(function(){
					childObj.remove();
				},200);
			},300);
		},20);

	});
};

var ripple = new Ripple(".ripple");
ripple.generate();

//分页
function tabPages(urls,types,dataList,fn){
    $.ajax({
        url:urls,
        type:types,
        data:dataList,
        success:function(data){
           if(fn)fn(data.result,data.success);
        }
    });
}
//时间
function daysTimeBgn(times){//返回开始时间
    var dd = new Date();
    switch(times){
       case '今天':
           dd.setDate(dd.getDate()+0);
       break;
       case '近三天':
           dd.setDate(dd.getDate()-2);
       break;
       case '本周内':
           dd.setDate(dd.getDate()-6);
       break;
       case '半个月':
           dd.setDate(dd.getDate()-14);
       break;
    }
    switch(times){//判断月份
     case '一个月':
           var y = dd.getFullYear();
           var m = dd.getMonth()+1;//获取当前月份的日期
           var d = "01";
       break;
       case '半年':
         if(dd.getMonth()>4){
         var y = dd.getFullYear();
         var m = dd.getMonth()-4;//获取当前月份的日期
         } else {
         var y = dd.getFullYear()-1;
         var m = dd.getMonth()+12-4;//获取当前月份的日期
         }
         var d = "01";
       break;
       case '一年':
         var y = dd.getFullYear()-1;
         var m = dd.getMonth()+1;//获取当前月份的日期
         var d = dd.getDate();
       break;
       default:
         var y = dd.getFullYear();
         var m = dd.getMonth()+1;//获取当前月份的日期
         var d = dd.getDate();
       break;
    }
    if(m<10){
    	m = "0"+m;
    }
    return y+"-"+m+"-"+d;
}*/

