/*
 //配置内容key及value
 网站标题: WEB_TITLE
 网站logo: LOGO_NAME
 客服电话: CUSTOM_NUM
 客服邮箱: CUSTOM_EMAIL
 客服网址: CUSTOM_ADRESS
 版权提示: COPYRIGHT
 底部提示: FOOTTIP
 底部logo隐藏参数: FOOTLOGOSHOW
 轮播图文件夹路径: CAROUSEL_PATH
 导航-彩票游戏: LOTTERY_TICKET
 导航-KG彩票: KG_LOTTERY_TICKET
 导航-真人娱乐: LIVE_ENTERTAINMENT
 导航-电子游艺: TV_GAME
 导航-体育投注: SPORTS_BET
 平台：PLATFORMNAME
 在线客服链接：SERVIERONLINE
 注册链接地址:REGISTER_ADDR
 手机下载:APP_DOWNLOAD
 */

var configObj = {
  //正式环境使用
  PCNew: {
    WEB_TITLE: "8号彩票",
    LOGO_NAME: "static/assets/logo.png",
    CUSTOM_NUM: "#",
    CUSTOM_EMAIL: "#",
    CUSTOM_ADRESS: "#",
    COPYRIGHT: "Copyright©2017 8号彩票 版权所有 All Right Reserved",
    FOOTTIP: "8号彩票郑重提示：彩票有风险，投注需谨慎，未满18周岁的青少年请自觉离开",
    FOOTLOGOSHOW: true,
    CAROUSEL_PATH: "static/assets/carousel/",
    LOTTERY_TICKET: "官方玩法",
    KG_LOTTERY_TICKET: "信用玩法",
    LIVE_ENTERTAINMENT: "真人娱乐",
    TV_GAME: "电子游艺",
    SPORTS_BET: "体育投注",
    PLATFORMNAME: "8号彩票",
    SERVIERONLINE: "#",
    REGISTER_ADDR: "#",
    APP_DOWNLOAD: "#"
  }
}
