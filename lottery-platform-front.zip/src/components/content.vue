<template>
  <div>
    <div v-if="isProduction">
      <span>登录失效....</span>
    </div>
    <template v-else>
      <table>
        <tr>
          <td>账号</td>
          <td><input v-model="account"/></td>
        </tr>
        <tr>
          <td>密码</td>
          <td><input v-model="password"/></td>
        </tr>
        <tr>
          <td colspan="2">
            <button type="button" @click="handleLogin">登录</button>
          </td>
        </tr>
      </table>
    </template>
  </div>
</template>
<script type="text/javascript">
  export default {
    data () {
      return {
        isProduction: process.env.NODE_ENV === 'production',
        account: '',
        password: ''
      }
    },
    created (){

    },
    methods: {
      handleLogin(){
        const _this = this, loginInfo = {userAccount: _this.account, userPassword: _this.password};
        _this.$parent.loadMask = true;
        _this.$store.dispatch('LoginByAccount', loginInfo).then(() => {
          _this.getNavMenuList();
        }).catch(err => {
          _this.$parent.loadMask = false;
          _this.notOnline = false;
          if (err && err.errorInformation) {
            _this.tips = true;
            _this.tipMsg = err.errorInformation.errCode;
            _this.$message.error(_this.tipMsg);
          } else if (err) {
            _this.$message.error(err);
          }
        });
      },
      getNavMenuList: function () {
        const _this = this;
        _this.$store.dispatch('LoadingMenus').then(result => {
          _this.$parent.loadMask = false;
          const {children, typeId, typeCode} = result[0];
          _this.$router.push({
            name: 'lotteryKgList',
            params: {
              typeId: typeId,
              typeCode: typeCode,
              gameId: children[0].gameId,
              gameCode: children[0].gameCode,
              gameName: children[0].gameName
            }
          })
        }).catch(err => {
          _this.$parent.loadMask = false;
          _this.$message.error('获取彩票列表失败...');
        });
      }
    }
  }
</script>
