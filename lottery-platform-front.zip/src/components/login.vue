<template>
  <div>跳转中,请稍后...</div>
</template>
<script>
  import {setToken, setResource} from  '../utils/auth'
  export default {
    name: 'Login',
    data () {
      return {}
    },
    methods: {
      validation: function (option) {
        const {token, resource} = option;
        this.getAccountInfoByToken(token, resource);
      },
      getAccountInfoByToken: function (token, resource) {
        console.log(`【system】:getAccountInfoByToken...`);
        this.$store.dispatch('LoadInfoByToken', token).then(() => {
          setToken(token);
          setResource(resource);
          this.getLotteryMenus();
        }).catch(err => {
          this.$message.error('非法令牌！');
        });
      },
      getLotteryMenus: function () {
        this.$store.dispatch('LoadingMenus').then(result => {
          if (result && result.length > 0) {
            if (result[0].children && result[0].children.length > 0) {
              const {children, typeId, typeCode} = result[0];
              const {gameId, gameCode, gameName} = children[0];
              console.log(`【system】:validation success!begin redirect page,params:typeId:${typeId},typeCode:${typeCode},gameId:${gameId},gameCode:${gameCode},gameName:${gameName}...`);
              this.$router.push({
                name: 'lotteryKgList',
                params: {typeId: typeId,typeCode: typeCode,gameId: gameId,gameCode: gameCode,gameName: gameName}
              })
            } else {
              this.$message.error('该账户尚未配置彩票玩法');
            }
          } else {
            this.$message.error('该账户尚未配置彩票系列');
          }
        }).catch(err => {
          this.$message.error(err);
        });
      }
    },
    beforeRouteEnter(to, from, next){
      if (!from.path)  return false;
      next(vm => {
        console.log(`【system】:login...`);
        vm.validation(to.params)
      });
    },
  }
</script>
