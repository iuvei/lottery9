<template>
  <div class="left-nav-bar">
    <aside class="fl">
      <div class="portrait-cnt">
        <div class="portrait-bg">
          <img src="../../../../../static/assets/commons/logo.png" alt="">
        </div>
        <p class="user-name" :title="account">{{account | filterAccount}}</p>
        <p class="user-balance">余额：
          <count-to class="card-panel-num user-balance" :startVal="0" :endVal="balance" :duration="1000" :decimals="2"></count-to>
          <span class="refresh" :class="{transR:referBtn}" @click="onReferClick" title="刷新余额"></span></p>
        <router-link class="bet-record" :to='{name:"betRecord"}'>投注记录</router-link>
        <!--<a class="bet-record" href="">投注记录</a>-->
      </div>
      <div style="background: #2c2c32">
        <el-tabs v-model="activeName">
          <el-tab-pane label="信用玩法" name="first">
            <div style="background: #000">
              <el-menu class="el-menu-vertical-demo" unique-opened ref="menu" collapse-transition>
                <el-submenu v-for="(group,x) in kgMenusList" :index="`${x}`" :key="x">
                  <template slot="title"><span class="lottery-list-icon"></span>{{group.gameTypeName}}</template>
                  <el-menu-item-group>
                    <el-menu-item style="background: #32323a;color: #87919a" :index="`${x}-${y}`" :class="{active:item.gameCode == activeGameCode}"
                                  v-for="(item,y) in group.children" @click="onClickRouter(item,y)" :key="`${x}-${y}`">
                      {{item.gameName}}
                    </el-menu-item>
                  </el-menu-item-group>
                </el-submenu>
              </el-menu>
            </div>
          </el-tab-pane>
          <el-tab-pane label="官方玩法" name="second">
            <div>
              <span>敬请期待</span>
            </div>
          </el-tab-pane>
        </el-tabs>
      </div>
    </aside>
  </div>
</template>
<script>
  import {isDouble} from '../../../../utils/index';
  import CountTo from 'vue-count-to'
  export default{
    components: {CountTo},
    name: 'LeftNavBar',
    props: {
      kgMenusList: {
        type: Array,
        default: function () {
          return []
        }
      },
      account: {
        type: String
      },
      balance: {
        type: Number
      },
      groupCode: {
        type: String
      },
      gameCode: {
        type: String
      }
    },
    data(){
      return {
        activeName: 'first',
        activeIndex: 0,
        defaultOpeneds:{
          type: Array,
        },
        //刷新状态是否激活
        referBtn: false,
        activeGameCode:''
      }
    },
    watch: {
      'balance'(val) {
        const _this = this;
        if (isDouble(val) && val < 1) {
          setTimeout(function () {
            _this.$message('余额不足请及时充值');
          }, 3000);
        }
      },
      gameCode(val){
        this.activeGameCode = this.gameCode;
        this.$refs.menu.openMenu(this.lotteryPlaysLists.getIndexLotteryPlaysList(this.gameCode)+'');
      }
    },
    filters: {
      filterAccount(val){
        if (val && val.length > 10) {
          return `${val.substr(0, 10)}...`;
        }
        return val
      }
    },
    methods: {
      onReferClick: function () {
        const _this = this;
        _this.referBtn = true;
        _this.$emit('referBalance');
        setTimeout(function () {
          _this.referBtn = false;
        }, 300)
      },
      onClickRouter: function (item, newIndex) {
        const {typeId, typeCode, gameId, gameCode, gameName} = item;
        this.$emit('pageNum', newIndex, this.activeIndex)
        this.activeIndex = newIndex;
        this.activeGameCode = item.gameCode;
        this.$router.push({
          name: "lotteryKgList", params: {
            typeId: typeId,
            typeCode: typeCode,
            gameId: gameId,
            gameCode: gameCode,
            gameName: gameName
          }
        })
      }
    }
  }
</script>
<style lang="less">
  .left-nav-bar {
    .portrait-cnt {
      /*width:190px;*/
      /*height:196px;*/
      /*padding: 20px 25px 15px;*/
      text-align: center;
      font-size: 16px;
      background: url("../../../../../static/assets/head-portrait-bg.png") #4f4f56 no-repeat center;
      /*background-size: contain;*/
      border-top-left-radius: 5px;
      padding: 10px 0 20px;
    }

    .user-name {
      color: #fff;
      padding: 10px 0;
    }

    .user-balance {
      color: #20a0ff;
      overflow: hidden;
      height: 30px;
      /*display: block;*/
    }

    .bet-record {
      margin-top: 10px;
      display: inline-block;
      padding: 5px 10px;
      border: 1px solid #98a4ae;
      -webkit-border-radius: 20px;
      -moz-border-radius: 20px;
      border-radius: 20px;
    }

    .el-tabs__item.is-active {
      color: #fff;
      background: #20a0ff;
    }

    .el-tabs__item:hover {
      color: #fff;
      cursor: pointer;
    }

    .el-tabs__header {
      border-bottom: 1px solid #45454d;
      margin: 0;
    }

    .kg_content aside ul > li:hover, .kg_content aside ul > li.active {
      background: #d1dbe5;
    }

    .el-menu-item-group .el-menu-item:last-child {
      border-bottom: none;
    }

    .el-menu-item-group__title {
      display: none;
    }

    .el-submenu__title {
      background: #32323a;
      color: #87919a;
    }

    .el-submenu__title:hover {
      background: #4a4a4a;
    }

    .el-menu-item:hover {
      color: #00a0f0 !important;
    }

    .el-menu-item.active {
      color: #00a0f0 !important;
    }

    .bet-record:hover {
      color: #00a0f0 !important;
      border-color: #00a0f0;
    }

    .el-submenu .el-menu-item {
      min-width: inherit;
      padding: 0 30px;
      text-align: center;
    }

    .lottery-list-icon {
      display: inline-block;
      width: 25px;
      height: 18px;
      background: url("../../../../../static/assets/lottery-list-icon.png") no-repeat center;
      vertical-align: middle;
      margin-right: 10px;
    }
    .portrait-bg {
      width: 75px;
      height: 75px;
      background: #fff;
      -webkit-border-radius: 50%;
      -moz-border-radius: 50%;
      border-radius: 50%;
      text-align: center;
      margin: 0 auto;
      img {
        border: 0;
        vertical-align: middle;
        position: relative;
        height: 65px;
        width: 65px;
        top: 7px;
        left: -3px;
      }
    }
    .refresh {
      bottom: -3px;
    }
  }
</style>
