<template>
  <div class="ranking" @keyup="contentKeyUpFun">
    <div class="clearfix mt0">
      <div v-for="(item,x) in firstDataList" :key="x">
        <p>{{ item.ruleMasterName }}</p>
        <ul>
          <template v-for="(info,y) in item.gameRuleDetailList">
            <template v-if="info && info.showName">
              <li class="ripple red_ripple"
                  :class="!integrationArr[0+y+x*14]?'':'cur'"
                  :ref="`klsf_single_${getIndex(x,y)}`"
                  :data-x="x" :data-y="y" :data-showCode="info.showCode" :data-showName="info.showName" :key="y">
                <span @click="handleAddIntegration(0+y+x*14)" class="ranking_type beautifyCss03">
                    <span :class="{icon_squares:isNumber(info.showName)}">{{info.showName}}</span>
                    <span> {{info.ruleOdds ||'0.00'}} </span>
                </span>
                <input type="text" v-model="integrationArr[0+y+x*14]">
              </li>
            </template>
            <template v-else>
              <li :key="y"><span class="ranking_type"></span></li>
            </template>
          </template>
        </ul>
      </div>
    </div>
  </div>
</template>
<script>
  import {isNumber} from '../../../../utils/index'
  import setPageData from '../setPageData/index'
  import {mapGetters} from 'vuex'
  export default{
    data () {
      return {
        newArray:[],
        firstDataList: [
          {
            ruleMasterName: '第一球',
            gameRuleDetailList: [{}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}]
          },
          {
            ruleMasterName: '第二球',
            gameRuleDetailList: [{}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}]
          },
          {
            ruleMasterName: '第三球',
            gameRuleDetailList: [{}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}]
          },
          {
            ruleMasterName: '第四球',
            gameRuleDetailList: [{}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}]
          },
          {
            ruleMasterName: '第五球',
            gameRuleDetailList: [{}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}]
          }]
      }
    },
    props: {
      betAmount: {
        type: [String, Number],
        default: 0
      },
      renderData: {
        type: Array,
        default: []
      }
    },
    watch: {
      renderData: function (val) {
        const _this = this;
        if (val && val.length > 0) {
          _this.$nextTick(function () {
            _this.dealData();
            // _this.getFirstData();
          });
        }
      }
    },
    computed: {
      ...mapGetters([
        'integrationArr'
      ])
    },
    mounted() {
      this.dealData();
    },
    methods: {
      init(){
        let key=[],value=[];
        
        for( let m=1 ; m < 6 ; m++ ){
          for( let n=1 ; n < 12 ; n++ ){
            key.push( m + '-' + n);
            value.push(n);
          }
        }
     
        this.newArray = setDataArray(key,value);

        //构建数据对象，传入showCode数组及showName数组，长度须一致
        function setDataArray(key,value){
          let newArray = new Array()
          for(let i = 0 ,len = key.length;i<len;i++){
            newArray[i] = new Object();
            newArray[i].showCode = key[i];
            newArray[i].showName = value[i];
            newArray[i].ruleOdds = '';
          }
          return newArray;
        }
      },
      dealData(){//处理传过来的数据
        const _this = this;
        this.init();
        this.newArray.dealData(this.renderData);

        //处理数组，显示为每几个一组
        this.newArray.forEach(function(item,index){
          if( !(index%11) ){
            _this.firstDataList[index/11].gameRuleDetailList = _this.newArray.slice(index,index+11);//使用该方法赋值，是vue视图渲染不接受常规赋值渲染，因为js特性如此（指针）
          } 
        });
      },
      isNumber,
      getFirstData: function () {
        if (this.renderData.length > 0) {
          for (let x = 0; x < this.renderData.length; x++) {
            if (x < this.firstDataList.length) {
              const {ruleMasterName, gameRuleDetailList} = this.renderData[x];
              this.renderData[x].ruleMasterName = this.firstDataList[x].ruleMasterName = ruleMasterName;
              if (!gameRuleDetailList && !gameRuleDetailList instanceof Array) return;
              for (let y = 0; y < gameRuleDetailList.length; y++) {
                if (y < this.firstDataList[x].gameRuleDetailList.length) {
                  this.firstDataList[x].gameRuleDetailList.splice((y + 14) % 14, 1, gameRuleDetailList[y]);
                }
              }
            }
          }
        }
      },
      removeBetByIndex: function (index) {
        this.integrationArr.splice(index, 1, undefined);
        this.onBetClick();
      },
      getBetList: function () {
        const _this = this;
        let arr = [];
        for (let i = 0; i < _this.integrationArr.length; i++) {
          const amount = _this.integrationArr[i];
          if (amount !== undefined && amount !== '') {
            const target = _this.$refs[`klsf_single_${i}`];
            if (target) {
              let showName;
              const renderDataItem = _this.renderData.filter((item,index)=>{
                if( item.showCode == target[0].getAttribute('data-showCode') ){
                  showName = target[0].getAttribute('data-showName');
                  return true;
                }
                 return false;
              })[0];
              
              if(renderDataItem){
                const  {odds,showCode,typeName} = renderDataItem;
                arr.push({
                  title: typeName,
                  ruleName: showName,
                  showCode:showCode,
                  odds: odds,
                  amount: amount,
                  index: i
                });
              }
            }
          }
        }
        return arr;
      },
      getIndex: function (i, n) {
        return (n + i * 14);
      },
      handleAddIntegration: function (index) {
        this.integrationArr.splice(index, 1, this.integrationArr[index] ? undefined : this.betAmount);
        this.onBetClick();
      },
      contentKeyUpFun: function () {
        this.validationBetAmount();
        this.onBetClick();
      },
      onBetClick: function () {
        this.$emit('onBetClick');
      },
      validationBetAmount: function () {
        for (let i = 0; i < this.integrationArr.length; i++) {
          let singleChip = this.integrationArr[i];
          if (singleChip !== undefined && (!isNumber(singleChip) || singleChip * 1 === 0)) {
            this.integrationArr.splice(i, 1, undefined);
          }
        }
      }
    }
  }
</script>
