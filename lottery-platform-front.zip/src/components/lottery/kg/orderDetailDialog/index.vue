<template>
  <div class="lay_box" @click="onClose" @click.stop>
    <div class="bet_con lottery_con" @click.stop>
      <a class="close" @click="onClose"></a>
      <h2>
        {{betDetail.gameName}}
        <span class="oranget">{{ betDetail.lotteryGameNum }}</span>期
        <span v-if="!betDetail.withDrawn">开奖号码</span>
      </h2>
      <div class="lotNumber">
        <ul class="cf"
            :class="{three:betDetail.curLotNumber.length==3,ten:betDetail.curLotNumber.length==10,twenty:betDetail.curLotNumber.length==20,seven:betDetail.curLotNumber.length==7}"
            v-if="betDetail.isDraw">
          <li v-for="item in betDetail.curLotNumber">{{ item }}</li>
        </ul>
        <div class="blue countdown" v-if="betDetail.isNotDraw">未开奖</div>
        <div class="be_drawn countdown" v-if="betDetail.withDrawn">已{{ betDetail.orderStatus }}</div>
      </div>
      <div class="bet_detail">
        <ul>
          <li>
            <span>订单号</span><span>{{ betDetail.billSeqNo }}</span>
          </li>
          <li>
            <span>玩法</span><span>{{betDetail.countName}}</span>
          </li>
          <li>
            <span>奖金赔率</span><span><i v-amount="betDetail.odds"></i></span>
          </li>
          <li>
            <span>投注内容</span><span class="bet_detail_con">{{ betDetail.ruleDetailName }}</span>
          </li>
          <li>
            <span>投注总额</span><span><i v-amount="betDetail.betAmount"></i>元</span>
          </li>
          <li v-if="betDetail.isDraw">
            <span>中奖注数</span><span>{{betDetail.billSeqWin}}</span>
          </li>
          <!--<li>
            <span>返点金额</span><span><i v-amount="betDetail.rebateAmount"></i>({{ betDetail.rebatePoint }}%)</span>
          </li>-->
          <li v-if="betDetail.isDraw"><span>中奖金额</span><span v-amount="betDetail.gameNetBetAmount"></span></li>
        </ul>
        <div class="profit_loss">
          <div class="lossParms" v-if="betDetail.isDraw">
            <span>实际盈亏</span><span class="red" v-if="betDetail.gameNetBetAmount>0">+<i
              v-amount="betDetail.gameNetBetAmount-betDetail.betAmount"></i>元</span><span class="blue" v-else>-<i
            v-amount="betDetail.betAmount"></i>元</span>
          </div>
          <!-- div class="withdrawal" v-if="!betDetail.isDraw && !betDetail.withDrawn && gameId != 34"><a class="a_btn bluet" @click="betWidthDraw(betDetail.billSeqNo)">撤单</a></div -->
        </div>
      </div>
    </div>
  </div>
</template>
<script>
  export default{
    name: 'OrderDetailDialog',
    props: {
      betDetail: {
        type: Object,
        default: function () {
          return {
            gameName: '',
            countName: '',
            lotteryGameNum: '',
            withDrawn: false,
            billSeqWin:'',
            curLotNumber: [],
            isDraw: false,
            isUnPrize: false,
            unPrizeTxt: '',
            orderStatus: '',
            billSeqNo: '',
            odds: '',
            multiple: '',
            ruleDetailName: '',
            betAmount: '',
            betMultiple: '',
            betCount: '',
            winCount: '',
            rebateAmount: '',
            rebatePoint: '',
            winAmount: '',
            actualProfit: '',
            gameNetBetAmount: ''
          }
        }
      }
    },
    data () {
      return {
        showDialog: true
      }
    },
    methods: {
      onClose: function () {
        this.$emit('onClose')
      }
    }
  }
</script>
