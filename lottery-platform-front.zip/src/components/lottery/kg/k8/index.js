import k8SingleCode from './integrationPan.vue'
import k8TwoSidesPan from './twoSidesPan.vue'

export {k8SingleCode , k8TwoSidesPan}
