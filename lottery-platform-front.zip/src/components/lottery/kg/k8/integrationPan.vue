<template>
  <div class="special_code" @keyup="contentKeyUpFun">
    <template v-if="firstDataIsNotNull()">
      <div class="bet_content_data clearfix">
        <p v-for="(_,i) in firstDataList.length" :key="i">
          <span>号</span>
          <span>赔率</span>
          <span>下注</span>
        </p>
        <ul class="clearfix mark_six_ball" v-for="(item,x) in firstDataList" :key="'k8_'+x">
          <template v-for="(info,y) in item">
            <template v-if="info && info.showName">
              <li class="ripple red_ripple"
                  :class="!integrationArr[getIndex(x,y)]?'':'cur'"
                  @click="handleAddIntegration(getIndex(x,y))"
                  :data-btid="info.id"
                  :ref="`k8_code_${getIndex(x,y)}`"
                  :data-x="0" :data-y="getIndex(x,y)"
                  :data-showCode="info.showCode"
                  :data-showName="info.showName"
                  :key="y">
                  <span class="ranking_type">
                    <span class="ball">{{info.showName}}</span>
                    <span>{{info.ruleOdds ||'0.00'}}</span>
                  </span>
                <input type="text" v-model="integrationArr[getIndex(x,y)]">
              </li>
            </template>
            <template v-else>
              <li class="ripple red_ripple" :key="y">
                <span class="ranking_type"></span>
              </li>
            </template>
          </template>
        </ul>
      </div>
    </template>
  </div>
</template>
<script>
  import {isNumber} from '../../../../utils/index'
  import setPageData from '../setPageData/index'
  import {mapGetters} from 'vuex'
  export default{
    name: 'k8-integrationPan',
    props: {
      betAmount: {
        type: [String, Number],
        default: ''
      },
      renderData: {
        type: Array,
        default: function () {
          return []
        }
      }
    },
    watch: {
      renderData: function (val) {
        const _this = this;
        if (val && val.length > 0) {
          _this.$nextTick(function () {
            _this.dealData();
            // _this.parseFirstData();
          });
        }
      }
    },
    data () {
      return {
        newArray:[],
        firstDataList: [
          [{}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}],
          [{}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}],
          [{}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}],
          [{}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}],
          [{}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}]]
      }
    },
    computed: {
      ...mapGetters([
        'integrationArr'
      ])
    },
    created() {
      this.dealData(); 
    },
    methods: {
      dealData(){//处理传过来的数据
        const _this = this;
        let i = 1;
        while ( i < 81 ) {
          this.newArray[i-1] = {
            showCode : 'zm-'+ i,
            showName : i + ''
          }
          i++;
        }

        //处理数组，显示为每几个一组
        this.newArray.dealData(_this.renderData);
        this.newArray.forEach(function(item,index){
          if( !(index%16) ){
            _this.firstDataList.splice(index/16,1,_this.newArray.slice(index,index+16));//使用该方法赋值，是vue视图渲染不接受常规赋值渲染，因为js特性如此（指针）
          }
        });
      },
      firstDataIsNotNull: function () {
        return this.firstDataList && this.firstDataList.length > 0;
      },
      secondDataIsNotNull: function () {
        return this.secondDataList && this.secondDataList.length > 0;
      },
      parseFirstData: function () {
        if (this.renderData.length > 0) {
          const {gameRuleDetailList} = this.renderData[0];
          if (!gameRuleDetailList && !gameRuleDetailList instanceof Array) return;
          let index = 0;
          for (let i = 0; i < gameRuleDetailList.length; i++) {
            if (index < this.firstDataList.length) {
              this.firstDataList[index].splice((i + 16) % 16, 1, gameRuleDetailList[i]);
              if ((i + 1) % 16 === 0) {
                index++;
              }
            }
          }
        }
      },
      handleAddIntegration: function (index) {
        this.integrationArr.splice(index, 1, this.integrationArr[index] ? undefined : this.betAmount);
        this.onBetClick();
      },
      validationBetAmount: function () {
        for (let i = 0; i < this.integrationArr.length; i++) {
          let singleChip = this.integrationArr[i];
          if (singleChip !== undefined && (!isNumber(singleChip) || singleChip * 1 === 0)) {
            this.integrationArr.splice(i, 1, undefined);
          }
        }
      },
      onBetClick: function () {
        this.$emit('onBetClick');
      },
      getIndex: function (x, y) {
        return y + x * 16
      },
      contentKeyUpFun: function () {
        this.validationBetAmount();
        this.onBetClick();
      },
      removeBetByIndex: function (index) {
        this.integrationArr.splice(index, 1, undefined);
        this.onBetClick();
      },
      getBetList: function () {
        const _this = this, arr = [];
        for (let i = 0; i < _this.integrationArr.length; i++) {
          const amount = _this.integrationArr[i];
          if (amount !== undefined && amount !== '') {
            const target = _this.$refs[`k8_code_${i}`];
            if (target) {
              let showName;
              const renderDataItem = _this.renderData.filter((item,index)=>{
                if( item.showCode == target[0].getAttribute('data-showCode') ){
                  showName = target[0].getAttribute('data-showName');
                  return true;
                }
                 return false;
              })[0];
              
              if(renderDataItem){
                const  {odds,showCode,typeName} = renderDataItem;
                arr.push({
                  title: typeName,
                  ruleName: showName,
                  showCode:showCode,
                  odds: odds,
                  amount: amount,
                  index: i
                });
              }
            }
          }
        }
        console.log(arr)
        return arr;
      },
    }
  }
</script>
<style scoped>
.game-play-content .bet_content_data li span > span:last-child{
  font-size: 13px;
}
</style>
