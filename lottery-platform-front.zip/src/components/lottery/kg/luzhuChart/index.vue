<template>
  <div>
    <ul class="game_dl fl" id="dewdrop">
      <li>露珠图</li>
      <li v-for="(_,n) in dewdropDataAll" @click="changeDewdropBall(n)" class="ripple red_ripple"
          :class="{active:curDewdropBall == n}">{{ dewdropNavTitle[n] }}
      </li>
      <li @click="changeDewdropBall(dewdropSumNavIndex)" class="ripple red_ripple"
          :class="{active:curDewdropBall == dewdropSumNavIndex}">
        {{typeCode == 'pk10' ? "冠亚和" : "总和"}}
      </li>
    </ul>
    <div class="center-box_ball fl">
      <div class="left-ball" id="left-ball">
        <div class="tab-tr_red1 ripple red_ripple" :class="{active:changeDewdropRander == 0}"
             @click="changeRander(0)">
          <i class="tab-tr_red2">单</i>
          <i>{{dewdropSingleSum[dewdropSumIndex]}}</i>
          <i class="tab-tr_blue1">双</i>
          <i>{{dewdropEvenSum[dewdropSumIndex]}}</i>
        </div>
        <div class="tab-tr_red1 ripple red_ripple" :class="{active:changeDewdropRander == 1}"
             @click="changeRander(1)">
          <i class="tab-tr_red2">大</i>
          <i>{{dewdropBigSum[dewdropSumIndex]}}</i>
          <i class="tab-tr_blue1">小</i>
          <i>{{dewdropSmallSum[dewdropSumIndex]}}</i>
        </div>
      </div>
      <table class="tab">
        <tr v-for="y in 8" class="tab-tr">
          <td v-for="x in 20">
            <span :class="getDewdropClass(y,x)"
                  @mousemove="showLnAndIssue=getLnAndIssue(y,x,$event)"
                  @mouseout="showLnAndIssue=false">{{getCur(y, x)}}</span>
          </td>
        </tr>
        <div class="dewdropIssue" v-if="showLnAndIssue"
             :style="{ top: showLnAndIssueY + 'px', left: showLnAndIssueX + 'px'}">
          <div>
            开奖号码:<span v-for="num in dewdropNumber" class="dewdropShowNum"> {{num}}</span>
          </div>
          <div>开奖期号: {{dewdropIssue}}</div>
        </div>
      </table>
    </div>
  </div>
</template>
<script>
  export default{
    name: 'luzhu-chart',
    props: {
      gameId: {
        type: [String, Number],
        default: ''
      },
      dewdrop: {
        type: Object,
        default: function () {
          return {};
        }
      },
      typeCode: {
        type: [String, String],
        default: ''
      }
    },
    data () {
      return {
        //露珠图导航颜色
        curDewdropBall: 0,
        dewdropNavTitle: ["第一球", "第二球", "第三球", "第四球", "第五球", "第六球", "第七球", "第八球", "第九球", "第十球"],
        dewdropSumNavIndex: 0,
        changeDewdropRander: 0,
        dewdropSumShowType: 0,
        dewdropSingleSum: [],
        dewdropSumIndex: 0,
        //露珠图期号
        showLnAndIssue: "",
        //露珠图期号移入显示
        showLnAndIssueX: "",
        showLnAndIssueY: "",
        dewdropNumber: [],
        dewdropIssue: '',
        dewdropDataAll: [],
        //露珠图期号和开奖号码
        dewdroplnAndIssue: [],
        //露珠图单种数据中的每条数据
        dewdropData: [],
        dewdropEvenSum: [],
        dewdropBigSum: [],
        dewdropSmallSum: [],
      }
    },
    created(){
    },
    methods: {
      initData: function () {
        let _this = this;
        _this.dewdropSingleSum = _this.dewdrop.single;
        _this.dewdropEvenSum = _this.dewdrop.even;
        _this.dewdropBigSum = _this.dewdrop.big;
        _this.dewdropSmallSum = _this.dewdrop.small;
        _this.dewdropSumNavIndex = _this.dewdrop.big.length - 1;
        //初始化露珠图
        _this.dewdropDataSum = _this.dewdrop.sumSingleOrEven;
        _this.dewdropDataAll = _this.dewdrop.singleOrEven;
        _this.dewdropData = _this.dewdropDataAll[0];
        this.changeDewdropBall(0);
        this.changeTitle();
      },
      // 切换头部名称
      changeTitle: function () {
        let _this = this;
        console.log('_this.typeCode : ' + _this.typeCode);
        if (_this.typeCode == 'ssc') {
          _this.dewdropNavTitle = ["第一球", "第二球", "第三球", "第四球", "第五球"]
        } else if (_this.typeCode == 'pk10') {
          _this.dewdropNavTitle = ["冠军", "亚军", "第三名", "第四名", "第五名", "第六名", "第七名", "第八名", "第九名", "第十名"]
        } else if (_this.typeCode == 'c11x5') {
          _this.dewdropNavTitle = ["第一球", "第二球", "第三球", "第四球", "第五球"]
        }else if (_this.typeCode == 'klsf') {
          _this.dewdropNavTitle = ["第一球", "第二球", "第三球", "第四球", "第五球", "第六球", "第七球", "第八球"]
        }
      },
      //露珠图排列切换（第一球，第二球...）
      changeDewdropBall: function (i) {
        var data = [];
        if (i === this.dewdropSumNavIndex) {
          if (this.dewdropSumShowType === 0) {
            data = this.dewdrop.sumSingleOrEven;
          } else {
            data = this.dewdrop.sumBigOrSmall;
          }
          this.computedDewPosition(data, i);
          this.dewdropSumIndex = i;
          return false;
        }
        if (this.dewdropSumShowType === 0) {
          this.dewdropDataAll = this.dewdrop.singleOrEven;
        } else {
          this.dewdropDataAll = this.dewdrop.bigOrSmall;
        }
        data = this.dewdropDataAll[i];
        this.computedDewPosition(data, i);
        this.dewdropSumIndex = i;
      },
      //获取露珠图号码显示
      getCur: function (y, x) {
        var x = x - 1;
        var y = y - 1;
        var cloumn = 20;
        var row = 8;
        return this.dewdropData[x + y * cloumn] ? this.dewdropData[x + y * cloumn] : "";
      },
      //切换露珠图单双或者大小视图
      changeRander: function (i) {
        if (i === 0) {
          if (this.dewdropSumIndex === this.dewdropSumNavIndex) {
            this.dewdropData = this.dewdrop.sumSingleOrEven;
          } else {
            this.dewdropDataAll = this.dewdrop.singleOrEven;
            this.dewdropData = this.dewdropDataAll[0];
          }
          this.dewdropSumShowType = 0;
        } else {
          if (this.dewdropSumIndex === this.dewdropSumNavIndex) {
            this.dewdropData = this.dewdrop.sumBigOrSmall;
          } else {
            this.dewdropDataAll = this.dewdrop.bigOrSmall;
            this.dewdropData = this.dewdropDataAll[0];
          }
          this.dewdropSumShowType = 1;
        }
        this.changeDewdropBall(this.dewdropSumIndex);
        this.changeDewdropRander = i;
      },
      //设置化露珠图球的背景颜色
      getDewdropClass: function (y, x) {
        var x = x - 1;
        var y = y - 1;
        var cloumn = 20;
        var row = 8;
        if (this.dewdropData[x + y * cloumn] === '大' || this.dewdropData[x + y * cloumn] === '单') {
          return 'tab-tr_red2';
        } else if (this.dewdropData[x + y * cloumn] === '和') {
          return 'tab-tr_green2'
        } else if (this.dewdropData[x + y * cloumn]) {
          return 'tab-tr_blue1';
        } else {
          return '';
        }
      },
      //设置露珠图的期号和号码
      getLnAndIssue: function (y, x, event) {
        if (this.getDewdropClass(y, x) === '') return false;
        this.showLnAndIssueX = event.pageX + 15;
        this.showLnAndIssueY = event.pageY + 10;
        var x = x - 1;
        var y = y - 1;
        var cloumn = 20;
        var row = 8;
        if (this.dewdroplnAndIssue[x + y * cloumn]) {
          this.dewdropNumber = this.dewdroplnAndIssue[x + y * cloumn][0].split(" ");
          this.dewdropIssue = this.dewdroplnAndIssue[x + y * cloumn][1]
          return this.dewdroplnAndIssue[x + y * cloumn] ? this.dewdroplnAndIssue[x + y * cloumn] : 0;
        }
      },
      //露珠图位置计算
      computedDewPosition: function (data, i) {
        var cloumn = 20,
          row = 8,
          result = [],
          pre = 0,
          curX = -1,
          curY = 0,
          nextX = null;
        this.dewdroplnAndIssue = [];
        this.curDewdropBall = i;
        for (var i = 0; i < data.length; i++) {
          var cur = data[i];
          if (cur !== pre) {
            if (nextX !== null) {
              curX = nextX;
              nextX = null;
            }
            curY = 0;
            curX++;
            while (curY < row && result[curX + curY * cloumn] !== undefined) {
              curY++;
            }
            if (curX > cloumn - 1) {
              curX = 0;
              curY++;
              while (curY < row && result[curX + curY * cloumn] !== undefined) {
                curY++;
              }
              if (curY > row - 1) {
              }
            }
          } else {
            curY++;
            if (curY > row - 1) {
              if (nextX === null) {
                nextX = curX;
              }
              curY--;
              curX++;
              if (curX > cloumn - 1 || result[curX + curY * cloumn] !== undefined) {
              }
            }
          }
          result[curX + curY * cloumn] = cur;
          this.dewdroplnAndIssue[curX + curY * cloumn] = this.dewdrop.lnAndIssue[i];
          pre = cur;
        }
        this.dewdropData = result;
      }
    }
  }
</script>
