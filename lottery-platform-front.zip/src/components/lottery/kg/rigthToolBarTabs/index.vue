<template>
  <div class="left-toolbar-tabs" @click.stop>
    <div class="toolbar">
      <!--<div class="cart btn tip_r" v-if="hasBetData" @click="handleParentSubmitBetbtn(1)">
        <span>官方玩法</span>
      </div>
      <div class="cart tip_r" v-else @click="handleParentSubmitBetbtn(2)">
        <span>信用玩法</span>
      </div>-->
      <div class="yjs">
        <div class="yjs-btn" @click="betRecordBy()">
          <div class="icon-js" title="已结算投注记录"></div>
          <p>已结算</p>
          <span class="js-num">{{betRecordsByList.total}}</span>
        </div>
      </div>
      <div class="yjs">
        <div class="wjs-btn" @click="betRecordNot()">
          <div class="icon-js" title="未结算投注记录"></div>
          <p>未结算</p>
          <span class="js-num"
                :class="{js_num_red:betRecordsNotList.total>0}">{{betRecordsNotList.total}}</span>
        </div>
      </div>
      <!--<div class="contact tip_r">
        <a target="_blank">
          <div class="icon-contact"></div>
          <span>联系客服</span>
        </a>
      </div>-->
      <div class="to-top tip_r" @click="backTop()">
        <div class="icon-top"></div>
        <span>返回顶部</span>
      </div>
    </div>
    <div class="bet_record" :class="[{show:betRecordShow},{showBy:betRecordShowBy},{showNot:betRecordShowNot}]">
      <span class="caret-right"></span>
      <div class="jiesuan-list">
        <div class="jiesuan-tab">
          <a :class="{active:betRecordShowBy}" @click="betRecordBy()">已结算（<span>{{betRecordsByList.total}}</span>）</a>
          <a :class="{active:betRecordShowNot}"
             @click="betRecordNot()">未结算（<span>{{betRecordsNotList.total}}</span>）</a>
        </div>
        <div class="tab-content">
          <div v-for="(item,index) in betRecords" :key="index" class="jiesuan-item" @click="handleParentOpenBetDetail(item)">
            <p>{{item.gameName}} - {{item.ruleMasterName}}</p>
            <div class="small-ball-num">
              选号：{{item.ruleDetailName}}
              <small>赔率：{{item.odds}}</small>
            </div>
            <div class="icon-arrow-left"></div>
          </div>
        </div>
      </div>
      <div class="star-chat text-center">
        <router-link :to='{name:"betRecord"}' class="ripple">查看所有投注记录 &gt;&gt;</router-link>
      </div>
    </div>
    <!--<transition name="slide-fade">
      <order-detail-dialog v-if="betDetailDialogIsShow"
                           :betDetail="betRecordDetail"
                           @onClose="betDetailDialogIsShow=false"></order-detail-dialog>
    </transition>-->
  </div>
</template>
<script>
  import {getBetDetail} from '../../../../api/lotteryKg'
  import OrderDetailDialog from "../orderDetailDialog/index";
  export default{
    components: {OrderDetailDialog},
    name: 'RightToolbarTabs',
    props: {
      hasBetData: {
        type: Boolean,
        default: false
      },
      betRecordsByList: {
        type: Object,
        default: function () {
          return {
            list: [],
            total: 0
          }
        }
      },
      betRecordsNotList: {
        type: Object,
        default: function () {
          return {
            list: [],
            total: 0
          }
        }
      }
    },
    data () {
      return {
        betRecords: [],
        betRecordShow: false,
        betRecordShowBy: true,
        betRecordShowNot: false,
        betDetailDialogIsShow: false
      }
    },
    mounted() {
      /*点击页面关闭结算*/
      const _this = this;
      $(document).on('click', function () {
        if (_this.betRecordShow === true) {
          _this.betRecordShow = false;
        }
      })
    },
    methods: {
      betRecordBy: function () {
        this.betRecords = this.betRecordsByList.list;
        if (this.betRecordShow && this.betRecordShowBy) {
          this.betRecordShow = false;
        } else if (this.betRecordShow) {
          this.betRecordShowNot = false;
          this.betRecordShowBy = true;
        } else {
          this.betRecordShow = true;
          this.betRecordShowNot = false;
          this.betRecordShowBy = true;
        }
      },
      betRecordNot: function () {
        this.betRecords = this.betRecordsNotList.list;
        if (this.betRecordShow && this.betRecordShowNot) {
          this.betRecordShow = false;
        } else if (this.betRecordShow) {
          this.betRecordShowBy = false;
          this.betRecordShowNot = true;
        } else {
          this.betRecordShow = true;
          this.betRecordShowBy = false;
          this.betRecordShowNot = true;
        }
      },
      backTop: function () {
        $('body,html').animate({scrollTop: 0}, 500);
      },
      handleParentSubmitBetbtn: function (val) {

      },
      handleParentOpenBetDetail: function (info) {
        info.isDraw = this.betRecordShowBy;
        info.isNotDraw = this.betRecordShowNot;
        info.curLotNumber = this.betRecordShowBy && info.lotteryResult ? info.lotteryResult.split(',') : [];
        info.withDrawn = false;
        this.$emit('onOpen', info);
      }
    }
  }
</script>
