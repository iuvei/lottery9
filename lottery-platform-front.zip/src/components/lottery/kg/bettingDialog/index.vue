<template>
  <transition name="fade" mode="out-in" appear>
    <div class="lottery_tip kg_lottery_tip" v-show="isShow">
      <div class="tip_one">
        <div class="tip_top">
          <p class="detail_title">第<span style="color: #fd7c5c">{{nextIssue}}</span>期&nbsp;{{isChaseNum ? '追号' : '下注'}}明细(请确认注单)
          </p>
          <div>
            <span class="span_title">号码</span>
            <span class="span_title">赔率</span>
            <span class="span_title">金额</span>
            <span class="span_title">操作</span>
          </div>
          <div>
            <ul>
              <li v-for="(item,index) in betDetails" :key="index">{{item.title}} - <i class="red">{{item.ruleName}}</i></li>
            </ul>
            <ul>
              <li v-for="(item,index) in betDetails" :key="index">{{item.odds}}</li>
            </ul>
            <ul>
              <li v-for="(item,index) in betDetails" :key="index">{{item.amount}}</li>
            </ul>
            <ul>
              <li v-for="(item,index) in betDetails" :key="index">
                <i @click="handleDeleteDetail(item.index)" class="deleted">删除</i>
              </li>
            </ul>
          </div>
          <div class="detail_count">
            <div class="detail_chased" v-if="isChaseNum">
              <span>中奖后是否停止追号<i class="red"> {{chaseIsWinStop ? '是' : '否'}} </i></span>
            </div>
            <div class="detail_money">
              <span>{{isChaseNum ? "每期" : "共"}}<i class="red"> {{betTotal}} </i>注 </span>
              <span> <i class="red"> {{amountTotal}} </i>元</span>
            </div>
          </div>
        </div>
        <div class="tip_bottom">
          <div class="time">投注截止:<span>{{gameTime}}</span><span style="margin-left: 25px"><i class="red">注意:</i>投注成功后无法撤单</span>
          </div>
          <div class="btn_con" v-if="dialogBtn==1">
            <a class="btn ripple enter" @click="isShow=false">确定</a>
          </div>
          <div class="btn_con" v-else>
            <a class="btn ripple esc" @click="handleCancelBet">取消</a>
            <a class="btn ripple enter" @click="handSubmitBet">{{isChaseNum ? "确认追号" : "确认投注"}}</a>
          </div>
        </div>
      </div>
    </div>
  </transition>
</template>
<script>
  import {mapGetters} from 'vuex'
  export default{
    name: 'betting-dialog',
    props: {
      nextIssue: {
        type: String,
        default: ''
      },
      gameTime: {
        type: String,
        default: ''
      },
      dialogVisible: {
        type: Boolean,
        default: false
      },
      isChaseNum: {
        type: Boolean,
        default: false
      },
      chaseIsWinStop: {
        type: Boolean,
        default: false
      },
      betDetails: {
        type: Array,
        default: function () {
          return []
        }
      }
    },
    data () {
      return {
        dialogBtn: 2,
        isShow: false,
        loginUrl: ''
      }
    },
    filters: {
      filterTitle(val){
        if (val && val.length > 4) {
          return `${val.substr(0, 4)}...`
        }
        return val
      }
    },
    computed: {
      betTotal(){
        return this.betDetails.length;
      },
      amountTotal(){
        const tempArr = this.betDetails.map(item => item.amount);
        if (tempArr && tempArr.length > 0) {
          return tempArr.reduce((prev, curr, idx, arr) => Number(prev) + Number(curr));
        }
        return 0;
      }
    },
    methods: {
      show: function () {
        this.isShow = true;
      },
      close: function () {
        this.isShow = false;
      },
      handleDeleteDetail: function (index) {
        this.$emit('handleRemoveBet', index);
      },
      handleCancelBet: function () {
        this.isShow = false;
      },
      handSubmitBet: function () {  //确认投注
        this.$emit('handleSubmitBet', this.amountTotal);
      }
    }
  }
</script>
