<template>
  <div class="ripple red_ripple">
    <p>{{lotteryName}}</p>
    <p>{{drawEndTime}}</p>
  </div>
</template>
<script>
  export default{
    name: 'count-down-timer',
    props: {
      isActivite: {type: Boolean, default: false},
      lotteryName: {type: String, default: '--'}
    },
    data () {
      return {
        intervalId: -1,
        currPeriod: 0,
        betEndSecond: 0,
        drawEndSecond: 0,
        betEndTime: "加载中",
        drawEndTime: '加载中'
      }
    },
    methods: {
      stop: function (msg) {
        this.drawEndTime = msg;
        clearInterval(this.intervalId);
        this.intervalId = -1;
      },
      isRunning: function () {
        return this.intervalId !== -1;
      },
      setPeriod: function (currPeriod) {
        this.currPeriod = currPeriod;
      },
      setSecond: function (nextLotteryTime, drawTime, isStopSell) {
        if (isStopSell) {
          this.betEndSecond = nextLotteryTime;
          this.drawEndSecond = drawTime;
        } else {
          this.betEndSecond = 0;
          this.drawEndSecond = 0;
          this.betEndTime = '已停售';
          this.drawEndTime = '已停售';
          this._isNotice();
          if (this.isActivite) {
            this.$emit('onStopSells', true);
          }
        }
      },
      start: function () {
        const _this = this;
        if (!_this.isRunning()) {
          _this.intervalId = setInterval(function () {
            updateTimer();
          }, 1000);
        }

        function calculateBetEnd() {
          if (_this.betEndSecond <= 0) {
            _this.betEndTime = '已封盘';
            if (_this.isActivite) {
              _this.$emit('onStopBet');
            }
          } else {
            _this.betEndSecond--;
            _this.betEndTime = _this._formatterTime(_this.betEndSecond);
          }
        }

        function calculateDrawEnd() {
          if (_this.drawEndSecond === 0) {
            if (_this.isActivite) {
              _this.$emit('onDrawing');
              _this.stop('开奖中');
            } else {
              _this.drawEndSecond = _this.currPeriod;
              _this.drawEndTime = _this._formatterTime(_this.drawEndSecond);
            }
          } else {
            _this.drawEndSecond--;
            _this.drawEndTime = _this._formatterTime(_this.drawEndSecond);
          }
        }

        function updateTimer() {
          calculateBetEnd();
          calculateDrawEnd();
          _this._isNotice();
        }
      },
      _isNotice: function () {
        const _this = this;
        if (_this.isActivite) {
          _this.$emit('onBetTimerChange', _this.betEndTime);
          _this.$emit('onDrawTimerChange', _this.drawEndTime);
        }
      },
      _formatterTime: function (seconds) {
        let hour, minute, second;
        hour = parseInt(parseInt(seconds / 60) / 60);
        minute = parseInt(seconds / 60) % 60;
        second = parseInt(seconds) % 60;
        if (hour < 10) {
          hour = "0" + hour;
        }
        if (minute < 10) {
          minute = "0" + minute;
        }
        if (second < 10) {
          second = "0" + second;
        }
        return hour * 1 > 0 ? `${hour}:${minute}:${second}` : `${minute}:${second}`;
      },
    }
  }
</script>
