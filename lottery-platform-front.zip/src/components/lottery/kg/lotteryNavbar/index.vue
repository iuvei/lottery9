<template>
  <aside class="fl">
    <ul>
      <li v-for="group in lotteryGroupData" :class="{active:groupId==group.id}">
        <a href="javascript:;" class="ripple">{{group.menuName}}</a>
        <div class="left-menuBox">
          <div class="left-menuBox-title">{{group.menuName}}</div>
          <div class="left-menuBox-data cf">
            <router-link v-for="menu in group.childrenList"
                         :key="menu.gameId"
                         class="ripple red_ripple"
                         :class="{cur:menu.id==gameId}"
                         :to='{name:"lotteryKgList",params:{
                             typeId:group.typeId,
                             typeCode:group.typeCode,
                             gameId:menu.gameId,
                             gameName:menu.gameName
                         }}'>
              {{menu.menuName}}
            </router-link>
          </div>
        </div>
      </li>
    </ul>
  </aside>
</template>
<script>
  export default{
    name: 'left-nav-bar',
    props: {
      lotteryGroupData: {
        type: Array,
        default: function () {
          return []
        }
      },
      groupId: {
        type: [String, Number],
        default: ''
      },
      gameId: {
        type: [String, Number],
        default: ''
      }
    }
  }
</script>
