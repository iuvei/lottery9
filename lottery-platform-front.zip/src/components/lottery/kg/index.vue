<template>
  <div class="kg_game_template" @click="defaultPopupMenu">
    <!--左侧中奖排行榜组件
    <lottery-ranking :randkingData="winning" :isShow="rankingIsShow"></lottery-ranking>-->
    <!--右侧结算，未结算菜单组件-->
    <right-toolbar-tabs :hasBetData="true"
                        :betRecordsByList="betRecordsByList"
                        :betRecordsNotList="betRecordsNotList"
                        @onOpen="onOpenBetDetailDialog"></right-toolbar-tabs>
    <!--结算菜单详情弹出框-->
    <transition name="slide-fade">
      <order-detail-dialog
        v-if="orderDetailDialogShow"
        :betDetail="betDetail"
        @onClose="orderDetailDialogShow=false">
      </order-detail-dialog>
    </transition>

    <div class="kg_content clearfix">
      <!--左侧彩种系列组件(高频，快乐等)-->
      <left-nav-bar ref="leftNavBar" :account="account" :balance="balance" :kgMenusList="lotteryKgMenus" :gameCode="baseParams.gameCode"
                    @referBalance="refreshUserBalance"
                    @pageNum="pageNumChange"></left-nav-bar>
      <!--中间内容-->
      <article class="fl clearfix">
        <div class="kg_announcement_box clearfix" style="position: relative">
          <!--中间内容彩种，玩法列表组件-->
          <div style="width: 1154px;overflow: hidden;" class="kg_lottery_selecter" :class="{no_classify:false}">
            <div ref="wrapper" style="position: relative;width: 1100px; margin: 0 auto;overflow: hidden;max-height:86px;">
              <div class="lottery-type clearfix" :style="`width: ${totalWidth}px;`">
                <template v-for="(item,index) in lotteryTimerList">
                  <!---->
                  <div ref="listGroup" class="fl"
                       :class="[{active:baseParams.gameCode===item.gameCode},getBackgroundImgClass(item.gameCode)]"
                       @click="listClick(index)"
                       :key="index">
                    <router-link
                      :to='{name:"lotteryKgList",params:{
                      typeId:baseParams.typeId,
                      typeCode:baseParams.typeCode,
                      gameId:item.gameId,
                      gameCode:item.gameCode,
                      gameName:item.gameName}}'>
                      <count-down-timer
                        @onDrawTimerChange="onDrawTimerChange"
                        @onBetTimerChange="onBetTimerChange"
                        @onDrawing="_getLotteryDrawInfo"
                        @onStopSells="onStopSells"
                        @onStopBet="onStopBet"
                        :ref="`timer${item.gameId}`"
                        :isActivite="baseParams.gameCode===item.gameCode"
                        :lotteryName="item.gameName"></count-down-timer>
                    </router-link>
                  </div>
                </template>
              </div>
            </div>

            <!--玩法列表 -->
            <div class="lottery-type-classify">
              <span @click="switchPlay(item.id,item.ruleMasterCode,item.ruleMasterName)"
                    v-for="(item,index) in lotteryPlaysList"
                    class="ripple red_ripple"
                    :class="{cur:item.ruleMasterCode==baseParams.playCode}"
                    :key="index">
                {{item.ruleMasterName}}
              </span>
            </div>
          </div>
          <transition name="fade">
            <div v-show="showSlideToolLeft" class="scrollLeft" @click="scrollToLeftSide"></div>
          </transition>
          <transition name="fade">
            <div v-show="showSlideToolRight" class="scrollRight" @click="scrollToRightSide"></div>
          </transition>
          <div class="top clearfix">
            <div class="kg_lottery_reciprocal fl">
              <div>
                {{baseParams.gameName}}&nbsp;&nbsp;<span>{{currentIssue}}</span> 期 &nbsp;&nbsp;
                <p>
                  封盘时间：<span :class="{font_size:showTime.betEndTime.length>8}">{{showTime.betEndTime}}</span>&nbsp;&nbsp;&nbsp;&nbsp;开奖时间：<span
                  :class="{font_size:showTime.betEndTime.length>8}">{{showTime.drawEndTime}}</span>
                </p>
              </div>
            </div>
            <div class="kg_lottery_box fl">
              <div class="fl w655">
                <div class="reciprocal_data">
                  第 <span>{{winningIssue}}</span> 期
                  <p>开奖号码</p>
                </div>
                <div class="kg_lottery_date_now" :class="{kg_lottery_number:hisShow}">
                  <template v-if="lotteryLaodingStaus==='loading'">
                    <div class="kg-number-title">加载中...</div>
                  </template>
                  <template v-else-if="lotteryLaodingStaus==='drawing'">
                    <div class="kg-number-title">开奖中...</div>
                  </template>
                  <template v-else-if="lotteryLaodingStaus==='draw'">
                    <ul v-if="isKlc()" class="clearfix kg-number-new">
                      <li class="pc_egg_ball pc_egg_computed">
                        <div><span>0</span></div>
                      </li>
                      <li class="operator">+</li>
                      <li class="pc_egg_ball pc_egg_computed">
                        <div><span>0</span></div>
                      </li>
                      <li class="operator">+</li>
                      <li class="pc_egg_ball pc_egg_computed">
                        <div><span>0</span></div>
                      </li>
                      <li class="operator">=</li>
                      <li class="pcEggSumColor pc_egg_ball" :class="getPcddColor(pcGetSum)">
                        <div><span>{{pcGetSum}}</span></div>
                      </li>
                    </ul>
                    <ul v-else-if="baseParams.typeCode === 'kl8'" class="clearfix kg-number-new kl8Number" >
                      <li v-for="(list,index) in kl8LotteryNum" :key="index" :class="getMarkSixColor(index)">
                        <div><span>{{list}}</span></div>
                      </li>
                    </ul>
                    <ul v-else class="clearfix kg-number-new">
                      <li v-for="(list,index) in lotteryNum" :key="index" :class="getMarkSixColor(index)">
                        <div><span>{{list}}</span></div>
                      </li>
                    </ul>
                  </template>
                </div>
              </div>
              <div class="kg_explain_tendency fr">
                <p @click="play_dialogVisible=true" class="play_explain">游戏规则</p>
                <p @click="onHisDrawOpen" class="play_numberTrend"><a>历史开奖</a></p>
              </div>
            </div>
          </div>
        </div>
        <!--此div未抽离成组件，是筹码设置和快速最号-->
        <div class="lottery_chip_install">
          <div class="counter-set fl pl17">
            <div class="left fl">
              <span class="fl" @click="chipListDislogShow=!chipListDislogShow" v-on:click.stop> 筹码设置</span>
              <ul class="fl">
                <li v-for="n in 5" :key="n" @click="chipSetting(n)" :class="{active:chipRotate == n}">
                  {{ chipSettingData[n - 1] }}
                </li>
              </ul>
            </div>
            <div class="right fr">
              金额 &nbsp;
              <input type="text" v-model="chipMoney" number>&nbsp;
              <a style='width:62px;' v-if="hasBetDatas" class="btn btn-danger btn-lg ripple"
                 @click="submitBetbtn()">{{isChaseNum ? "追号" : "投注"}}</a>
              <a style='width:62px;' v-else class="btn btn-danger btn_disabled btn-lg ripple">{{isChaseNum ? "追号" : "投注"}}</a>&nbsp;
              <a style='width:62px;' v-if="hasBetDatas || chipMoney != ''" class="btn btn-danger btn-lg ripple" @click="resetBet()">重填</a>
              <a style='width:62px;' v-else class="btn btn-danger btn_disabled btn-lg ripple">重填</a>
              <a style='width:62px;' class="btn btn-danger btn-lg ripple" @click="allBet">全选</a>
            </div>
            <ul class="chip-box" v-if="chipListDislogShow" v-on:click.stop>
              <li><i class="icon-chip"></i>筹码设置</li>
              <li class="num" v-for="n in 5" :key="n">
                <select v-model="chipSettingData[n-1]">
                  <option v-for="i in 9" :key="i">{{ i * Math.pow(10, n - 1) }}</option>
                </select>
              </li>
              <li>
                <a href="javascript:;" class="chip-btn btn btn-danger btn-lg ripple"
                   @click="chipListDislogShow=false">确定</a>
              </li>
            </ul>
          </div>
          <!--<div class="chase_number fl">
            <el-checkbox v-model="isChaseNum">快速追号</el-checkbox>
            <transition name="fade">
              <div v-if="isChaseNum"> 期数&nbsp;
                <input type="text" v-model="chaseAmount">
                &nbsp;期&nbsp;&nbsp;
                <el-checkbox v-model="chaseIsWinStop">中奖停止追号</el-checkbox>
              </div>
            </transition>
          </div>-->
          <betting-dialog ref="betDetailDialog" :dialogVisible="dialogVisible"
                          :nextIssue="currentIssue"
                          :gameTime="showTime.betEndTime"
                          :isChaseNum="isChaseNum"
                          :chaseIsWinStop="chaseIsWinStop"
                          :betDetails="betDetails"
                          @handleRemoveBet="handleRemoveBet"
                          @handleSubmitBet="handleSubmitBet"></betting-dialog>
        </div>
        <!--投注内容-->
        <div class="kg_lottery_content">
          <div class="game-play-content clearfix">
            <div class="bet-content-mask" v-show="isStopSells">
              <img src="../../../../static/assets/commons/stop_sells.png"/>
            </div>
            <div class="bet-content-mask" v-show="isStopBet">
              <img src="../../../../static/assets/commons/yifengpan.png"/>
            </div>
            <template v-if="controller.ssc.show">
              <!--整合盘玩法页面-->
              <integration-pan v-if="controller.ssc.plays.ssc_zhp.show"
                               ref="sscIntegration"
                               :betAmount="chipMoney"
                               @onBetClick="onBetClick"
                               :renderData="renderContentData"></integration-pan>
              <!--两面盘玩法页面-->
              <ssc-two-sides-pan
                v-if="controller.ssc.plays.ssc_lmp.show"
                ref="sscTwoSidesPan"
                @onBetClick="onBetClick"
                :betAmount="chipMoney"
                :renderData="renderContentData"></ssc-two-sides-pan>
              <!--数字盘玩法页面-->
              <number-pan
                v-if="controller.ssc.plays.ssc_szp.show"
                ref="sscNumberPan"
                @onBetClick="onBetClick"
                :betAmount="chipMoney"
                :renderData="renderContentData"></number-pan>
              <!-- 第一球，第二球，第三球，第四球，第五球玩法页面-->
              <num-ball-pan
                v-if="controller.ssc.plays.ssc_dyq.show||
                controller.ssc.plays.ssc_deq.show||
                controller.ssc.plays.ssc_dsanq.show||
                controller.ssc.plays.ssc_dsiq.show||
                controller.ssc.plays.ssc_dwq.show"
                ref="sscNumberBall"
                @onBetClick="onBetClick"
                :betAmount="chipMoney"
                :playName="baseParams.playName"
                :renderData="renderContentData"></num-ball-pan>
            </template>
            <template v-if="controller.pk10.show">
              <!--两面盘玩法页面-->
              <pk-tow-sides-pan
                v-if="controller.pk10.plays.pk10_lmp.show"
                ref="pk10twoSides"
                @onBetClick="onBetClick"
                :betAmount="chipMoney"
                :renderData="renderContentData"></pk-tow-sides-pan>
              <!--1-10名玩法页面-->
              <pk-number-pan
                v-if="controller.pk10.plays.pk10_1_10m.show"
                ref="pk10Number"
                @onBetClick="onBetClick"
                :renderData="renderContentData"
                :betAmount="chipMoney"></pk-number-pan>
              <!--冠亚和玩法页面-->
              <first-and-second-sum
                v-if="controller.pk10.plays.pk10_gyh.show"
                ref="pk10Airmender"
                @onBetClick="onBetClick"
                :playName="baseParams.playName"
                :betAmount="chipMoney"
                :renderData="renderContentData"></first-and-second-sum>
            </template>
            <template v-if="controller.k3.show">
              <happy-three v-if="controller.k3.plays.ks_sb.show"
                           ref="happyThree"
                           @onBetClick="onBetClick"
                           :betAmount="chipMoney"
                           :renderData="renderContentData"></happy-three>
            </template>
            <template v-if="controller.klc.show">
              <pc-egg v-if="controller.klc.plays.klc_xywf.show"
                      ref="pcAggShow"
                      @onBetClick="onBetClick"
                      :betAmount="chipMoney"
                      :renderData="renderContentData"></pc-egg>
            </template>
            <div class="fl mark_six" v-if="controller.xgc.show">
              <!--特码玩法页面-->
              <hongkon-special-code-head-end v-if="controller.xgc.plays.klc_tmtw.show"
                                             ref="specialCodeHeadAndEndShow"
                                             @onBetClick="onBetClick"
                                             :betAmount="chipMoney"
                                             :renderData="renderContentData"></hongkon-special-code-head-end>
              <Hongkon-special-code-qima v-if="controller.xgc.plays.klc_qm.show"
                                         ref="specialCodeQimaShow"
                                         @onBetClick="onBetClick"
                                         :betAmount="chipMoney"
                                         :renderData="renderContentData">

              </Hongkon-special-code-qima>
              <Hongkon-wuxing-and-banbo v-if="controller.xgc.plays.klc_wx.show||controller.xgc.plays.klc_bb.show"
                                        ref="wuxingAndBanboShow"
                                        @onBetClick="onBetClick"
                                        :betAmount="chipMoney"
                                        :renderData="renderContentData"
                                        :currCode="baseParams.playCode"></Hongkon-wuxing-and-banbo>
              <hongkon-special-code v-if="controller.xgc.plays.klc_tm.show"
                                    ref="specialCodeShow"
                                    @onBetClick="onBetClick"
                                    :betAmount="chipMoney"
                                    :renderData="renderContentData"></hongkon-special-code>
              <!--特肖玩法页面-->
              <hongkon-special-animal v-if="controller.xgc.plays.klc_tx.show"
                                      ref="specialAnimalShow"
                                      @onBetClick="onBetClick"
                                      :betAmount="chipMoney"
                                      :renderData="renderContentData"></hongkon-special-animal>
              <!--正码一，正码二，正码三，正码四，正码五玩法页面-->
              <hongkon-other-number v-if="controller.xgc.plays.klc_zm1.show||
              controller.xgc.plays.klc_zm2.show||
              controller.xgc.plays.klc_zm3.show||
              controller.xgc.plays.klc_zm4.show||
              controller.xgc.plays.klc_zm5.show||
              controller.xgc.plays.klc_zm6.show"
                                    ref="orthocodeNumShow"
                                    @onBetClick="onBetClick"
                                    :betAmount="chipMoney"
                                    :renderData="renderContentData"
                                    :currCode="baseParams.playCode"></hongkon-other-number>
              <!--正码玩法页面-->
              <hongkon-other-code v-if="controller.xgc.plays.klc_zm.show"
                                  ref="orthocodeShow"
                                  @onBetClick="onBetClick"
                                  :betAmount="chipMoney"
                                  :renderData="renderContentData"></hongkon-other-code>
            </div>
            <template v-if="controller.klsf.show">
              <klsf-tow-sides v-if="controller.klsf.plays.klsf_lmp.show"
                              ref="klsf_tow_sides_ref"
                              @onBetClick="onBetClick"
                              :betAmount="chipMoney"
                              :renderData="renderContentData"></klsf-tow-sides>
              <klsf-num-ball-pan v-if="controller.klsf.plays.klsf_dyq.show||
              controller.klsf.plays.klsf_deq.show||
              controller.klsf.plays.klsf_dsq.show||
              controller.klsf.plays.klsf_dsiq.show||
              controller.klsf.plays.klsf_dwq.show||
              controller.klsf.plays.klsf_dlq.show||
              controller.klsf.plays.klsf_dqq.show||
              controller.klsf.plays.klsf_dbq.show"
                                 ref="klsf_num_ball_ref"
                                 @onBetClick="onBetClick"
                                 :betAmount="chipMoney"
                                 :renderData="renderContentData"
                                 :playName="baseParams.playName"></klsf-num-ball-pan>
              <klsf-other-code v-if="controller.klsf.plays.klsf_zm.show"
                               ref="klsf_other_code_ref"
                               @onBetClick="onBetClick"
                               :betAmount="chipMoney"
                               :renderData="renderContentData"></klsf-other-code>
            </template>
            <template v-if="controller.c11x5.show">
              <c11x5-single-code v-if="controller.c11x5.plays.c11x5_dm.show"
                                 ref="c11x5_single_code_ref"
                                 @onBetClick="onBetClick"
                                 :betAmount="chipMoney"
                                 :renderData="renderContentData"></c11x5-single-code>
              <c11x5-tow-sides v-if="controller.c11x5.plays.c11x5_lmp.show"
                               ref="c11x5_two_sides_ref"
                               @onBetClick="onBetClick"
                               :betAmount="chipMoney"
                               :renderData="renderContentData"></c11x5-tow-sides>
            </template>
            <template v-if="controller.kl8.show">
              <k8-single-code v-if="controller.kl8.plays.k8_zm.show"
                              ref="k8Integration"
                              @onBetClick="onBetClick"
                              :betAmount="chipMoney"
                              :renderData="renderContentData"></k8-single-code>
              <k8-two-sides-pan v-if="controller.kl8.plays.k8_lmp.show"
                                ref="k8TwoSidesPan"
                                @onBetClick="onBetClick"
                                :betAmount="chipMoney"
                                :renderData="renderContentData"></k8-two-sides-pan>
            </template>
            <template v-if="controller.ssl.show">
              <!--整合盘玩法页面-->
              <ssl-integration v-if="controller.ssl.plays.ssc_zhp.show"
                               ref="sslIntegration"
                               :betAmount="chipMoney"
                               @onBetClick="onBetClick"
                               :renderData="renderContentData"></ssl-integration>
              <!--两面盘玩法页面-->
              <ssl-two-sides
                v-if="controller.ssl.plays.ssc_lmp.show"
                ref="sslTwoSidesPan"
                @onBetClick="onBetClick"
                :betAmount="chipMoney"
                :renderData="renderContentData"></ssl-two-sides>
              <!--数字盘玩法页面-->
              <ssl-number
                v-if="controller.ssl.plays.ssc_szp.show"
                ref="sslNumberPan"
                @onBetClick="onBetClick"
                :betAmount="chipMoney"
                :renderData="renderContentData"></ssl-number>
              <!-- 第一球，第二球，第三球 玩法页面-->
              <ssl-num-ball
                v-if="controller.ssl.plays.ssc_dyq.show||
                controller.ssl.plays.ssc_deq.show||
                controller.ssl.plays.ssc_dsq.show"
                ref="sslNumberBall"
                @onBetClick="onBetClick"
                :betAmount="chipMoney"
                :playName="baseParams.playName"
                :renderData="renderContentData"></ssl-num-ball>
              <sslkd-pan
                v-if="controller.ssl.plays.ssc_kd.show"
                ref="sslkdPan"
                @onBetClick="onBetClick"
                :betAmount="chipMoney"
                :playName="baseParams.playName"
                :renderData="renderContentData"></sslkd-pan>
              <sslhs-pan
                v-if="controller.ssl.plays.ssc_hs.show"
                ref="sslhsPan"
                @onBetClick="onBetClick"
                :betAmount="chipMoney"
                :playName="baseParams.playName"
                :renderData="renderContentData"></sslhs-pan>
            </template>
          </div>
          <div class="counter-set clearfix">
            <div class="left fl">
              <span class="fl" @click="chipListDislogShow2=!chipListDislogShow2" v-on:click.stop>筹码设置</span>
              <ul class="fl">
                <li v-for="n in 5" :key="n" @click="chipSetting(n)" :class="{active:chipRotate == n}">
                  {{ chipSettingData[n - 1] }}
                </li>
              </ul>
            </div>
            <div class="right fr">
              金额 &nbsp;
              <input type="text" v-model="chipMoney" number>&nbsp;
              <a style='width:62px;' v-if="hasBetDatas" class="btn btn-danger btn-lg ripple"
                 @click="submitBetbtn()">{{isChaseNum ? "追号" : "投注"}}</a>
              <a style='width:62px;' v-else class="btn btn-danger btn_disabled btn-lg ripple">{{isChaseNum ? "追号" : "投注"}}</a>&nbsp;
              <a style='width:62px;' v-if="hasBetDatas || chipMoney != ''" class="btn btn-danger btn-lg ripple" @click="resetBet()">重填</a>
              <a style='width:62px;' v-else class="btn btn-danger btn_disabled btn-lg ripple">重填</a>
              <a style='width:62px;' class="btn btn-danger btn-lg ripple"  @click="allBet">全选</a>
            </div>
            <ul class="chip-box" v-if="chipListDislogShow2" v-on:click.stop>
              <li><i class="icon-chip"></i>筹码设置</li>
              <li class="num" v-for="n in 5" :key="n">
                <select v-model="chipSettingData[n-1]">
                  <option v-for="i in 9" :key="i">{{ i * Math.pow(10, n - 1) }}</option>
                </select>
              </li>
              <li>
                <a href="javascript:;" class="chip-btn btn btn-danger btn-lg ripple"
                   @click="chipListDislogShow2=false">确定</a>
              </li>
            </ul>
          </div>
          <!--露珠组件-->
          <div v-if="isDewdropShow" class="center-box_top clearfix">
            <luzhu-chart ref="refLuzhuChart"
                         :dewdrop="dewdrop"
                         :gameId="baseParams.gameId"
                         :typeCode="baseParams.typeCode"></luzhu-chart>
          </div>
        </div>
        <div class="history_lottery">
          <!--号码，大小，单双组件-->
          <lottery-history-chart :groupCode="baseParams.typeCode"
                                 :gameCode="baseParams.gameCode"
                                 :pk10Show="controller.pk10.show"
                                 :historyData="historyData"
                                 :historyNumber="historyNumber"></lottery-history-chart>
          <!--两面长龙组件-->
          <div v-if="winLongRankShow">
            <two-sides-changlong :winLongRank="winLongRank"></two-sides-changlong>
          </div>
        </div>
      </article>
    </div>
    <!--控制声音-->
    <div id="wrapAudio" v-if="!notSound">
      <audio id="entertainedAudio">
        <source src="static/assets/audio/10s.mp3" type="audio/mpeg">
      </audio>
      <audio id="switchTypeAudio">
        <source src="static/assets/audio/ding.mp3" type="audio/mpeg">
      </audio>
      <audio id="chatAudio">
        <source src="static/assets/audio/1.mp3" type="audio/mpeg">
        <source src="static/assets/audio/1.wav" type="audio/wav">
      </audio>
    </div>
    <el-dialog title="游戏规则" class="w940" v-model="play_dialogVisible">
      <div class="play_box" v-html="lotteryRuleContent"></div>
    </el-dialog>
    <el-dialog title="历史开奖" v-model="history_dialogVisible" class="w940">
      <div class="play-box">
        <div class="play-box__title">
          <el-select class="item" v-model="history_query.lotteryGameId" placeholder="请选择" @change="onHisLotteryChange">
            <el-option v-for="item in history_reward_options" :key="item.gameId" :label="item.gameName"
                       :value="item.gameId"></el-option>
          </el-select>
          <el-input class="item" placeholder="请输入期号" style="width: 200px" v-model="history_query.lotteryResultNum"></el-input>
          <el-radio-group class="item" v-model="history_radio_value" @change="onHisRadioChange">
            <el-radio-button label="近50期"></el-radio-button>
            <el-radio-button label="近100期"></el-radio-button>
            <el-radio-button label="近200期"></el-radio-button>
          </el-radio-group>
          <el-button class="item" type="primary" @click="search_handle">搜索</el-button>
        </div>
        <!--<div style="margin-bottom: 5px">
          <el-input placeholder="请输入期号" style="width: 200px" v-model="history_query.lotteryResultNum"></el-input>
          <el-button type="primary" @click="search_handle">搜索</el-button>
        </div>-->
        <div>
          <el-table v-loading.body="history_table_loading" :data="history_reward_table" height="450" border>

            <el-table-column label="期号" width="160" align="center">
              <template slot-scope="scope">
                <span>第{{scope.row.lotteryResultNum}}期</span>
              </template>
            </el-table-column>

            <el-table-column label="开奖号码" align="center" width="640">
              <template slot-scope="scope" v-if="scope.row.lotteryNumber && scope.row.lotteryNumber.indexOf(',')!==-1">
                <span class="red_ball_small" v-for="(item,index) in scope.row.lotteryNumber.split(',')" :key="index">{{item}}</span>
              </template>
            </el-table-column>

          </el-table>
        </div>
      </div>
    </el-dialog>
  </div>
</template>
<script>
  import "./common.js"
  import "../../../../static/assets/css/pk10.css"
  import countdownPopup from './countDownPopup/index'
  import lotteryRanking from './leftLotteryRanking/index'
  import rightToolbarTabs from './rigthToolBarTabs/index'
  import orderDetailDialog from './orderDetailDialog/index'
  import leftNavBar from './leftNavBar/index'
  import lotteryNavbar from './lotteryNavbar/index'
  import drawNumberList from './drawNumberList/index'
  import bettingDialog from './bettingDialog/index'
  import {FirstAndSecondSum, PkNumberPan, PkTowSidesPan} from './pk10/index'
  import {IntegrationPan, NumBallPan, NumberPan, SscTwoSidesPan} from './ssc/index'
  import {SslIntegration, SslNumBall, SslNumber, SslTwoSides, SslkdPan, SslhsPan} from './ssl/index'
  import {
    HongkonOtherCode,
    HongkonSpecialAnimal,
    HongkonOtherNumber,
    HongkonSpecialCode,
    HongkonSpecialCodeHeadEnd,
    HongkonSpecialCodeQima,
    HongkonWuxingAndBanbo
  } from './happy/hongKonSix/index'
  import {C11x5SingleCode, C11x5TowSides} from './11x5/index'
  import {k8SingleCode, k8TwoSidesPan} from './k8/index'
  import {KlsfTowSides, KlsfNumBallPan, KlsfOtherCode} from './klsf/index'
  import happyThree from './happy/happyThree/happyThree'
  import pcEgg from './happy/pcEgg/pcEgg'
  import luzhuChart from './luzhuChart/index'
  import twoSidesChanglong from './twoSidesChanglong/index'
  import lotteryHistoryChart from './lotteryHistoryChart/index'
  import countDownTimer from './countDownTimer/index'
  import {mapActions, mapGetters} from 'vuex'
  import BScroll from 'better-scroll'
  import {
    getLotteryPlays,
    getMasterList,
    getNumberHistory,
    getDewdropList,
    getLotterysDraw,
    getLotteryDraw,
    lotteryBet,
    getDataFromGameCode
  } from '../../../api/lotteryKg'
  import {getUrlByToken} from '../../../api/lottery'
  import {getChartList} from '../../../api/trend'
  import {isNumber, allIsNumber, getPerIssue} from '../../../utils/index'
  import  lotteryConfig from './config/index'
  export default{
    components: {
      NumBallPan,
      SscTwoSidesPan,
      countdownPopup,
      lotteryRanking,
      rightToolbarTabs,
      orderDetailDialog,
      leftNavBar,
      lotteryNavbar,
      drawNumberList,
      bettingDialog,
      IntegrationPan,
      NumberPan,
      PkTowSidesPan,
      PkNumberPan,
      FirstAndSecondSum,
      happyThree,
      pcEgg,
      HongkonSpecialCode,
      HongkonSpecialCodeHeadEnd,
      HongkonSpecialCodeQima,
      HongkonWuxingAndBanbo,
      HongkonSpecialAnimal,
      HongkonOtherNumber,
      HongkonOtherCode,
      KlsfTowSides,
      KlsfNumBallPan,
      KlsfOtherCode,
      luzhuChart,
      twoSidesChanglong,
      lotteryHistoryChart,
      countDownTimer,
      C11x5SingleCode,
      C11x5TowSides,
      k8TwoSidesPan,
      k8SingleCode,
      SslIntegration,
      SslNumBall,
      SslNumber,
      SslTwoSides,
      SslkdPan,
      SslhsPan
    },
    data () {
      return {
        controller: {},
        lotteryRuleContent: '',
        history_query: {
          lotteryGameId: '',
          recentIssues: 0,
          lotteryResultNum:''
        },
        isStopSells: false,
        history_table_loading: false,
        history_radio_items: {'近50期': 50, '近100期': 100, '近200期': 200},
        history_radio_value: '近50期',
        history_dialogVisible: false,
        history_reward_options: [],
        history_reward_table: [],
        orderDetailDialogShow: false,
        baseParams: {
          typeId: '',
          typeCode: '',
          gameId: '',
          gameCode: '',
          gameName: '',
          playId: '',
          playCode: '',
          playName: ''
        },
        chipMoney: '',
        lotteryTimerList: [],
        lotteryPlaysList: [],//玩法列表
        renderContentData: [],
        currRef: 'sscIntegration',
        // 筹码值
        chipSettingData: [5, 50, 100, 1000, 10000],
        hasBetDatas: false,
        //声音
        notSound: false,
        sscIntegration: true,
        sscTwoShow: false,
        sscNumBallShow: false,
        sscShow: true,
        sscNumberShow: false,
        pk10Show: false,
        pk10TwoShow: false,
        pk10NumberShow: false,
        pk10AirmenderShow: false,
        //快乐彩
        happyShow: false,
        happyThreeShow: false,
        pcAggShow: false,
        markSixShow: false,
        specialCodeShow: false,
        specialCodeHeadAndEndShow: false,
        specialCodeQimaShow: false,
        wuxingAndBanboShow: false,
        specialAnimalShow: false,
        orthocodeNumShow: false,
        orthocodeShow: false,
        currLotteryTimerId: -1,
        //中奖排行
        // winning: [],
        //显示排行版
        //rankingIsShow: false,
        hasBetData: false,
        betRecords: [],
//        betRecordsByList: [],
        betDetailname: "",
//        betRecordsNotList: [],
        betDetail: null,
        showTime: {
          betEndTime: '加载中',
          drawEndTime: '加载中',
        },
        dialogVisible: false,
        winLongRankShow: true,
        historyData: [],
        historyNumber: [],
        trendLink: '',
        isDewdropShow: true,
        chipListDislogShow2: false,
        isChaseNum: false,
        chipRotate: false,
        currentIssue: "00000-00",
        winningIssue: "00000-00",
        hisShow: false,
        lotteryLaodingStaus: '',
        tempLotteryNum: [],
        kl8LotteryNum: [],
        lotteryNum: [],
        chipListDislogShow: false,
        chaseIsWinStop: false,
        betDetails: [],
        dewdrop: {},
        winLongRank: [],
        //pc蛋蛋开奖号码总和
        pcGetSum: 0,
        markSixNum: "",
        drawAnimation: [],//开奖动画(球滚动)
        //设置动画延迟时间对象
        timerContainer: {},
        lotteryIntervalId: -1,
        chaseAmount: 5,
        play_dialogVisible: false,
        animateTime: 0,
        totalWidth: 1124,
        scroll: null,
        showSlideToolLeft: false,
        showSlideToolRight: false,
        isStopBet: false
      }
    },
    created(){
      const _this = this;
      _this.controller = lotteryConfig;
      _this.refreshUserBalance();
      _this.queryGameBet({pageNum: 1, pageSize: 5});
      _this.lotteryKgMenus.forEach(item => {
        if (item && item.children) {
          item.children.forEach(item => {
            _this.history_reward_options.push(item);
          });
        }
      });
    },
    mounted() {
      let _this = this
      this.$nextTick(function () {
        _this.scroll = new BScroll(this.$refs.wrapper, {
          scrollX: true,
          scrollY: false,
          bounce: true,
          click: true
        })
      })
    },
    methods: {
      ...mapActions([
        'setIntegrationArr',
        'queryGameBet'
      ]),
      search_handle(){
        this.getLotteryHisList();
      },
      onStopBet: function () {
        this.isStopBet = true;
        this.hasBetDatas = false;
      },
      listClick(index){
        this.$nextTick(function () {
          this.scroll.scrollToElement(this.$refs.listGroup[index], 400, true);
        })
      },
      onStopSells: function (val) {
        this.isStopSells = val;
      },
      onHisLotteryChange: function (val) {
        this.history_query.lotteryGameId = val;
        this.getLotteryHisList();
      },
      onHisRadioChange: function (key) {
        this.history_query.recentIssues = this.history_radio_items[key] || 0;
        this.getLotteryHisList();
      },
      getLotteryHisList: function () {
        this.history_table_loading = true;
        getChartList(this.history_query).then(res => {
          this.history_table_loading = false;
          const {currentStatus, currentData} = res;
          if (currentStatus === 0) {
            this.history_reward_table = currentData;
          }
        }).catch(err => {
          this.history_table_loading = false;
        })
      },
      onHisDrawOpen: function () {
        const _this = this;
        _this.history_dialogVisible = true;

        _this.history_radio_value = '近50期';
        _this.history_query.lotteryGameId = Number(_this.baseParams.gameId);

        _this.onHisRadioChange(_this.history_radio_value);
      },
      getBackgroundImgClass: function (gameCode) {
        if (!gameCode) return;
        if (gameCode.indexOf('tj') !== -1) {
          return 'tianjin';
        } else if (gameCode.indexOf('xj') !== -1) {
          return 'xingjiang';
        } else if (gameCode.indexOf('bj') !== -1) {
          return 'beijing';
        } else if (gameCode.indexOf('jx') !== -1) {
          return 'jiangxi';
        } else if (gameCode.indexOf('js') !== -1) {
          return 'jiangsu';
        } else if (gameCode.indexOf('gx') !== -1) {
          return 'guangxi';
        } else if (gameCode.indexOf('gs') !== -1) {
          return 'gansu';
        } else if (gameCode.indexOf('sh') !== -1) {
          return 'shanghai';
        } else if (gameCode.indexOf('xyft') !== -1) {
          return 'xingyunfieting';
        } else if (gameCode.indexOf('anh') !== -1) {
          return 'anhui';
        } else if (gameCode.indexOf('hub') !== -1) {
          return 'hubei';
        } else if (gameCode.indexOf('lhc') !== -1) {
          return 'xianggang';
        } else if (gameCode.indexOf('dd') !== -1) {
          return 'pcdd';
        } else if (gameCode.indexOf('cq') !== -1) {
          return 'chongqing';
        } else if (gameCode.indexOf('heb') !== -1) {
          return 'hebei';
        } else if (gameCode.indexOf('xywfc') !== -1) {
          return 'xywfc';
        } else if (gameCode.indexOf('xyefc') !== -1) {
          return 'xyefc';
        } else if (gameCode.indexOf('xyffc') !== -1) {
          return 'xyffc';
        } else if (gameCode.indexOf('wfpk10') !== -1) {
          return 'wfpk10';
        } else if (gameCode.indexOf('ffpk10') !== -1) {
          return 'ffpk10';
        } else if (gameCode.indexOf('wfk3') !== -1) {
          return 'wfk3';
        } else if (gameCode.indexOf('efk3') !== -1) {
          return 'efk3';
        } else if (gameCode.indexOf('ffk3') !== -1) {
          return 'ffk3';
        } else {
          return 'other';
        }
      },
      pageNumChange: function (newIndex, oldIndex) {
        this.$nextTick(function () {
          this.scroll.scrollToElement(this.$refs.listGroup[newIndex], 400, true);
        })
      },
      scrollToRightSide: function () {
        this.showSlideToolLeft = true
        if (this.scroll.maxScrollX < this.scroll.x) {
          this.showSlideToolRight = true
          this.scroll.scrollBy(-100, 0, 500)
        } else {
          this.showSlideToolRight = false
        }
      },
      scrollToLeftSide: function () {
        this.showSlideToolRight = true
        if (0 > this.scroll.x) {
          this.showSlideToolLeft = true
          this.scroll.scrollBy(100, 0, 500)
        } else {
          this.showSlideToolLeft = false
        }
      },
      onOpenBetDetailDialog: function (info) {
        this.betDetail = info;
        this.orderDetailDialogShow = true;
      },
      _setBaseOptions: function (options) {
        this.baseParams = Object.assign({}, this.baseParams, options);
      },
      _pageInit: function () {
        const _this = this;
        _this.$parent.headHtmlShow = false;
        _this.$parent.footHtmlShow = false;
        _this.initPageParams();
        _this.initLotteryHistoryResult();
        _this.betContentShowManage();
        _this.initLotteryPlays();
        _this.initLotterysDrawInfo();
      },
      initPageParams: function () {
        this.filterLotterys();
      },
      filterLotterys: function () {
        const _this = this;
        let flag = false;
        const menuList = Array.from(_this.lotteryKgMenus || []);
        for (let i = 0; i < menuList.length; i++) {
          const {typeCode, children} = menuList[i];
          if (typeCode === _this.baseParams.typeCode) {
            if (children && children.length > 0) {
              _this.lotteryTimerList = children.map(item => {
                const {gameCode, removed, lotteryText} = item;
                if (gameCode === _this.baseParams.gameCode) {
                  _this.isStopSells = removed === 1;
                  _this.lotteryRuleContent = lotteryText;
                }
                item.period = 300;
                item.second = 0;
                return item;
              });
              if (_this.lotteryTimerList.length > 6) {
                this.showSlideToolLeft = true
                this.showSlideToolRight = true
              } else {
                this.showSlideToolLeft = false
                this.showSlideToolRight = false
              }
              _this.totalWidth = _this.lotteryTimerList.length * 185 - 17;
              flag = true;
              break;
            }
          }
        }
        if (!flag) console.log(`【error】 can not match the same lotter info... `)
      },
      handleSubmitBet: function (totalAmount) {
        const _this = this;
        if (_this.betDetails.length < 1) {
          this.$message.error('抱歉,投注数据获取失败,请重新投注');
          return false;
        }
        if (_this.lotteryLaodingStaus === 'loading') {
          this.$message('开奖数据获取中...');
          return false;
        }

        const params = {
          gameId: _this.baseParams.gameId,
          currentNum: _this.currentIssue,
          totalAmount: totalAmount,
          betList: _this.betDetails
        };

        _this.$parent.loadMask = true;
        lotteryBet(params).then(res => {
          _this.$parent.loadMask = false;
          const {currentStatus, errorInformation} = res;
          if (currentStatus === 0) {
            _this.$refs['betDetailDialog'].close();
            _this.$message({
              message: '投注成功！',
              type: 'success'
            });
            _this.refreshUserBalance();
            _this.queryGameBet({pageNum: 1, pageSize: 5});
            _this.resetBet();
          } else {
            const {errCode} = errorInformation;
            _this.$message.error(errCode);
          }
        }).catch(err => {
          _this.$parent.loadMask = false;
          console.log(`【error】: lotteryBet err:${err}`);
        });
      },
      refreshUserBalance: function () {
        this.$store.dispatch('LoadUserBalance', this.userId).then(() => {
        }).catch(err => {
        });
      },
      initLotterysDrawInfo: function () {
        this.lotteryIsLoading();
        this._getLotteryDrawInfo();
      },
      isStopSell: function (nextLotteryTime, openLotteryTime) {
        return /^[+-]?\d+(\.\d+)?$/.test(nextLotteryTime) && /^[+-]?\d+(\.\d+)?$/.test(openLotteryTime);
      },
      _getLotteryDrawInfo: function () {
        const _this = this;
        getLotterysDraw({lotteryGroupId: _this.baseParams.typeId}).then(res => {
          const {currentStatus, currentData} = res;
          if (currentStatus === 0 && currentData && currentData.length > 0) {
            currentData.forEach(item => {
              const {lotteryGameId, lotteryGameName, dateTime, nextLotteryTime, nextGameResultNum, openResultNum, openTimeType, openLotteryTime} = item;
              _this.startTimer(lotteryGameId, dateTime, nextLotteryTime, _this.isStopSell(nextLotteryTime, openLotteryTime), openLotteryTime);
              if (item.lotteryGameId == _this.baseParams.gameId) {
                _this.isStopBet = false;
                _this.onBetClick();
                _this.setLotteryDrawIssue(nextGameResultNum, openResultNum, openTimeType);
                _this.getLotteryDrawResultOnInterval(_this.baseParams.gameId, _this.winningIssue);
              }
            });
          }
        }).catch(error => {
          console.log(`【error】: getLotterysDraw ${error}`)
        });
      },
      getLotteryDrawResultOnInterval: function (gameId, winningIssue) {
        const _this = this, param = {
          lotteryGameId: gameId,
          lotteryResultNum: winningIssue
        };
        _this.lotteryLaodingStaus = 'drawing';
        function getLotteryDrawResult() {
          getLotteryDraw(param).then(res => {
            const {currentStatus, currentData} = res;
            if (currentStatus === 0 && currentData) {
              const {gameResult} = currentData;
              if (gameResult) {
                clearInterval(_this.lotteryIntervalId);
                _this.lotteryLaodingStaus = 'draw';
                _this.setLotteryDrawResult(gameResult.split(',').reverse());
                _this.startDrawLotteryBallsAnimate();

                clearTimeout(_this.timerContainer['betTimer']);
                _this.timerContainer['betTimer'] = setTimeout(function () {
                  _this.queryGameBet({pageNum: 1, pageSize: 5});
                }, 5000);

                clearTimeout(_this.timerContainer['drawHis']);
                _this.timerContainer['drawHis'] = setTimeout(function () {
                  _this.initLotteryHistoryResult();
                }, _this.animateTime);
              }
            }
          }).catch(error => {
            console.log(`【error】: requestLotteryDraw error :${error}`);
          })
        }

        if (_this.lotteryIntervalId !== -1)
          clearInterval(_this.lotteryIntervalId);
        _this.lotteryIntervalId = setInterval(function () {
          getLotteryDrawResult();
        }, 3000);
      },
      setLotteryDrawResult: function (resulrArr) {
        this.lotteryNum = resulrArr;
        this.kl8LotteryNum = resulrArr.reverse()
        this.$nextTick(function () {
          /*快乐8有20个球,显示不完全hank*/
          if (this.lotteryNum.length > 10) {
            document.querySelector('.kg-number-new').style.bottom = '17px'
          } else {
            document.querySelector('.kg-number-new').style.bottom = '0px'
          }
        });
        this.tempLotteryNum = [];
        if (this.isKlc() || this.isXgc()) {
          this.tempLotteryNum = Array.from(resulrArr);
        }
      },
      setLotteryDrawIssue: function (nextGameResultNum, openResultNum, issueType) {
        if (nextGameResultNum && isNumber(nextGameResultNum) && openResultNum && issueType) {
          this.currentIssue = nextGameResultNum;
          this.winningIssue = getPerIssue(nextGameResultNum, openResultNum, issueType);
        }
      },
      clearLastAnimateBallsTimer: function () {
        const _this = this;
        for (let key in _this.timerContainer) clearTimeout(_this.timerContainer[key]);
      },
      startTimer: function (gameId, period, second, isStart, drawTime) {
        const target = this.$refs[`timer${gameId}`];
        if (target) {
          const periodNumber = Number(period);
          const secondNumber = Number(second);
          target[0].setPeriod(periodNumber);
          target[0].setSecond(secondNumber, drawTime, isStart);
          if (isStart) {
            target[0].start();
          }
        }
      },
      lotteryIsLoading: function () {
        const _this = this;
        _this.currentIssue = "00000-00";
        _this.winningIssue = "00000-00";
        _this.lotteryLaodingStaus = 'loading';
      },
      startDrawLotteryBallsAnimate: function () {
        const _this = this;
        _this.pcGetSum = 0;
        _this.clearLastAnimateBallsTimer();
        _this.lotteryNum.forEach(_this.drawBallAnimate);
        _this.animateTime = 2000 * _this.lotteryNum.length;
      },
      isKlc: function () {
        return this.baseParams.typeCode === 'klc';
      },
      is11x5: function () {
        return this.baseParams.typeCode === 'c11x5';
      },
      isKlsf: function () {
        return this.baseParams.typeCode === 'klsf';
      },
      drawBallAnimate: function (value, index) {
        const _this = this;
        if (_this.is11x5() || _this.isKlsf()) {
          _this.lotteryNum[index] = '00'
        } else {
          _this.lotteryNum[index] = value.length === 1 ? "0" : "00";
        }

        _this.timerContainer[index] = setTimeout(function () {
          const ballObj = _this.isKlc() ? $(`.pc_egg_computed:eq(${index}) div:eq(0)`) : $(`.kg-number-new li:eq(${index}) div:eq(0)`);
          _this.lotteryAn(ballObj, value, 4000, "swing", _this.isKlc() ? _this.showPcEggBallsSum : undefined);
        }, index * (_this.isKlc() ? 300 : 500))
      },
      showPcEggBallsSum: function () {
        this.pcGetSum = this.tempLotteryNum.reduce((prev, curr, idx, arr) => Number(prev) + Number(curr));
      },
      lotteryAn: function (obj, num, sp, ease, call) {
        const _this = this, arr = _this.drawAnimation;
        let h = obj.outerHeight(),
          t = _this.isKlc() ? h * 10 * 5 - h : h * arr.length * 5 - h,
          po = arr.indexOf(num),
          p = h * po;
        if (obj[0] && obj[0].parentNode.className.indexOf("pcEggSumColor") !== -1) {
          return false;
        }
        obj.html(_this.getRollingNums).stop().css("top", -t + "px").animate({top: -p + "px"}, sp, ease, function () {
          $(this).empty().html(`<span>${num}</span>`).css("top", "0px");
          if (call) call();
        });
      },
      getRollingNums: function () {
        let _this = this, rollNums = '';
        for (let a = 0; a < 5; a++)
          _this.drawAnimation.forEach(item => rollNums += `<span>${item}</span>`);
        return rollNums;
      },
      initLotteryPlays: function () {
        const _this = this;
        let index = this.lotteryPlaysLists.getIndexLotteryPlaysList(this.baseParams.gameCode);
       
       //根据gameCode获取自定义的lotteryPlaysList列表
        this.lotteryPlaysList = this.lotteryPlaysLists.defineLotteryPlaysList[index];
        next(this.lotteryPlaysList);

        // console.log( this.defineLotteryPlaysList[index] );
        // const expTime = 5*60*1000;//设置过期时间为五分钟
        // const getData = this.storage.get(_this.baseParams.gameId,expTime);
        
        // if( !!getData ){
        //   next(getData);
        // }else{
        //   //该接口经常挂掉。无返回。。。故用计时器挂载清除的方式解决（3s无返回，则再次请求，直至有返回数据）
        //   let controller = setInterval(function(){
        //     getLotteryPlays({lotteryGameId: _this.baseParams.gameId}).then(res => {
        //       _this.storage.set( _this.baseParams.gameId , res );
        //       clearInterval(controller);
        //       next(res);
        //     }).catch(error => {
        //       console.log(`【error】: getLotteryPlays ${error}`);
        //     });
        //   },10000);
        // }

        function next(res){
          console.log(`【system】 get lottery plays success`)
          const {currentStatus, currentData} = res;
          if (currentStatus === 0) {
            _this.lotteryPlaysList = currentData || [];
            if (currentData && currentData.length > 0) {
              const {id, ruleMasterCode, ruleMasterName} = currentData[0];
              _this.switchPlay(id, ruleMasterCode, ruleMasterName);
            } else {
              console.log('【error】: getLotteryPlays result is null')
            }
          }
        }
      },
      requestContentRender: function (gameCode) {
        var _this = this;
        this.$parent.loadMask = true;
        this.renderContentData = [];
        const expTime = 5*60*1000;//设置过期时间为五分钟
        let getData
        if (!!this.$store.state.user.account) {
          getData = this.storage.get(this.$store.state.user.account + '_' + gameCode,expTime);
        } else {
          getData = this.storage.get(gameCode,expTime);
        }

        if( !!getData ){
          _this.$parent.loadMask = false;
          next(getData);
        }else{
          getDataFromGameCode({gameCode: gameCode}).then(res => {
            _this.$parent.loadMask = false;
            if (res && res.currentStatus === 2) {
              this.$message.error(res.errorInformation.errCode);
            } else {
              if (!!this.$store.state.user.account) {
                _this.storage.set( _this.$store.state.user.account + '_' + gameCode , res );
              } else {
                _this.storage.set( gameCode , res );
              }
              next(res);
            }
          }).catch(err => {
            _this.$parent.loadMask = false
            console.log(`【error】: getDataFromGameCode ${err}`)
          });
        }
        
        function next(res){
          _this.$nextTick(()=>{
            const {currentStatus, currentData} = res;
            console.log('获取的渲染数据为gameCode：'+(currentData && currentData[0].gameCode));
            if (currentStatus === 0) {
              _this.renderContentData = currentData || [];
            } else {
              console.log('【error】: load masters fail...')
            }
          })
        }
      },
      //切换玩法类型
      switchPlay: function (playId, playCode, playName) {
        this.resetBet();
        this.baseParams.playId = playId;
        this.baseParams.playCode = playCode;
        this.baseParams.playName = playName;
        this.betContentShowManage();
        this.requestContentRender(this.baseParams.gameCode);
      },
      betContentController: function (typeCode, playCode) {
        if (!typeCode || !playCode)return;
        if (playCode.indexOf('-') !== -1) {
          playCode = playCode.replace('-', '_');
        }
        const _this = this;

        function updatePlay(obj, code) {
          Object.keys(obj).forEach(k => {
            if (k === code) {
              obj[k].show = true;
              const {ref, isDewdropShow, winLongRankShow} = obj[k];
              _this.currRef = ref;
              _this.isDewdropShow = isDewdropShow;
              _this.winLongRankShow = winLongRankShow;
            }
            else obj[k].show = false
          })
        }

        Object.keys(_this.controller).forEach(k => {
          if (k === typeCode) {
            _this.controller[k].show = true
            _this.drawAnimation = _this.controller[k].drawAnimation;
            updatePlay(_this.controller[k].plays, playCode)
          } else {
            _this.controller[k].show = false
          }
        })
      },
      isXgc: function () {
        return this.baseParams.typeCode === 'xgc';
      },
      betContentShowManage: function () {
        this.betContentController(this.baseParams.typeCode, this.baseParams.playCode);
      },
      isSsc: function () {
        return this.baseParams.typeCode === 'ssc';
      },
      isPk10: function () {
        return this.baseParams.typeCode === 'pk10';
      },
      isC11x5: function () {
        return this.baseParams.typeCode === 'c11x5';
      },
      isKlsf: function () {
        return this.baseParams.typeCode === 'klsf';
      },
      initLotteryHistoryResult: function () {
        var _this = this;
        //历史记录，渲染号码，大小，单双组件
        if (_this.baseParams.gameId) {
          _this.historyData = [];
          getNumberHistory({lotteryGameId: _this.baseParams.gameId, size: 10}).then(res => {
            const {currentStatus, currentData} = res;
            if (currentStatus === 0 && currentData) {
              _this.historyData = currentData;
              for (let i = 0; i < _this.historyData.length; i++) {
                let numberArr = _this.historyData[i].lotteryResult.split(',');
                let numbers = [];
                for (let j = 0; j < numberArr.length; j++) {
                  numbers.push(numberArr[j]);
                }
                _this.historyData[i].historyNumber = numbers;
              }
            }

          }).catch(() => {
            this.$parent.loadMask = false;
          });
        }
        //露珠和两面长龙
        if (this.isSsc() || this.isPk10() || this.isC11x5() || this.isKlsf()) {
          //双面龙排行、露珠图
          getDewdropList({
            lotteryGameId: _this.baseParams.gameId,
            typeCode: _this.baseParams.typeCode
          }).then(response => {
            // 双面龙排行数据获取
            _this.winLongRank = Array.from(response.currentData.winLongRank);
            //快乐彩临时判断
            if (_this.isDewdropShow && response.currentData.bigOrSmall.length != 0) {
              _this.dewdrop = response.currentData;
              _this.$nextTick(() => {
                const target = _this.$refs.refLuzhuChart;
                target && target.initData();
              });
            }
          }).catch(error => {
            console.log(`【error】:${error}`);
          });
        }
      },
      onBetClick: function () {
        this.hasBetDatas = allIsNumber(this.integrationArr);
      },
      submitBetbtn: function () {
        // console.log(this.proxyId)
        if (this.proxyId === 39) {
          getUrlByToken().then((res) => {
            const {currentStatus, currentData} = res
            if (currentStatus === 0 && currentData) {
              this.$message.error("没有登录，请登录");
              window.location.href = currentData.loginUrl
            }
          })
        } else{
          this.handleGetBetData();
        }
      },
      handleRemoveBet: function (index) {
        const _this = this;
        _this.$refs[this.currRef].removeBetByIndex(index);
        _this.$nextTick(function () {
          _this.handleGetBetData();
          if (_this.betDetails.length < 1) {
            _this.$refs['betDetailDialog'].close();
          }
        });
      },
      handleGetBetData: function () {
        this.betDetails = this.$refs[this.currRef].getBetList();
        if (this.betDetails.length) {
          this.$refs['betDetailDialog'].show();
        } else {
          this.$message.error("无效数据，请刷新重试");
        }
      },
      allBet(){
        let betAmount = '';
        if( this.chipMoney ){
          betAmount =  this.chipMoney;
        }else{
          betAmount =  prompt('请填写你想全选的金额');
        }

        if( betAmount ){
          let betArray = new Array();
          this.$refs[this.currRef].$el.querySelectorAll('[data-showcode]').forEach(()=>{
            betArray.push(betAmount);
          })
          this.hasBetDatas = true;
          this.$refs[this.currRef].$store.dispatch('setIntegrationArr', betArray);
        }
      },
      //筹码重填
      resetBet: function () {
        this.chipMoney = '';
        this.chipRotate = false;
        this.hasBetDatas = false;
        this.setIntegrationArr(Array(100))
      },
      defaultPopupMenu: function () {
        if (this.rankingShow) this.rankingShow = false;
        if (this.betRecordShow) this.betRecordShow = false;
        if (this.chipListDislogShow) this.chipListDislogShow = false;
        if (this.chipListDislogShow2) this.chipListDislogShow2 = false;
      },
      onDrawTimerChange: function (time) {
        this.showTime.drawEndTime = time;
      },
      onBetTimerChange: function (time) {
        this.showTime.betEndTime = time;
      },
      chipSetting: function (n) {
        this.chipMoney = parseInt(this.chipSettingData[n - 1]);
      },
      getPcddColor: function (i) {
        if ([0, 13, 14, 27].indexOf(i) !== -1) {
          return 'yellow';
        } else if ([1, 4, 7, 10, 16, 19, 22, 25].indexOf(i) !== -1) {
          return 'green';
        } else if ([2, 5, 8, 11, 17, 20, 23, 26].indexOf(i) !== -1) {
          return '';
        } else {
          return 'red_bg';
        }
      },
      //香港彩开奖号码颜色设置
      getMarkSixColor: function (index) {
        return this.isXgc() ? `${this.markSixballColor(this.tempLotteryNum[index])} pc_egg_ball` : '';
      },
      //香港彩波色类名计算
      markSixballColor: function (n) {
        if ([1, 2, 7, 8, 12, 13, 18, 19, 23, 24, 29, 30, 34, 35, 40, 45, 46].indexOf(Number(n)) !== -1) {
          return 'red_ball';
        } else if ([3, 4, 9, 10, 14, 15, 20, 25, 26, 31, 36, 37, 41, 42, 47, 48].indexOf(Number(n)) !== -1) {
          return 'blue_ball';
        } else if ([5, 6, 11, 16, 17, 21, 22, 27, 28, 32, 33, 38, 39, 43, 44, 49].indexOf(Number(n)) !== -1) {
          return 'green_ball';
        }
      },
      clearPageTimerObj: function () {
        this.clearGetLotteryInfo();
        this.clearLotteryTimer();
      },
      clearLotteryTimer: function () {
        const _this = this;
        _this.lotteryTimerList.forEach(item => {
          const target = _this.$refs[`timer${item.gameId}`];
          if (target) {
            target[0].stop('加载中');
          }
        });
        _this.showTime.betEndTime = "加载中";
        _this.showTime.drawEndTime = "加载中";
      },
      clearGetLotteryInfo: function () {
        if (this.lotteryIntervalId !== -1)
          clearInterval(this.lotteryIntervalId);
      }
    },
    computed: {
      ...mapGetters([
        'userId',
        'proxyId',
        'lotteryKgMenus',
        'integrationArr',
        'betRecordsByList',
        'betRecordsNotList', 'balance', 'account',
      ])
    },
    beforeRouteEnter(to, from, next){
      if (!from.path)  return false;
      next(vm => {
        if (!to.params.typeId && vm.lotteryKgMenus.length > 0) {
          const {typeId, typeCode, children} = vm.lotterKygMenus[0];
          vm.$router.push({
            name: 'lotteryKgList', params: {
              typeId: typeId,
              typeCode: typeCode,
              gameId: children[0].gameId,
              gameCode: children[0].gameCode,
              gameName: children[0].gameName
            }
          })
        } else {
          const options = {
            typeId: to.params.typeId,
            typeCode: to.params.typeCode,
            gameId: to.params.gameId,
            gameCode: to.params.gameCode,
            gameName: to.params.gameName
          };
          vm._setBaseOptions(options);
          vm._pageInit();
        }

        setTimeout(function () {
          $('body,html').animate({scrollTop: 0}, 300)
        }, 100);
      });
    },
    beforeRouteLeave(to, from, next){
      this.clearLastAnimateBallsTimer();
      this.clearPageTimerObj();
      next(true);
    },
    watch: {
      chipMoney: function (val) {
        this.chipMoney = isNumber(val) ? val : '';
      },
      lotteryTimerList: function (val) {
        this.$nextTick(function () {
          this.clearLotteryTimer();
          this.lotteryTimerList = val;
        });
      },
      // 如果路由有变化，会再次执行该方法
      $route (to, from) {
        let _this = this;
        if (to.path !== from.path) {
          _this.clearPageTimerObj();
          const {typeId, typeCode, gameId, gameCode, gameName} = _this.$route.params;
          const options = {typeId: typeId, typeCode: typeCode, gameId: gameId, gameCode: gameCode, gameName: gameName};
          _this.baseParams.playCode = '';
          _this.baseParams.playId = '';
          _this._setBaseOptions(options);
          _this._pageInit();
        }
      }
    }
  }
</script>
<style scoped="">
  .fade-enter-active, .fade-leave-active {
    transition: opacity .5s;
  }

  .fade-enter, .fade-leave-to /* .fade-leave-active below version 2.1.8 */
  {
    opacity: 0;
  }
  .kl8Number{
    padding-top: 5px;
    direction: ltr;
    text-align: left;
  }
  .kl8Number>li{
    width: 35px;
    height: 35px;
    text-align: center;
    line-height: 35px;
    font-size: 16px;
  }
  .kl8Number>li:last-child{
      background: #1aa3f1 !important;
  }
  .lottery-type-classify{
    min-height: 32.5px;
  }
</style>
