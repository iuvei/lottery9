<template>
  <div class="special_code orthocode" @keyup="contentKeyUpFun">
    <div class="bet_content_data clearfix">
      <p v-for="i in firstDataList.length" :key="i">
        <span>号</span>
        <span>赔率</span>
        <span>下注</span>
      </p>
      <template v-if="firstDataList.length>0">
        <ul class="clearfix mark_six_ball" v-for="(item,x) in firstDataList" :key="'zheng_'+x">
          <template v-for="(info,y) in item">
            <template v-if="info && info.showName">
              <li class="ripple red_ripple"
                  :class="!integrationArr[y + x*10]?'':'cur'"
                  @click="handleAddIntegration(y + x*10)"
                  :ref="'other_code_'+getIndex(x,y)"
                  :data-x="0" :data-y="getIndex(x,y)"
                  :data-showCode="info.showCode"
                  :data-showName="info.showName"
                  :key="y">
              <span class="ranking_type">
                <span :class="info.ballColor">{{info.showName}}</span>
                <span>{{info.ruleOdds ||'0.00'}}</span>
              </span>
                <input type="text" v-model="integrationArr[y + x*10]">
              </li>
            </template>
            <template v-else>
              <li :key="y"></li>
            </template>
          </template>
        </ul>
      </template>

      <template v-if="secondDataList.length>0">
        <ul class="clearfix">
          <template v-for="(item,i) in secondDataList">
            <template v-if="item && item.showName">
              <li class="ripple red_ripple"
                  :class="!integrationArr[i + 49]?'':'cur'"
                  :ref="`other_code_${getRuleIdIndex(i+49)}`"
                  :data-x="1" :data-y="getRuleIdIndex(i)"
                  :data-showCode="item.showCode"
                  :data-showName="item.showName"
                  :key="i">
              <span @click="handleAddIntegration(i + 49)" class="ranking_type">
                <span>{{item.showName}}</span>
                <span>{{item.ruleOdds ||'0.00'}}</span>
              </span>
                <input type="text" v-model="integrationArr[i + 49]">
              </li>
            </template>
            <template v-else>
              <li :key="i"></li>
            </template>
          </template>
        </ul>
      </template>

    </div>
  </div>

</template>
<script>
  import {isNumber} from '../../../../../utils/index'
  import setPageData from '../../setPageData/index'
  import defineData from './defineData.js'
  import {mapGetters} from 'vuex'
  export default{
    name: 'HongkonOtherCode',
    props: {
      betAmount: {
        type: [String, Number],
        default: ''
      },
      renderData: {
        type: Array,
        default: function () {
          return []
        }
      }
    },
    data () {
      return {
        newArray:[],
        firstDataList: [
          [{}, {}, {}, {}, {}, {}, {}, {}, {}, {}],
          [{}, {}, {}, {}, {}, {}, {}, {}, {}, {}],
          [{}, {}, {}, {}, {}, {}, {}, {}, {}, {}],
          [{}, {}, {}, {}, {}, {}, {}, {}, {}, {}],
          [{}, {}, {}, {}, {}, {}, {}, {}, {}, {}]],
        secondDataList: setPageData['lottery']['otherCode'][0],
        title: '正码',
      }
    },
    watch: {
      renderData: function (val) {
        const _this = this;
        if (val && val.length > 0) {
          _this.$nextTick(function () {
            _this.dealData();
            // _this.parseFirstData();
            // _this.parseSecondData();
          });
        }
      }
    },
    computed: {
      ...mapGetters([
        'integrationArr'
      ])
    },
    mounted() {
      this.dealData();
    },
    methods: {
      init(){
        let m=1,key=[],value=[];
        while ( m < 50 ) {
          key.push('zm-' + m);
          value.push(m);
          m++;
        }
        key[49]='';

        this.newArray = setDataArray(key,value);

        //构建数据对象，传入showCode数组及showName数组，长度须一致
        function setDataArray(key,value){
          let newArray = new Array()
          for(let i = 0 ,len = key.length;i<len;i++){
            newArray[i] = new Object();
            newArray[i].showCode = key[i];
            newArray[i].showName = value[i];
            newArray[i].ruleOdds = '';
            newArray[i].ballColor = '';
          }
          return newArray;
        }
      },
      dealData(){//处理传过来的数据
        const _this = this;
        this.init();
        this.newArray.dealData(this.renderData);

        //处理数组，显示为每几个一组
        this.newArray.forEach(function(item,index){
          item.ballColor = defineData.getBallColor(item.showName);//模拟后台返回的色值配置
          if( !(index%10) ){
            _this.firstDataList.splice(index/10,1,_this.newArray.slice(index,index+10));//使用该方法赋值，是vue视图渲染不接受常规赋值渲染，因为js特性如此（指针）
          }
        });

        //处理第二个数组
        this.secondDataList.dealData(this.renderData);
      },
      parseFirstData: function () {
        if (this.renderData.length > 0) {
          const {gameRuleDetailList} = this.renderData[0];
          if (!gameRuleDetailList && !gameRuleDetailList instanceof Array) return;
          let index = 0;
          for (let i = 0; i < gameRuleDetailList.length; i++) {
            if (index < this.firstDataList.length) {
              const {showName} = gameRuleDetailList[i],
                nameArr = showName.indexOf('#') !== -1 ? showName.split('#') : [];
              if (nameArr.length > 1) {
                gameRuleDetailList[i].showName = nameArr[0];
                gameRuleDetailList[i].ballColor = `${nameArr[1]}_ball`;
                this.firstDataList[index].splice((i + 10) % 10, 1, gameRuleDetailList[i]);
                if ((i + 1) % 10 === 0) {
                  index++;
                }
              }
            }
          }
        }
      },
      parseSecondData: function () {
        if (this.renderData.length > 1) {
          const {gameRuleDetailList} = this.renderData[1];
          if (!gameRuleDetailList && !gameRuleDetailList instanceof Array) return;
          for (let i = 0; i < gameRuleDetailList.length; i++) {
            if (i < this.secondDataList.length) {
              this.secondDataList.splice(i, 1, gameRuleDetailList[i]);
            }
          }
        }
      },
      //香港彩波色类名计算
      markSixballColor: function (n) {
        switch (true) {
          case n == 1 || n == 2 || n == 7 || n == 8 || n == 12 || n == 13 || n == 18 || n == 19 || n == 23 || n == 24 || n == 29 || n == 30 || n == 34 || n == 35 || n == 40 || n == 45 || n == 46:
            return "red_ball";
            break;
          case n == 3 || n == 4 || n == 9 || n == 10 || n == 14 || n == 15 || n == 20 || n == 25 || n == 26 || n == 31 || n == 36 || n == 37 || n == 41 || n == 42 || n == 47 || n == 48:
            return "blue_ball";
            break;
          case n == 5 || n == 6 || n == 11 || n == 16 || n == 17 || n == 21 || n == 22 || n == 27 || n == 28 || n == 32 || n == 33 || n == 38 || n == 39 || n == 43 || n == 44 || n == 49:
            return "green_ball";
            break;
        }
      },
      handleAddIntegration: function (index) {
        this.integrationArr.splice(index, 1, this.integrationArr[index] ? undefined : this.betAmount);
        this.onBetClick();
      },
      validationBetAmount: function () {
        for (let i = 0; i < this.integrationArr.length; i++) {
          let singleChip = this.integrationArr[i];
          if (singleChip !== undefined && (!isNumber(singleChip) || singleChip * 1 === 0)) {
            this.integrationArr.splice(i, 1, undefined);
          }
        }
      },
      getIndex: function (i, n) {
        return (n + i * 10);
      },
      getRuleIdIndex: function (i) {
        return i;
      },
      onBetClick: function () {
        this.$emit('onBetClick');
      },
      contentKeyUpFun: function () {
        this.validationBetAmount();
        this.onBetClick();
      },
      removeBetByIndex: function (index) {
        this.integrationArr.splice(index, 1, undefined);
        this.onBetClick();
      },
      getBetList: function () {
        const _this = this;
        let arr = [];
        for (let i = 0; i < this.integrationArr.length; i++) {
          const amount = this.integrationArr[i];
          if (amount !== undefined && amount !== '') {
            const target = _this.$refs[`other_code_${i}`];
            if (target) {
              let showName;
              const renderDataItem = _this.renderData.filter((item,index)=>{
                if( item.showCode == target[0].getAttribute('data-showCode') ){
                  showName = target[0].getAttribute('data-showName');
                  return true;
                }
                 return false;
              })[0];

              if(renderDataItem){
                const  {odds,showCode,typeName} = renderDataItem;
                arr.push({
                  title: typeName,
                  ruleName: showName,
                  showCode:showCode,
                  odds: odds,
                  amount: amount,
                  index: i
                });
              }
            }
          }
        }
        return arr;
      },
    }
  }
</script>
