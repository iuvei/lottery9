//球颜色和特肖为一年改一次，所以统一在此处设定
export default {
    getBallColor:(number)=>{
        //共49项，0代表红，1代表蓝，2代表绿
        let colorArray = [0,0,1,1,2,2,0,0,1,1,2,0,0,1,1,2,2,0,0,1,2,2,0,0,1,1,2,2,0,0,1,2,2,0,0,1,1,2,2,0,1,1,2,2,0,0,1,1,2];
        return colorArray[number-1] == 0?'red_ball':colorArray[number-1] == 1?'blue_ball':'green_ball';
    },
    getAnimalsNumbers:(type)=>{
        //传入对应的生肖，返回自定义的对应生肖数组
        let newArray;
        switch (type) {
            case '鼠':
                newArray = [11,23,35,47];
                break;
            case '牛':
                newArray = [10,22,34,46];
                break;
            case '虎':
                newArray = [9,21,33,45];
                break;
            case '兔':
                newArray = [8,20,32,44];
                break;
            case '龙':
                newArray = [7,19,31,43];
                break;
            case '蛇':
                newArray = [6,18,30,42];
                break;
            case '马':
                newArray = [5,17,29,41];
                break;
            case '羊':
                newArray = [4,16,28,40];
                break;
            case '猴':
                newArray = [3,15,27,39];
                break;
            case '鸡':
                newArray = [2,14,26,38];
                break;
            case '狗':
                newArray = [1,13,25,37,49];
                break;
            case '猪':
                newArray = [12,24,36,48];
                break;
            default:
                throw new Error('传入的参数必须为十二生肖之一的中文文字');
                break;
        }
        return newArray;
    },
    getFiveElements:(type)=>{
        //传入对应的五行，返回自定义的对应五行数组
        let newArray;
        switch (type) {
            case '金':
                newArray = ['01','06','11','16','21','26','31','36','41','46'];
                break;
            case '木':
                newArray = ['02','07',12,17,22,27,32,37,42,47];
                break;
            case '水':
                newArray = ['03','08',13,18,23,28,33,38,43,48];
                break;
            case '火':
                newArray = ['04','09',14,19,24,29,34,39,44,49];
                break;
            case '土':
                newArray = ['05',10,15,20,25,30,35,40,45];
                break;
            default:
                throw new Error('传入的参数必须为五行之一的中文文字');
                break;
        }
        return newArray;
    },
    getHalfWaves:(type)=>{
        //传入对应的五行，返回自定义的对应五行数组
        let newArray;
        switch (type) {
            case '红单':
                newArray = ['01','07',13,19,23,29,35,45];
                break;
            case '红双':
                newArray = ['02','08',12,18,24,30,34,40,46];
                break;
            case '红大':
                newArray = ['29',30,34,35,40,45,46];
                break;
            case '红小':
                newArray = ['01','02','07','08',12,13,18,19,23,24];
                break;
            case '蓝单':
                newArray = ['03','09',15,25,31,37,41,47];
                break;
            case '蓝双':
                newArray = ['04',10,14,20,26,36,42,48];
                break;
            case '蓝大':
                newArray = [25,26,31,36,37,41,42,47,48];
                break;
            case '蓝小':
                newArray = ['03','04','09',10,14,15,20];
                break;
            case '绿单':
                newArray = ['05',11,17,21,27,33,39,43];
                break;
            case '绿双':
                newArray = ['06',16,22,28,32,38,44];
                break;
            case '绿大':
                newArray = [27,28,32,33,38,39,43,44];
                break;
            case '绿小':
                newArray = ['05','06',11,16,17,21,22];
                break;
            default:
                throw new Error('传入的参数必须为半波之一的中文文字');
                break;
        }
        return newArray;
    }

    
}