<template>
  <div class="game-play-content clearfix specialCodeHeadAnd7" @keyup="contentKeyUpFun">
    <template v-if="firstDataIsNotNull()">
      <div class="bet_content_data ">
        <p v-for="i in 4" :key="i">
          <span>号</span>
          <span>赔率</span>
          <span>下注</span>
        </p>
        <ul class="clearfix">
          <template v-for="(item,i) in firstDataList">
            <template v-if="item && item.showName">
              <li class="ripple red_ripple"
                  :class="!integrationArr[i]?'':'cur'"
                  @click="handleAddIntegration(i)"
                  :ref="`special_code_head${i}`"
                  :data-x="0" :data-y="i" 
                  :data-showCode="item.showCode" 
                  :data-showName="item.showName"
                  :key="i">
                  <span class="ranking_type">
                    <span>{{item.showName}}</span>
                    <span>{{item.ruleOdds ||'0.00'}}</span>
                  </span>
                <input type="text" v-model="integrationArr[i]">
              </li>
            </template>
            <template v-else>
              <li :key="i"><span class="ranking_type"></span></li>
            </template>
          </template>
        </ul>
      </div>
    </template>
    <template v-if="secondDataIsNotNull()">
      <div class="bet_content_data ">
        <p v-for="i in Math.ceil(secondDataList.length/3)" :key="i">
          <span>号</span>
          <span>赔率</span>
          <span>下注</span>
        </p>
        <ul class="clearfix">
          <template v-for="(item,i) in secondDataList">
            <template v-if="item && item.showName">
              <li class="ripple red_ripple"
                  :class="!integrationArr[i + 6]?'':'cur'"
                  :ref="`special_code_head${i+6}`"
                  :data-x="1" :data-y="i" 
                  :data-showCode="item.showCode" 
                  :data-showName="item.showName"
                  :key="i">
                  <span @click="handleAddIntegration(i + 6)" class="ranking_type">
                    <span>{{item.showName}}</span>
                    <span>{{item.ruleOdds ||'0.00'}}</span>
                  </span>
                <input type="text" v-model="integrationArr[i + 6]">
              </li>
            </template>
            <template v-else>
              <li :key="i"><span class="ranking_type"></span></li>
            </template>
          </template>
        </ul>
      </div>
    </template>
  </div>
</template>
<script>
  import {isNumber} from '../../../../../utils/index'
  import setPageData from '../../setPageData/index'
  import {mapGetters} from 'vuex'
  export default{
    name: 'hongkon-special-code',
    props: {
      betAmount: {
        type: [String, Number],
        default: ''
      },
      renderData: {
        type: Array,
        default: function () {
          return []
        }
      }
    },
    watch: {
      renderData: function (val) {
        const _this = this;
        if (val && val.length > 0) {
          _this.$nextTick(function () {
            _this.dealData();
            // _this.parseFirstData();
            // _this.parseSecondData();
          });
        }
      }
    },
    data () {
      return {
        firstDataList: setPageData['lottery']['HongkonSpecialCodeHeadEnd'][0],
        secondDataList: setPageData['lottery']['HongkonSpecialCodeHeadEnd'][1]
      }
    },
    computed: {
      ...mapGetters([
        'integrationArr'
      ])
    },
    methods: {
      dealData(){//处理传过来的数据
        //处理数组
        this.firstDataList.dealData(this.renderData);
        this.secondDataList.dealData(this.renderData);
      },
      firstDataIsNotNull: function () {
        return this.firstDataList && this.firstDataList.length > 0;
      },
      secondDataIsNotNull: function () {
        return this.secondDataList && this.secondDataList.length > 0;
      },
      parseFirstData: function () {
        if (this.renderData.length > 1) {
          const {gameRuleDetailList} = this.renderData[0];
          if (!gameRuleDetailList && !gameRuleDetailList instanceof Array) return;
          for (let i = 0; i < gameRuleDetailList.length; i++) {
            if (i < this.firstDataList.length) {
              this.firstDataList.splice(i, 1, gameRuleDetailList[i]);
            }
          }
        }
      },
      parseSecondData: function () {
        if (this.renderData.length > 1) {
          const {gameRuleDetailList} = this.renderData[1];
          if (!gameRuleDetailList && !gameRuleDetailList instanceof Array) return;
          for (let i = 0; i < gameRuleDetailList.length; i++) {
            if (i < this.secondDataList.length) {
              this.secondDataList.splice(i, 1, gameRuleDetailList[i]);
            }
          }
        }
      },
      handleAddIntegration: function (index) {
        this.integrationArr.splice(index, 1, this.integrationArr[index] ? undefined : this.betAmount);
        this.onBetClick();
      },
      validationBetAmount: function () {
        for (let i = 0; i < this.integrationArr.length; i++) {
          let singleChip = this.integrationArr[i];
          if (singleChip !== undefined && (!isNumber(singleChip) || singleChip * 1 === 0)) {
            this.integrationArr.splice(i, 1, undefined);
          }
        }
      },
      onBetClick: function () {
        this.$emit('onBetClick');
      },
      getIndex: function (i, n) {
        return (n + i * 10);
      },
      contentKeyUpFun: function () {
        this.validationBetAmount();
        this.onBetClick();
      },
      removeBetByIndex: function (index) {
        this.integrationArr.splice(index, 1, undefined);
        this.onBetClick();
      },
      getBetList: function () {
        const _this = this, arr = [];
        for (let i = 0; i < _this.integrationArr.length; i++) {
          const amount = _this.integrationArr[i];
          if (amount !== undefined && amount !== '') {
            const target = _this.$refs[`special_code_head${i}`];
            if (target) {
              let showName;
              const renderDataItem = _this.renderData.filter((item,index)=>{
                if( item.showCode == target[0].getAttribute('data-showCode') ){
                  showName = target[0].getAttribute('data-showName');
                  return true;
                }
                 return false;
              })[0];
              
              if(renderDataItem){
                const  {odds,showCode,typeName} = renderDataItem;
                arr.push({
                  title: typeName,
                  ruleName: showName,
                  showCode:showCode,
                  odds: odds,
                  amount: amount,
                  index: i
                });
              }
            }
          }
        }
        console.log(arr)
        return arr;
      },
    }
  }
</script>
<style scoped="">
  .specialCodeHeadAnd7 .bet_content_data  p{
    width: 198px;
    float: left;
    text-align: left;
  }
  .specialCodeHeadAnd7 .bet_content_data .mark_six_ball{
    width: 198px;
    float: left;
  }
  .specialCodeHeadAnd7 .bet_content_data  p span:nth-child(1){
    margin: 0 20px 0 25px;
  }
  .specialCodeHeadAnd7 .bet_content_data  p span:nth-child(2){
    margin-right: 25px;
  }
  .kg_content .game-play-content input{
    float: right;
    margin-top: 8px;
    margin-right: 8px;
  }
</style>
