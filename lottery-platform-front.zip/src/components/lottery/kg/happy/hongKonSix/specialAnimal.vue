<template>
  <div class="special_animal" @keyup="contentKeyUpFun">
    <div class="bet_content_data clearfix" v-for="(item,x) in firstDataList" :key="x">
      <p>
        <span>生肖</span>
        <span>号</span>
        <span>赔率</span>
        <span>金额</span>
      </p>
      <ul class="clearfix mark_six_ball">
        <template v-for="(info,y) in item">
          <template v-if="info && info.showName">
            <li class="ripple red_ripple"
                :class="!integrationArr[y + x*6]?'':'cur'"
                @click="handleAddIntegration(getIndex(x,y))"
                :ref="`special_animal_${getIndex(x,y)}`"
                :data-x="0" :data-y="getIndex(x,y)" 
                :data-showCode="info.showCode"
                :data-showName="info.showName"
                :key="y">
                <span class="ranking_type">
                  <span>{{info.showName}}</span>
                  <span v-for="(numberColor,key) in info.numberColors" :key="key" class="markSixBall" :class="numberColor.color">{{numberColor.number}}</span>
                  <span>{{info.ruleOdds ||'0.00'}}</span>
                </span>
              <input type="text" v-model="integrationArr[y + x*6]">
            </li>
          </template>
          <template v-else>
            <li class="ripple red_ripple" :key="y"><span class="ranking_type"></span></li>
          </template>
        </template>
      </ul>
    </div>
  </div>
</template>
<script>
  import {isNumber} from '../../../../../utils/index'
  import setPageData from '../../setPageData/index'
  import defineData from './defineData.js'
  import {mapGetters} from 'vuex'
  export default{
    name: 'hongkon-special-animal',
    props: {
      betAmount: {
        type: [String, Number],
        default: ''
      },
      renderData: {
        type: Array,
        default: function () {
          return []
        }
      }
    },
    watch: {
      renderData(val){
        const _this = this;
        if (val && val.length > 0) {
          _this.$nextTick(function () {
            // _this.parseFirstData();
            _this.dealData();
          });
        }
      }
    },
    data () {
      return {
        firstDataList: setPageData['lottery']['specialAnimal'][0]
      }
    },
    computed: {
      ...mapGetters([
        'integrationArr'
      ])
    },
    mounted() {
      this.dealData();
    },
    methods: {
      dealData(){//处理传过来的数据
        const _this = this;
        this.firstDataList[0].dealData(this.renderData);
        this.firstDataList[1].dealData(this.renderData);
        
        //给对应数据渲染上数字和颜色值
        this.firstDataList[0].forEach((element,index) => {
          let numbers =  defineData.getAnimalsNumbers(element.showName);
          if( numbers && numbers.length ){
            element.numberColors = new Array();
            numbers.forEach((elementA,indexA)=>{
              element.numberColors[indexA] = {
                number: elementA, 
                color: defineData.getBallColor(elementA)
              }
            });
          }else{
            throw new Error('未知错误');
          }
        });

        this.firstDataList[1].forEach((element,index) => {
          let numbers =  defineData.getAnimalsNumbers(element.showName);
          if( numbers && numbers.length ){
            element.numberColors = new Array();
            numbers.forEach((elementA,indexA)=>{
              element.numberColors[indexA] = {
                number: elementA, 
                color: defineData.getBallColor(elementA)
              }
            });
          }else{
            throw new Error('未知错误');
          }
        });

      },
      parseFirstData: function () {
        if (this.renderData.length > 0) {
          const {gameRuleDetailList} = this.renderData[0];
          if (!gameRuleDetailList && !gameRuleDetailList instanceof Array) return;
          let index = 0;
          for (let i = 0; i < gameRuleDetailList.length; i++) {
            if (index < this.firstDataList.length) {
              const {showName} = gameRuleDetailList[i];
              const nameArr = showName.indexOf('=') ? showName.split('=') : [];
              if (nameArr.length > 1) {
                gameRuleDetailList[i].showName = nameArr[0];
                const balls = nameArr[1].split(',');
                for (let j = 0; j < balls.length; j++) {
                  const numberColors = balls[j].indexOf('#') !== -1 ? balls[j].split('#') : [];
                  if (numberColors.length > 1) {
                    balls[j] = Object.assign({}, {number: numberColors[0], color: `${numberColors[1]}_ball`});
                  } else {
                    balls[j] = Object.assign({}, {number: '', color: ''});
                  }
                }
                gameRuleDetailList[i].numberColors = balls;
              }
              this.firstDataList[index].splice((i + 6) % 6, 1, gameRuleDetailList[i]);
              if ((i + 1) % 6 === 0) {
                index++;
              }
            }
          }
        }
      },
      handleAddIntegration: function (index) {
        this.integrationArr.splice(index, 1, this.integrationArr[index] ? undefined : this.betAmount);
        this.onBetClick();
      },
      validationBetAmount: function () {
        for (let i = 0; i < this.integrationArr.length; i++) {
          let singleChip = this.integrationArr[i];
          if (singleChip !== undefined && (!isNumber(singleChip) || singleChip * 1 === 0)) {
            this.integrationArr.splice(i, 1, undefined);
          }
        }
      },
      onBetClick: function () {
        this.$emit('onBetClick');
      },
      getIndex: function (x, y) {
        return (y + x * 6);
      },
      contentKeyUpFun: function () {
        this.validationBetAmount();
        this.onBetClick();
      },
      removeBetByIndex: function (index) {
        this.integrationArr.splice(index, 1, undefined);
        this.onBetClick();
      },
      getBetList: function () {
        const _this = this;
        let arr = [];
        for (let i = 0; i < this.integrationArr.length; i++) {
          const amount = this.integrationArr[i];
          if (amount !== undefined && amount !== '') {
            const target = _this.$refs["special_animal_" + i];
            if (target) {
              let showName;
              const renderDataItem = _this.renderData.filter((item,index)=>{
                if( item.showCode == target[0].getAttribute('data-showCode') ){
                  showName = target[0].getAttribute('data-showName');
                  return true;
                }
                 return false;
              })[0];
              
              if(renderDataItem){
                const  {odds,showCode,typeName} = renderDataItem;
                arr.push({
                  title: typeName,
                  ruleName: showName,
                  showCode:showCode,
                  odds: odds,
                  amount: amount,
                  index: i
                });
              }
            }
          }
        }
        return arr;
      },
    }
  }
</script>
<style scoped>
.game-play-content .bet_content_data li span > span:last-child {
  margin-right: 20px;
}
</style>

