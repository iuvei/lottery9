<template>
  <div class="game-play-content clearfix specialCodeHeadAnd7" @keyup="contentKeyUpFun">
    <template v-if="firstDataIsNotNull()">
      <div class="bet_content_data clearfix">
        <p v-for="(_,i) in firstDataList.length" :key="i">
          <span>号</span>
          <span>赔率</span>
          <span>下注</span>
        </p>
        <ul class="clearfix mark_six_ball" v-for="(item,x) in firstDataList" :key="'six_'+x">
          <template v-for="(info,y) in item">
            <template v-if="info && info.showName">
              <li class="ripple red_ripple"
                  :class="!integrationArr[y + x*8]?'':'cur'"
                  @click="handleAddIntegration(y + x*8)"
                  :data-btid="info.id"
                  :ref="`qi_ma_${getIndex(x,y)}`"
                  :data-x="0" :data-y="getIndex(x,y)" 
                  :data-showCode="info.showCode" 
                  :data-showName="info.showName"
                  :key="y">
                  <span class="ranking_type">
                    <span :class="info.ballColor">{{info.showName}}</span>
                    <span>{{info.ruleOdds ||'0.00'}}</span>
                  </span>
                <input type="text" v-model="integrationArr[y + x*8]">
              </li>
            </template>
            <template v-else>
              <li class="ripple red_ripple" :key="y">
                <span class="ranking_type"></span>
              </li>
            </template>
          </template>
        </ul>
      </div>
    </template>
  </div>
</template>
<script>
  import {isNumber} from '../../../../../utils/index'
  import setPageData from '../../setPageData/index'
  import {mapGetters} from 'vuex'
  export default{
    name: 'hongkon-special-code',
    props: {
      betAmount: {
        type: [String, Number],
        default: ''
      },
      renderData: {
        type: Array,
        default: function () {
          return []
        }
      }
    },
    watch: {
      renderData: function (val) {
        const _this = this;
        if (val && val.length > 0) {
          _this.$nextTick(function () {
            _this.dealData();
            // _this.parseFirstData();
//            _this.parseSecondData();
          });
        }
      }
    },
    data () {
      return {
        firstDataList: setPageData['lottery']['HongkonSpecialCodeQima'][0],
      }
    },
    computed: {
      ...mapGetters([
        'integrationArr'
      ])
    },
    methods: {
      dealData(){//处理传过来的数据
        const _this = this;
        //处理数组，显示为每几个一组
        this.firstDataList.forEach(function(item,index){
          item.dealData(_this.renderData);
        });
      },
      firstDataIsNotNull: function () {
        return this.firstDataList && this.firstDataList.length > 0;
      },
      parseFirstData: function () {
        if (this.renderData.length > 0) {
          const {gameRuleDetailList} = this.renderData[0];
          if (!gameRuleDetailList && !gameRuleDetailList instanceof Array) return;
          let index = 0;
          for (let i = 0; i < gameRuleDetailList.length; i++) {
            if (index < this.firstDataList.length) {
                this.firstDataList[index].splice((i + 8) % 8, 1, gameRuleDetailList[i]);
                if ((i + 1) % 8 === 0) {
                  index++;
                }
            }
          }

        }
      },
//      parseSecondData: function () {
//        if (this.renderData.length > 1) {
//          const {gameRuleDetailList} = this.renderData[1];
//          if (!gameRuleDetailList && !gameRuleDetailList instanceof Array) return;
//          for (let i = 0; i < gameRuleDetailList.length; i++) {
//            if (i < this.secondDataList.length) {
//              this.secondDataList.splice(i, 1, gameRuleDetailList[i]);
//            }
//          }
//        }
//      },
      handleAddIntegration: function (index) {
        this.integrationArr.splice(index, 1, this.integrationArr[index] ? undefined : this.betAmount);
        this.onBetClick();
      },
      validationBetAmount: function () {
        for (let i = 0; i < this.integrationArr.length; i++) {
          let singleChip = this.integrationArr[i];
          if (singleChip !== undefined && (!isNumber(singleChip) || singleChip * 1 === 0)) {
            this.integrationArr.splice(i, 1, undefined);
          }
        }
      },
      onBetClick: function () {
        this.$emit('onBetClick');
      },
      getIndex: function (i, n) {
        return (n + i * 8);
      },
      contentKeyUpFun: function () {
        this.validationBetAmount();
        this.onBetClick();
      },
      removeBetByIndex: function (index) {
        this.integrationArr.splice(index, 1, undefined);
        this.onBetClick();
      },
      getBetList: function () {
        const _this = this, arr = [];
        for (let i = 0; i < _this.integrationArr.length; i++) {
          const amount = _this.integrationArr[i];
          if (amount !== undefined && amount !== '') {
            const target = _this.$refs[`qi_ma_${i}`];
            if (target) {
              let showName;
              const renderDataItem = _this.renderData.filter((item,index)=>{
                if( item.showCode == target[0].getAttribute('data-showCode') ){
                  showName = target[0].getAttribute('data-showName');
                  return true;
                }
                 return false;
              })[0];
              
              if(renderDataItem){
                const  {odds,showCode,typeName} = renderDataItem;
                arr.push({
                  title: typeName,
                  ruleName: showName,
                  showCode:showCode,
                  odds: odds,
                  amount: amount,
                  index: i
                });
              }
            }
          }
        }
        return arr;
      },
    }
  }
</script>
<style scoped="">
  .specialCodeHeadAnd7 .bet_content_data  p{
    width: 198px;
    float: left;
  }
  .specialCodeHeadAnd7 .bet_content_data .mark_six_ball{
    width: 198px;
    float: left;
  }
  .specialCodeHeadAnd7 div:first-child p span:first-child {
    margin: 0 26px 0 -11px;
  }
  .specialCodeHeadAnd7 div:first-child p span:nth-of-type(2) {
    margin-right: 26px;
    position: relative;
    left: -8px;
  }
  .kg_content .game-play-content input{
    float: right;
    margin-top: 8px;
    margin-right: 8px;
  }
  .mark_six .ranking_type span:first-of-type{
    width: 36px;
  }
</style>
