<template>
  <div class="special_animal" @keyup="contentKeyUpFun">
    <div class="bet_content_data clearfix">
      <p>
        <span></span>
        <span>号</span>
        <span>赔率</span>
        <span>金额</span>
      </p>
      <ul class="clearfix">
        <template v-for="(item,i) in firstDataList">
          <template v-if="item && item.showName">
            <li class="ripple red_ripple"
                :class="!integrationArr[i]?'':'cur'"
                @click="handleAddIntegration(i)"
                :ref="`wuxing_banbo_${i}`"
                :data-x="0" :data-y="i" 
                :data-showCode="item.showCode"
                :data-showName="item.showName"
                :key="i">
                  <span class="ranking_type">
                    <span>{{item.showName}}</span>
                  <span v-for="(numberColor,key) in item.numberColors" :key="key" class="markSixBall" :class="numberColor.color">{{numberColor.number}}</span>
                    <span>{{item.ruleOdds ||'0.00'}}</span>
                  </span>
              <input type="text" v-model="integrationArr[i]">
            </li>
          </template>
          <template v-else>
            <li :key="i"><span class="ranking_type"></span></li>
          </template>
        </template>
      </ul>
    </div>
  </div>
</template>
<script>
  import {isNumber} from '../../../../../utils/index'
  import setPageData from '../../setPageData/index'
  import defineData from './defineData.js'
  import {mapGetters} from 'vuex'
  export default{
    name: 'hongkon-special-animal',
    props: {
      betAmount: {
        type: [String, Number],
        default: ''
      },
      renderData: {
        type: Array,
        default: function () {
          return []
        }
      },
      currCode: {
        type: String
      }
    },
    watch: {
      renderData(val){
        const _this = this;
        if (val && val.length > 0) {
          _this.$nextTick(function () {
            _this.dealData();
            //_this.parseFirstData();
          });
        }
      },
      currCode(){
        this.dealData();
      }
    },
    data () {
      return {
        firstDataList:''
      }
    },
    computed: {
      ...mapGetters([
        'integrationArr'
      ])
    },
    mounted() {
      this.dealData();
    },
    methods: {
      dealData(){//处理传过来的数据
        const _this = this ;
        let defineRenderData;
        //如果为五行，则加载xxx，如果为半波则...
        if( this.currCode == 'klc_wx' ){
          defineRenderData = setPageData['lottery']['wuxingAndBanbo'][0];
        }else{
          defineRenderData = setPageData['lottery']['wuxingAndBanbo'][1];
        }
        this.firstDataList =  defineRenderData;
        this.firstDataList.dealData(this.renderData);
        
        //给对应数据渲染上数字和颜色值
        this.firstDataList.forEach((element,index) => {
          let numbers;
          if( this.currCode == 'klc_wx' ){
            numbers =  defineData.getFiveElements(element.showName);
          }else{
            numbers =  defineData.getHalfWaves(element.showName);
          }
          if( numbers && numbers.length ){
            element.numberColors = new Array();
            numbers.forEach((elementA,indexA)=>{
              element.numberColors[indexA] = {
                number: elementA, 
                color: defineData.getBallColor(elementA)
              }
            });
          }else{
            throw new Error('未知错误');
          }
        });
      },
      parseFirstData: function () {
        this.firstDataList = [{}, {}, {}, {}, {}];
        if (this.renderData.length > 0) {
          const {gameRuleDetailList} = this.renderData[0];
          if (!gameRuleDetailList && !gameRuleDetailList instanceof Array) return;
          for (let i = 0; i < gameRuleDetailList.length; i++) {
              const {showName} = gameRuleDetailList[i];
              const nameArr = showName.indexOf('=') ? showName.split('=') : [];
              if (nameArr.length > 1) {
                gameRuleDetailList[i].showName = nameArr[0];
                const balls = nameArr[1].split(',');
                for (let j = 0; j < balls.length; j++) {
                  const numberColors = balls[j].indexOf('#') !== -1 ? balls[j].split('#') : [];
                  if (numberColors.length > 1) {
                    balls[j] = Object.assign({}, {number: numberColors[0], color: `${numberColors[1].trim()}_ball`});
                  } else {
                    balls[j] = Object.assign({}, {number: '', color: ''});
                  }
                }
                gameRuleDetailList[i].numberColors = balls;
              }
              this.firstDataList.splice(i, 1, gameRuleDetailList[i]);
          }

        }
      },
      handleAddIntegration: function (index) {
        this.integrationArr.splice(index, 1, this.integrationArr[index] ? undefined : this.betAmount);
        this.onBetClick();
      },
      validationBetAmount: function () {
        for (let i = 0; i < this.integrationArr.length; i++) {
          let singleChip = this.integrationArr[i];
          if (singleChip !== undefined && (!isNumber(singleChip) || singleChip * 1 === 0)) {
            this.integrationArr.splice(i, 1, undefined);
          }
        }
      },
      onBetClick: function () {
        this.$emit('onBetClick');
      },
      getIndex: function (x, y) {
        return (y + x * 6);
      },
      contentKeyUpFun: function () {
        this.validationBetAmount();
        this.onBetClick();
      },
      removeBetByIndex: function (index) {
        this.integrationArr.splice(index, 1, undefined);
        this.onBetClick();
      },
      getBetList: function () {
        const _this = this;
        let arr = [];
        for (let i = 0; i < this.integrationArr.length; i++) {
          const amount = this.integrationArr[i];
          if (amount !== undefined && amount !== '') {
            const target = _this.$refs["wuxing_banbo_" + i];
            if (target) {
              let showName;
              const renderDataItem = _this.renderData.filter((item,index)=>{
                if( item.showCode == target[0].getAttribute('data-showCode') ){
                  showName = target[0].getAttribute('data-showName');
                  return true;
                }
                 return false;
              })[0];
              
              if(renderDataItem){
                const  {odds,showCode,typeName} = renderDataItem;
                arr.push({
                  title: typeName,
                  ruleName: showName,
                  showCode:showCode,
                  odds: odds,
                  amount: amount,
                  index: i
                });
              }
            }
          }
        }
        return arr;
      },
    }
  }
</script>
<style scoped="">
  .special_animal > div.bet_content_data{
    width: 100%;
  }
  .special_animal .ranking_type{
    width: 600px;
    float: left;
  }
  .game-play-content .bet_content_data p{
    text-align: left;
  }
  .special_animal p span:first-of-type {
    margin: 0 192px 0 15px;
  }
  .special_animal p span:nth-of-type(3) {
    margin: 0px 120px 0 242px;
  }
</style>
