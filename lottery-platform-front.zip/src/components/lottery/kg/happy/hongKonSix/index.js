import HongkonOtherCode from './otherCode.vue'
import HongkonOtherNumber from './otherNumber.vue'
import HongkonSpecialAnimal from './specialAnimal.vue'
import HongkonSpecialCode from './specialCode.vue'
import HongkonSpecialCodeHeadEnd from './HongkonSpecialCodeHeadEnd.vue'
import HongkonSpecialCodeQima from './HongkonSpecialCodeQima.vue'
import HongkonWuxingAndBanbo from './wuxingAndBanbo.vue'
import defineData from './defineData.js'

export {HongkonOtherCode, HongkonSpecialAnimal, HongkonOtherNumber, HongkonSpecialCode, HongkonSpecialCodeHeadEnd ,HongkonSpecialCodeQima,HongkonWuxingAndBanbo}
