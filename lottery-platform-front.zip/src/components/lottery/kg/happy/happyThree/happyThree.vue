<template>
  <div class="fl happyThree" @keyup="contentKeyUpFun">
    <div class="bet_content_data threeArmy">
      <p>{{firstDataList.ruleMasterName}}</p>
      <ul class="clearfix margin-controller">
        <template v-for="(item,x) in firstDataList.gameRuleDetailList">
          <template v-if="item && item.showName">
            <li class="ripple red_ripple" :class="!integrationArr[getIndex(0,x)] ?'':'cur'"
                :ref="`happythree${getIndex(0,x)}`"
                :data-x="0"
                :data-y="x"
                :data-showCode="item.showCode"
                :data-showName="item.showName"
                :key="x">
              <span @click="handleAddIntegration(getIndex(0,x))" class="ranking_type">
                <template v-if="isArray(item.textName)">
                  <i v-for="(value,index) in item.textName" :key="index" :class="`happyThree${value}`"></i>
                </template>
                <template v-else>{{item.textName}}</template>
                <!--{{x == 3 ? "大" : x == 7 ? "小" : ""}}-->
                <span>{{item.ruleOdds ||'0.00'}}</span>
              </span>
              <input type="text" v-model="integrationArr[getIndex(0,x)]">
            </li>
          </template>
          <template v-else>
            <li :key="x"></li>
          </template>
        </template>
      </ul>
    </div>

    <div class="bet_content_data sameCraps">
      <p>{{secondDataList.ruleMasterName}}</p>
      <ul class="clearfix">
        <template v-for="(item,x) in secondDataList.gameRuleDetailList">
          <template v-if="item && item.showName">
            <li class="ripple red_ripple" :class="!integrationArr[getIndex(1,x)] ?'':'cur'"
                :ref="`happythree${getIndex(1,x)}`"
                :data-x="1" :data-y="x"
                :data-showCode="item.showCode"
                :data-showName="item.showName"
                :key="x">
              <span @click="handleAddIntegration(getIndex(1,x))" class="ranking_type">
                <template v-if="isArray(item.textName)">
                  <i v-for="(value,index) in item.textName" :key="index" :class="`happyThree${value}`"></i>
                </template>
                <template v-else><i class="happyThree__sameCraps">{{item.textName}}</i></template>
                <span>{{item.ruleOdds ||'0.00'}}</span>
              </span>
              <input type="text" v-model="integrationArr[getIndex(1,x)]">
            </li>
          </template>
          <template v-else>
            <li :key="x"></li>
          </template>
        </template>
      </ul>
    </div>

    <div class="bet_content_data crapsPoint">
      <p>{{thirdDataList.ruleMasterName}}</p>
      <ul class="clearfix">
        <template v-for="(item,x) in thirdDataList.gameRuleDetailList">
          <template v-if="item && item.showName">
            <li class="ripple red_ripple" :class="!integrationArr[getIndex(2,x)] ?'':'cur'"
                :ref="`happythree${getIndex(2,x)}`"
                :data-x="2" :data-y="x"
                :data-showCode="item.showCode"
                :data-showName="item.showName"
                :key="x">
              <span @click="handleAddIntegration(getIndex(2,x))" class="ranking_type">
                <span>{{item.showName}}点</span>
                <span>{{item.ruleOdds ||'0.00'}}</span>
              </span>
              <input type="text" v-model="integrationArr[getIndex(2,x)]">
            </li>
          </template>
          <template v-else>
            <li :key="x"></li>
          </template>
        </template>
      </ul>
    </div>

    <div class="bet_content_data longCards">
      <p>{{fourthDataList.ruleMasterName}}</p>
      <ul class="clearfix">
        <template v-for="(item,x) in fourthDataList.gameRuleDetailList">
          <template v-if="item && item.showName">
            <li class="ripple red_ripple" :class="!integrationArr[getIndex(3,x)] ?'':'cur'"
                :ref="`happythree${getIndex(3,x)}`"
                :data-x="3" :data-y="x"
                :data-showCode="item.showCode"
                :data-showName="item.showName"
                :key="x">
              <span @click="handleAddIntegration(getIndex(3,x))" class="ranking_type">
                <template v-if="isArray(item.textName)">
                  <i v-for="(value,index) in item.textName" :key="index" :class="`happyThree${value}`"></i>
                </template>
                <template v-else>{{item.textName}}</template>
                <span>{{item.ruleOdds ||'0.00'}}</span>
              </span>
              <input type="text" v-model="integrationArr[getIndex(3,x)]">
            </li>
          </template>
          <template v-else>
            <li :key="x"></li>
          </template>
        </template>
      </ul>
    </div>

    <div class="bet_content_data shortCards">
      <p>{{lastDataList.ruleMasterName}}</p>
      <ul class="clearfix">
        <template v-for="(item,x) in lastDataList.gameRuleDetailList">
          <template v-if="item && item.showName">
            <li class="ripple red_ripple" :class="!integrationArr[getIndex(4,x)] ?'':'cur'"
                :ref="`happythree${getIndex(4,x)}`"
                :data-x="4" :data-y="x"
                :data-showCode="item.showCode"
                :data-showName="item.showName"
                :key="x">
              <span @click="handleAddIntegration(getIndex(4,x))" class="ranking_type">
                <template v-if="isArray(item.textName)">
                  <i v-for="(value,index) in item.textName" :key="index" :class="`happyThree${value}`"></i>
                </template>
                <template v-else>{{item.textName}}</template>
                <span>{{item.ruleOdds ||'0.00'}}</span>
              </span>
              <input type="text" v-model="integrationArr[getIndex(4,x)]">
            </li>
          </template>
          <template v-else>
            <li :key="x"></li>
          </template>
        </template>
      </ul>
    </div>
  </div>
</template>
<script>
  import {mapGetters} from 'vuex'
  import {isNumber, isArray} from '../../../../../utils/index'
  import setPageData from '../../setPageData/index'

  export default{
    name: 'HappyThree',
    props: {
      renderData: {
        type: Array,
        default: function () {
          return []
        }
      },
      betAmount: {
        type: [String, Number],
        default: 0
      }
    },
    data () {
      const cssArr = ['threeArmy', 'sameCraps', 'crapsPoint', 'longCards', 'shortCards'];
      return {
        cssArr,
        firstDataList: {
          ruleMasterName: '三军',
          gameRuleDetailList: setPageData['k3']['happyThree'][0]
        },
        secondDataList: {
          ruleMasterName: '围骰、全骰',
          gameRuleDetailList: setPageData['k3']['happyThree'][1]
        },
        thirdDataList: {
          ruleMasterName: '点数',
          gameRuleDetailList: setPageData['k3']['happyThree'][2]
        },
        fourthDataList: {
          ruleMasterName: '长牌',
          gameRuleDetailList: setPageData['k3']['happyThree'][3]
        },
        lastDataList: {
          ruleMasterName: '短牌',
          gameRuleDetailList: setPageData['k3']['happyThree'][4]
        }
      }
    },
    watch: {
      renderData: function (val) {
        const _this = this;
        if (val && val.length > 0) {
          _this.$nextTick(function () {
            _this.dealData();
            // _this.parseFirstData();
            // _this.parseSecondData();
            // _this.parseThirdData();
            // _this.parseFourthData();
            // _this.parseLastData();
          });
        }
      }
    },
    computed: {
      ...mapGetters([
        'integrationArr'
      ])
    },
    mounted() {
      this.dealData();
    },
    methods: {
      dealData(){//处理传过来的数据
        const _this = this
        this.firstDataList.gameRuleDetailList.dealData(this.renderData);
        this.firstDataList.gameRuleDetailList.forEach(element => {
          _this.$set(element,'textName',isNaN(element.showName) ? element.showName : element.showName.split(''));
        });

        this.secondDataList.gameRuleDetailList.dealData(this.renderData);
        this.secondDataList.gameRuleDetailList.forEach(element => {
          _this.$set(element,'textName',isNaN(element.showName) ? element.showName : element.showName.split(''));
        });

        this.thirdDataList.gameRuleDetailList.dealData(this.renderData);
        this.thirdDataList.gameRuleDetailList.forEach(element => {
          _this.$set(element,'textName',isNaN(element.showName) ? element.showName : element.showName.split(''));
        });

        this.fourthDataList.gameRuleDetailList.dealData(this.renderData);
        this.fourthDataList.gameRuleDetailList.forEach(element => {
          _this.$set(element,'textName',isNaN(element.showName) ? element.showName : element.showName.split(''));
        });

        this.lastDataList.gameRuleDetailList.dealData(this.renderData);
        this.lastDataList.gameRuleDetailList.forEach(element => {
          _this.$set(element,'textName',element.showName && element.showName.split(''));
        });
      },
      isArray,
      parseFirstData: function () {
        if (this.renderData.length > 0) {
          const {ruleMasterName, gameRuleDetailList} = this.renderData[0];
          if (!gameRuleDetailList && !gameRuleDetailList instanceof Array) return;
          this.firstDataList.ruleMasterName = ruleMasterName;
          for (let i = 0; i < gameRuleDetailList.length; i++) {
            if (i < this.firstDataList.gameRuleDetailList.length) {
              const {showName} = gameRuleDetailList[i];
              gameRuleDetailList[i].textName = isNumber(showName) ? showName.split('') : showName;
              this.firstDataList.gameRuleDetailList.splice(i, 1, gameRuleDetailList[i]);
            }
          }
        }
      },
      parseSecondData: function () {
        if (this.renderData.length > 1) {
          const {ruleMasterName, gameRuleDetailList} = this.renderData[1];
          if (!gameRuleDetailList && !gameRuleDetailList instanceof Array) return;
          this.secondDataList.ruleMasterName = ruleMasterName;
          for (let i = 0; i < gameRuleDetailList.length; i++) {
            if (i < this.secondDataList.gameRuleDetailList.length) {
              const {showName} = gameRuleDetailList[i];
              gameRuleDetailList[i].textName = isNumber(showName) ? showName.split('') : showName;
              this.secondDataList.gameRuleDetailList.splice(i, 1, gameRuleDetailList[i]);
            }
          }
        }
      },
      parseThirdData: function () {
        if (this.renderData.length > 2) {
          const {ruleMasterName, gameRuleDetailList} = this.renderData[2];
          if (!gameRuleDetailList && !gameRuleDetailList instanceof Array) return;
          this.thirdDataList.ruleMasterName = ruleMasterName;
          for (let i = 0; i < gameRuleDetailList.length; i++) {
            if (i < this.thirdDataList.gameRuleDetailList.length) {
              const {showName} = gameRuleDetailList[i];
              gameRuleDetailList[i].textName = isNumber(showName) ? showName.split('') : showName;
              this.thirdDataList.gameRuleDetailList.splice(i, 1, gameRuleDetailList[i]);
            }
          }
        }
      },
      parseFourthData: function () {
        if (this.renderData.length > 3) {
          const {ruleMasterName, gameRuleDetailList} = this.renderData[3];
          if (!gameRuleDetailList && !gameRuleDetailList instanceof Array) return;
          this.fourthDataList.ruleMasterName = ruleMasterName;
          for (let i = 0; i < gameRuleDetailList.length; i++) {
            if (i < this.fourthDataList.gameRuleDetailList.length) {
              const {showName} = gameRuleDetailList[i];
              gameRuleDetailList[i].textName = isNumber(showName) ? showName.split('') : showName;
              this.fourthDataList.gameRuleDetailList.splice(i, 1, gameRuleDetailList[i]);
            }
          }
        }
      },
      parseLastData: function () {
        if (this.renderData.length > 4) {
          const {ruleMasterName, gameRuleDetailList} = this.renderData[4];
          if (!gameRuleDetailList && !gameRuleDetailList instanceof Array) return;
          this.lastDataList.ruleMasterName = ruleMasterName;
          for (let i = 0; i < gameRuleDetailList.length; i++) {
            if (i < this.lastDataList.gameRuleDetailList.length) {
              const {showName} = gameRuleDetailList[i];
              gameRuleDetailList[i].textName = isNumber(showName) ? showName.split('') : showName;
              this.lastDataList.gameRuleDetailList.splice(i, 1, gameRuleDetailList[i]);
            }
          }
        }
      },
      getIndex: function (x, y) {
        if (x === 0) {
          return y
        } else if (x === 1) {
          return this.firstDataList.gameRuleDetailList.length + y
        } else if (x === 2) {
          return this.firstDataList.gameRuleDetailList.length +
            this.secondDataList.gameRuleDetailList.length + y
        } else if (x === 3) {
          return this.firstDataList.gameRuleDetailList.length +
            this.secondDataList.gameRuleDetailList.length +
            this.thirdDataList.gameRuleDetailList.length + y
        } else if (x === 4) {
          return this.firstDataList.gameRuleDetailList.length +
            this.secondDataList.gameRuleDetailList.length +
            this.thirdDataList.gameRuleDetailList.length +
            this.fourthDataList.gameRuleDetailList.length + y
        }
      },
      removeBetByIndex: function (index) {
        this.integrationArr.splice(index, 1, undefined);
        this.onBetClick();
      },
      onBetClick: function () {
        this.$emit('onBetClick');
      },
      getBetList: function () {
        const _this = this, arr = [];
        for (let i = 0; i < _this.integrationArr.length; i++) {
          const amount = _this.integrationArr[i];
          if (amount !== undefined && amount !== '') {
            const target = _this.$refs[`happythree${i}`];
            if (target) {
              let showName;
              const renderDataItem = _this.renderData.filter((item,index)=>{
                if( item.showCode == target[0].getAttribute('data-showCode') ){
                  showName = target[0].getAttribute('data-showName');
                  return true;
                }
                 return false;
              })[0];

              if(renderDataItem){
                const  {odds,showCode,typeName} = renderDataItem;
                arr.push({
                  title: typeName,
                  ruleName: showName,
                  showCode:showCode,
                  odds: odds,
                  amount: amount,
                  index: i
                });
              }
            }
          }
        }
        return arr;
      },
      contentKeyUpFun: function () {
        this.validationBetAmount();
        this.onBetClick();
      },
      validationBetAmount: function () {
        for (let i = 0; i < this.integrationArr.length; i++) {
          let singleChip = this.integrationArr[i];
          if (singleChip !== undefined && (!isNumber(singleChip) || singleChip * 1 === 0)) {
            this.integrationArr.splice(i, 1, undefined);
          }
        }
      },
      handleAddIntegration: function (index) {
        this.integrationArr.splice(index, 1, this.integrationArr[index] ? undefined : this.betAmount);
        this.onBetClick();
      }
    }
  }
</script>
<style scoped>
.game-play-content .bet_content_data li span>span:last-child{
  margin-right: 20px;
  font-size: 13px;
}
.game-play-content .bet_content_data .margin-controller li span>span:last-child{
  margin-right: 12px;
}
</style>
