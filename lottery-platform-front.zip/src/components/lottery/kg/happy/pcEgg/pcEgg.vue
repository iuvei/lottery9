<template>
  <div class="fl pc_egg" @keyup="contentKeyUpFun">
    <div class="bet_content_data pc_ball">
      <p v-for="(_,i) in firstDataList.length" :key="i">
        <span>点数</span>
        <span>赔率</span>
        <span>下注</span>
      </p>
      <ul class="clearfix pc_ball" v-for="(item,x) in firstDataList" :key="'pc_'+x">
        <template v-for="(info,y) in item">
          <template v-if="info && info.showName">
            <li class="ripple red_ripple"
                @click="handleAddIntegration(getIndex(x,y))"
                :class="!integrationArr[getIndex(x,y)]?'':'cur'"
                :ref="`pc_egg_${getIndex(x,y)}`" :data-x="0" 
                :data-y="getIndex(x,y)" 
                :data-showCode="info.showCode"
                :data-showName="info.showName"
                :key="y">
              <span class="ranking_type">
                <span class="pc_egg_num">{{info.showName}}</span>
                <span>{{info.ruleOdds||'0.00'}}</span>
              </span>
              <input type="text" v-model="integrationArr[y + x*7]"/>
            </li>
          </template>
          <template v-else>
            <li class="ripple red_ripple" :key="y"><span class="rinking_type"></span></li>
          </template>
        </template>
      </ul>
    </div>
    <div class="bet_content_data pc_two">
      <p>{{secondDataList.ruleMasterName}}</p>
      <ul class="clearfix">
        <template v-for="(item,i) in secondDataList.gameRuleDetailList">
          <template v-if="item && item.showName">
            <li class="ripple red_ripple"
                @click="handleAddIntegration(i+28)"
                :class="!integrationArr[i+28]?'':'cur'"
                :ref="'pc_egg_'+getRuleIdIndex(parseInt(i+28))" :data-x="1" :data-y="i" 
                :data-showCode="item.showCode"
                :data-showName="item.showName"
                :key="i">
                  <span class="ranking_type">
                     <span>{{item.showName}}</span>
                     <span>{{item.ruleOdds ||'0.00'}}</span>
                  </span>
              <input type="text" v-model="integrationArr[i+28]">
            </li>
          </template>
          <template v-else>
            <li class="ripple red_ripple" :key="i"><span class="ranking_type"></span></li>
          </template>
        </template>
      </ul>
    </div>
    <div class="bet_content_data">
      <p>{{lastDataList.ruleMasterName}}</p>
      <ul class="clearfix">
        <template v-for="(item,i) in lastDataList.gameRuleDetailList">
          <template v-if="item && item.showName">
            <li class="ripple red_ripple"
                @click="handleAddIntegration(i+38)"
                :class="!integrationArr[i+38]?'':'cur'"
                :ref="'pc_egg_'+getRuleIdIndex(parseInt(i+38))" :data-x="2" :data-y="i" 
                :data-showCode="item.showCode"
                :data-showName="item.showName"
                :key="i">
              <span class="ranking_type">
                <span>{{item.showName}}</span>
                <span>{{item.ruleOdds ||'0.00'}}</span>
              </span>
              <input type="text" v-model="integrationArr[i+38]">
            </li>
            <!-- <template v-if="isTmbs(item.betDetail)">
              <li class="ripple red_ripple"
                  @click="handleAddIntegration(i+38)"
                  :class="!integrationArr[i+38]?'':'cur'"
                  :ref="'pc_egg_'+getRuleIdIndex(parseInt(i+38))" :data-x="2" :data-y="i" 
                  :data-showCode="item.showCode"
                  :data-showName="item.showName"
                  :key="i">
                 <span class="ranking_type">
                   <span>{{item.showName}}</span>
                   <span>{{item.ruleOdds ||'0.00'}}</span>
                 </span>
                <p class="selectView">
                  <span :ref="'tm_bs_'+getRuleIdIndex(parseInt(i+38))"
                        :data-pc_select_1="pcSelect1">{{pcSelect1}}</span>
                  <span :ref="'tm_bs_'+getRuleIdIndex(parseInt(i+38))"
                        :data-pc_select_2="pcSelect2">{{pcSelect2}}</span>
                  <span :ref="'tm_bs_'+getRuleIdIndex(parseInt(i+38))"
                        :data-pc_select_3="pcSelect3">{{pcSelect3}}</span>
                </p>
                <select v-model="pcSelect1">
                  <option v-for="option in getOptions(1)" :value="option" :key="option">{{option}}</option>
                </select>
                <select v-model="pcSelect2">
                  <option v-for="option in getOptions(2)" :value="option" :key="option">{{option}}</option>
                </select>
                <select v-model="pcSelect3">
                  <option v-for="option in getOptions(3)" :value="option" :key="option">{{option}}</option>
                </select>
                <input type="text" v-model="integrationArr[i+38]">
              </li>
            </template> 
            <template v-else>
              <li class="ripple red_ripple"
                  @click="handleAddIntegration(i+38)"
                  :class="!integrationArr[i+38]?'':'cur'"
                  :ref="'pc_egg_'+getRuleIdIndex(parseInt(i+38))" :data-x="2" :data-y="i" 
                  :data-showCode="item.showCode"
                  :data-showName="item.showName"
                  :key="i">
                <span class="ranking_type">
                  <span>{{item.showName}}</span>
                  <span>{{item.ruleOdds ||'0.00'}}</span>
                </span>
                <input type="text" v-model="integrationArr[i+38]">
              </li>
            </template>-->
          </template>
          <template v-else>
            <li class="ripple red_ripple" :key="i"><span class="ranking_type"></span></li>
          </template>
        </template>
      </ul>
    </div>
  </div>
</template>
<script>
  import setPageData from '../../setPageData/index'
  import {isNumber} from '../../../../../utils/index'
  import {mapGetters} from 'vuex'
  export default{
    name: 'PcEgg',
    props: {
      renderData: {
        type: Array,
        default: function () {
          return []
        }
      },
      betAmount: {
        type: [String, Number],
        default: ''
      }
    },
    data () {
      return {
        pcEggTitle: ["点数", "两面", "色波/豹子"],
        pcSelect1: 0,
        pcSelect2: 1,
        pcSelect3: 2,
        firstDataList:[[]],
        newArry: setPageData['pcdd']['pcEgg'][0],
        secondDataList: {ruleMasterName: '两面', gameRuleDetailList: setPageData['pcdd']['pcEgg'][1]},
        lastDataList: {ruleMasterName: '色波/豹子', gameRuleDetailList: setPageData['pcdd']['pcEgg'][2]},
      }
    },
    watch: {
      renderData: function (val) {
        const _this = this;
        if (val && val.length > 0) {
          _this.$nextTick(function () {
            _this.dealData();
            // _this.getPointsData();
            // _this.getTwoSidesData();
            // _this.getPgThreeColorData();
          });
        }
      }
    },
    computed: {
      ...mapGetters([
        'integrationArr'
      ])
    },
    methods: {
      dealData(){//处理传过来的数据
        this.newArry.dealData(this.renderData);
        this.secondDataList.gameRuleDetailList.dealData(this.renderData);
        this.lastDataList.gameRuleDetailList.dealData(this.renderData);

        //处理数组，显示为每三个一组
        let i = 0;
        const _this = this;
        this.newArry.forEach(function(item,index){
          if( !(index%7) ){
            _this.$set(_this.firstDataList,i,_this.newArry.slice(index,index+7));
            i++;
          }
        });
      },
      //pc蛋蛋特码包三选项操作
      getOptions: function (n) {
        var arr = [];
        for (var i = 0; i <= 27; i++) {
          var isSelected = false;
          for (var j = 1; j < 4; j++) {
            if (j !== n && +this["pcSelect" + j] === i) {
              isSelected = true;
              break;
            }
          }
          !isSelected && arr.push(i + '');
        }
        return arr;
      },
      onBetClick: function () {
        this.$emit('onBetClick');
      },
      handleAddIntegration: function (index) {
        this.integrationArr.splice(index, 1, this.integrationArr[index] ? undefined : this.betAmount);
        this.onBetClick();
      },
      contentKeyUpFun: function () {
        this.validationBetAmount();
        this.onBetClick();
      },
      validationBetAmount: function () {
        for (let i = 0; i < this.integrationArr.length; i++) {
          let singleChip = this.integrationArr[i];
          if (singleChip !== undefined && (!isNumber(singleChip) || singleChip * 1 === 0)) {
            this.integrationArr.splice(i, 1, undefined);
          }
        }
      },
      getPointsData: function () {
        if (this.renderData.length > 0) {
          const {gameRuleDetailList} = this.renderData[0];
          if (!gameRuleDetailList && !gameRuleDetailList instanceof Array) return;
          let index = 0;
          for (let i = 0; i < gameRuleDetailList.length; i++) {
            if (index < this.firstDataList.length) {
              this.firstDataList[index].splice((i + 7) % 7, 1, gameRuleDetailList[i]);
              if ((i + 1) % 7 === 0) {
                index++;
              }
            }
          }
        }
      },
      getTwoSidesData: function () {
        if (this.renderData.length > 1) {
          const {ruleMasterName, gameRuleDetailList} = this.renderData[1];
          if (!gameRuleDetailList && !gameRuleDetailList instanceof Array) return;
          this.secondDataList.ruleMasterName = ruleMasterName;
          for (let i = 0; i < gameRuleDetailList.length; i++) {
            if (i < this.secondDataList.gameRuleDetailList.length) {
              this.secondDataList.gameRuleDetailList.splice(i, 1, gameRuleDetailList[i]);
            }
          }
        }
      },
      getPgThreeColorData: function () {
        const _this = this;
        if (_this.renderData.length > 2) {
          const {ruleMasterName, gameRuleDetailList} = _this.renderData[2];

          _this.lastDataList.ruleMasterName = ruleMasterName;
          for (let i = 0; i < gameRuleDetailList.length; i++) {
            if (i < _this.lastDataList.gameRuleDetailList.length) {
              _this.lastDataList.gameRuleDetailList.splice(i, 1, gameRuleDetailList[i]);
            }
          }
        }
      },
      isTmbs: function (betDetail) { //判断是否为特码包三
        return betDetail === "T@";
      },
      getIndex: function (x, y) {
        return y + x * this.firstDataList[0].length
      },
      getRuleIdIndex: function (i) {
        return i;
      },
      removeBetByIndex: function (index) {
        this.integrationArr.splice(index, 1, undefined);
        this.onBetClick();
      },
      getBetList: function () {
        const _this = this;
        let arr = [];
        for (let i = 0; i < this.integrationArr.length; i++) {
          const amount = this.integrationArr[i];
          if (amount !== undefined && amount !== '') {
            const target = _this.$refs[`pc_egg_${i}`];
            if (target) {
              let showName;
              const renderDataItem = _this.renderData.filter((item,index)=>{
                if( item.showCode == target[0].getAttribute('data-showCode') ){
                  showName = target[0].getAttribute('data-showName');
                  return true;
                }
                 return false;
              })[0];
              
              if(renderDataItem){
                const  {odds,showCode,typeName} = renderDataItem;
                arr.push({
                  title: typeName,
                  ruleName: showName,
                  showCode:showCode,
                  odds: odds,
                  amount: amount,
                  index: i
                });

                let title = typeName;
                let name = showName;
                if (renderDataItem.betDetail === 'T@') {
                  title = '包三';
                  const target1 = _this.$refs[`tm_bs_${i}`];
                  if (target1) {
                    const {pc_select_1} = target1[0].dataset;
                    const {pc_select_2} = target1[1].dataset;
                    const {pc_select_3} = target1[2].dataset;
                    name = `${pc_select_1}|${pc_select_2}|${pc_select_3}`
                  }
                } else if (showName === '红波' || showName === '绿波' || showName === '蓝波') {
                  title = '色波';
                } else if (showName === '豹子') {
                  title = showName;
                }
              }
            }
          }
        }
        return arr;
      },
    },
    mounted(){


    }
  }
</script>

<style scoped>
.game-play-content .bet_content_data li span > span:last-child {
  float: none;
  margin-right: 8px;
}
</style>

