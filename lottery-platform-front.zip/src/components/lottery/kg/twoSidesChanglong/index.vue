<template>
  <div class="history_issue-type" style="display: block;">
    <ul class="history_issue-type-ul">
      <li>两面长龙排行</li>
    </ul>
    <div class="history_type">
      <ul id="newAwardPostCon">
        <li class="newAward_li" v-for="(item,index) in winLongRank" :key="index">
          <span> {{ item.lotteryLocation }}</span>
          <span> {{ item.lotteryContinuous }}期</span>
        </li>
      </ul>
    </div>
  </div>
</template>
<script>
  export default{
    name: 'tow-sides-changlong',
    props: {
      winLongRank: {
        type: Array,
        default: []
      }
    },
    data () {
      return {}
    }
  }
</script>
