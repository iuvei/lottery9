import Vue from "vue";
/* 
   处理后台传过来的信用玩法数据(时时彩,gameCode: "cqssc")
   writed by ez
*/
'use strict';
Array.prototype.dealData = function(paramData){
    this.forEach(elementA => {
        if( paramData ){
            paramData.forEach(elementB => {
                if( elementA && elementA.showCode &&  (elementA.showCode === elementB.showCode)){
                   elementA.ruleOdds = elementB.odds||'-';
                }
            });
        }else{
            elementA.ruleOdds = '-';
        }
    })
    // console.log(this);
}

//封装storage的过期控制代码
Vue.prototype.storage = {
    set( key,value ){
        var curTime = new Date().getTime();
        sessionStorage.setItem(key,JSON.stringify({data:value,time:curTime}));
    },
    get( key,exp ){
        var data = sessionStorage.getItem(key);
        var dataObj = data && JSON.parse(data);
        if( !!exp ){
            if( dataObj && dataObj.time ){
                if ( new Date().getTime() - dataObj.time > exp ) {
                    console.log('信息已过期');
                    return false;
                }else{
                    return dataObj.data;
                }
            }else{
                //console.log('该数据尚未存入');
                return false;
            }
        }else{
            var dataObjDatatoJson = JSON.parse(dataObj.data)
            return dataObjDatatoJson;
        }
    },
    clear(){
        return sessionStorage.clear();
    }
}


//自定义配置的lotteryPlaysList数据
Vue.prototype.lotteryPlaysLists = {
    getIndexLotteryPlaysList:function(gameCode){
        let index;
        if( gameCode == 'cqssc' || gameCode == 'xjssc' || gameCode == 'xywfc'|| gameCode == 'xyefc' || gameCode == 'xyffc' || gameCode == 'tjssc' || gameCode == 'ynssc'){
            index = 0;
        }else if( gameCode == 'pcdd' || gameCode == 'wcdd' ){
            index = 1;
        }else if( gameCode == 'bjpk10' || gameCode == 'wfpk10' || gameCode == 'ffpk10' || gameCode == 'xyft' ){
            index = 2;
        }else if( gameCode == 'anhk3' || gameCode == 'hubk3' || gameCode == 'wfk3' || gameCode == 'efk3' || gameCode == 'ffk3' || gameCode == 'jsk3' ){
            index = 3;
        }else if( gameCode == 'lhc' || gameCode == 'wclhc' ){
            index = 4;
        }else if( gameCode == 'jx11x5' || gameCode == 'sh11x5' || gameCode == 'ln11x5' || gameCode == 'hb11x5' || gameCode == 'ah11x5' || gameCode == 'js11x5' || gameCode == 'c11x5wfc' || gameCode == 'c11x5efc' || gameCode == 'gd11x5'){
            index = 5;
        }else if( gameCode == 'klsfwfc' || gameCode == 'klsfefc' || gameCode == 'tjklsf' || gameCode == 'ynklsf' || gameCode == 'gdklsf' ){
            index = 6;
        }else if( gameCode == 'bjkl8' ){
            index = 7;
        }else if( gameCode == 'shssl' ){
           index = 8;
        }
        return index;
    },
    defineLotteryPlaysList:[
        {
            "currentStatus": 0,
            "currentData": [{
                    "id": 100000000000141,
                    "ruleMasterName": "整合盘",
                    "gameId": 1,
                    "sortNo": null,
                    "parentId": 0,
                    "ruleMasterCode": "ssc_zhp",
                    "remark": null
                }, {
                    "id": 100000000000142,
                    "ruleMasterName": "两面盘",
                    "gameId": 1,
                    "sortNo": null,
                    "parentId": 0,
                    "ruleMasterCode": "ssc_lmp",
                    "remark": null
                }, {
                    "id": 100000000000143,
                    "ruleMasterName": "数字盘",
                    "gameId": 1,
                    "sortNo": null,
                    "parentId": 0,
                    "ruleMasterCode": "ssc_szp",
                    "remark": null
                }, {
                    "id": 100000000000144,
                    "ruleMasterName": "第一球",
                    "gameId": 1,
                    "sortNo": null,
                    "parentId": 0,
                    "ruleMasterCode": "ssc_dyq",
                    "remark": null
                }, {
                    "id": 100000000000145,
                    "ruleMasterName": "第二球",
                    "gameId": 1,
                    "sortNo": null,
                    "parentId": 0,
                    "ruleMasterCode": "ssc_deq",
                    "remark": null
                }, {
                    "id": 100000000000146,
                    "ruleMasterName": "第三球",
                    "gameId": 1,
                    "sortNo": null,   
                    "parentId": 0,
                    "ruleMasterCode": "ssc_dsanq",
                    "remark": null
                }, {
                    "id": 100000000000147,
                    "ruleMasterName": "第四球",
                    "gameId": 1,
                    "sortNo": null,
                    "parentId": 0,
                    "ruleMasterCode": "ssc_dsiq",
                    "remark": null
                }, {
                    "id": 100000000000148,
                    "ruleMasterName": "第五球",
                    "gameId": 1,
                    "sortNo": null,
                    "parentId": 0,
                    "ruleMasterCode": "ssc_dwq",
                    "remark": null
                }],
            "errorInformation": null
        },
        {
            "currentStatus": 0,
            "currentData": [{
                    "id": 100000000000381,
                    "ruleMasterName": "幸运玩法",
                    "gameId": 4,
                    "sortNo": null,
                    "parentId": 0,
                    "ruleMasterCode": "klc_xywf",
                    "remark": null
                }],
            "errorInformation": null
        },
        {
            "currentStatus": 0,
            "currentData": [{
                    "id": 100000000000001,
                    "ruleMasterName": "两面盘",
                    "gameId": 6,
                    "sortNo": null,
                    "parentId": 0,
                    "ruleMasterCode": "pk10_lmp",
                    "remark": null
                }, {
                    "id": 100000000000002,
                    "ruleMasterName": "1~10名",
                    "gameId": 6,
                    "sortNo": null,
                    "parentId": 0,
                    "ruleMasterCode": "pk10_1-10m",
                    "remark": null
                }, {
                    "id": 100000000000003,
                    "ruleMasterName": "冠亚和 ",
                    "gameId": 6,
                    "sortNo": null,
                    "parentId": 0,
                    "ruleMasterCode": "pk10_gyh",
                    "remark": null
                }],
            "errorInformation": null
        },{
            "currentStatus": 0,
            "currentData": [{
                    "id": 100000000000375,
                    "ruleMasterName": "骰宝",
                    "gameId": 9,
                    "sortNo": null,
                    "parentId": 0,
                    "ruleMasterCode": "ks_sb",
                    "remark": null
                }],
            "errorInformation": null
        },{
            "currentStatus": 0,
            "currentData": [{
                    "id": 100000000000115,
                    "ruleMasterName": "特码",
                    "gameId": 5,
                    "sortNo": null,
                    "parentId": 0,
                    "ruleMasterCode": "klc_tm",
                    "remark": null
                }, {
                    "id": 100000000000116,
                    "ruleMasterName": "特肖",
                    "gameId": 5,
                    "sortNo": null,
                    "parentId": 0,
                    "ruleMasterCode": "klc_tx",
                    "remark": null
                }, {
                    "id": 100000000000117,
                    "ruleMasterName": "正码一",
                    "gameId": 5,
                    "sortNo": null,
                    "parentId": 0,
                    "ruleMasterCode": "klc_zm1",
                    "remark": null
                }, {
                    "id": 100000000000118,
                    "ruleMasterName": "正码二",
                    "gameId": 5,
                    "sortNo": null,
                    "parentId": 0,
                    "ruleMasterCode": "klc_zm2",
                    "remark": null
                }, {
                    "id": 100000000000119,
                    "ruleMasterName": "正码三",
                    "gameId": 5,
                    "sortNo": null,
                    "parentId": 0,
                    "ruleMasterCode": "klc_zm3",
                    "remark": null
                }, {
                    "id": 100000000000120,
                    "ruleMasterName": "正码四",
                    "gameId": 5,
                    "sortNo": null,
                    "parentId": 0,
                    "ruleMasterCode": "klc_zm4",
                    "remark": null
                }, {
                    "id": 100000000000121,
                    "ruleMasterName": "正码五",
                    "gameId": 5,
                    "sortNo": null,
                    "parentId": 0,
                    "ruleMasterCode": "klc_zm5",
                    "remark": null
                }, {
                    "id": 100000000000122,
                    "ruleMasterName": "正码六",
                    "gameId": 5,
                    "sortNo": null,
                    "parentId": 0,
                    "ruleMasterCode": "klc_zm6",
                    "remark": null
                }, {
                    "id": 100000000000123,
                    "ruleMasterName": "正码",
                    "gameId": 5,
                    "sortNo": null,
                    "parentId": 0,
                    "ruleMasterCode": "klc_zm",
                    "remark": null
                }, {
                    "id": 100000000002280,
                    "ruleMasterName": "特码头尾",
                    "gameId": 5,
                    "sortNo": null,
                    "parentId": 0,
                    "ruleMasterCode": "klc_tmtw",
                    "remark": null
                }, {
                    "id": 100000000002281,
                    "ruleMasterName": "五行",
                    "gameId": 5,
                    "sortNo": null,
                    "parentId": 0,
                    "ruleMasterCode": "klc_wx",
                    "remark": null
                }, {
                    "id": 100000000002282,
                    "ruleMasterName": "半波",
                    "gameId": 5,
                    "sortNo": null,
                    "parentId": 0,
                    "ruleMasterCode": "klc_bb",
                    "remark": null
                }, {
                    "id": 100000000002283,
                    "ruleMasterName": "七码",
                    "gameId": 5,
                    "sortNo": null,
                    "parentId": 0,
                    "ruleMasterCode": "klc_qm",
                    "remark": null
                }],
            "errorInformation": null
        },{
            "currentStatus": 0,
            "currentData": [{
                    "id": 100000000001826,
                    "ruleMasterName": "两面盘",
                    "gameId": 54,
                    "sortNo": null,
                    "parentId": 0,
                    "ruleMasterCode": "c11x5_lmp",
                    "remark": null
                }, {
                    "id": 100000000001827,
                    "ruleMasterName": "单码",
                    "gameId": 54,
                    "sortNo": null,
                    "parentId": 0,
                    "ruleMasterCode": "c11x5_dm",
                    "remark": null
                }],
            "errorInformation": null
        },{
            "currentStatus": 0,
            "currentData": [{
                    "id": 100000000001946,
                    "ruleMasterName": "两面盘",
                    "gameId": 63,
                    "sortNo": null,
                    "parentId": 0,
                    "ruleMasterCode": "klsf_lmp",
                    "remark": null
                }, {
                    "id": 100000000001947,
                    "ruleMasterName": "第一球",
                    "gameId": 63,
                    "sortNo": null,
                    "parentId": 0,
                    "ruleMasterCode": "klsf_dyq",
                    "remark": null
                }, {
                    "id": 100000000001948,
                    "ruleMasterName": "第二球",
                    "gameId": 63,
                    "sortNo": null,
                    "parentId": 0,
                    "ruleMasterCode": "klsf_deq",
                    "remark": null
                }, {
                    "id": 100000000001949,
                    "ruleMasterName": "第三球",
                    "gameId": 63,
                    "sortNo": null,
                    "parentId": 0,
                    "ruleMasterCode": "klsf_dsq",
                    "remark": null
                }, {
                    "id": 100000000001950,
                    "ruleMasterName": "第四球",
                    "gameId": 63,
                    "sortNo": null,
                    "parentId": 0,
                    "ruleMasterCode": "klsf_dsiq",
                    "remark": null
                }, {
                    "id": 100000000001951,
                    "ruleMasterName": "第五球",
                    "gameId": 63,
                    "sortNo": null,
                    "parentId": 0,
                    "ruleMasterCode": "klsf_dwq",
                    "remark": null
                }, {
                    "id": 100000000001952,
                    "ruleMasterName": "第六球",
                    "gameId": 63,
                    "sortNo": null,
                    "parentId": 0,
                    "ruleMasterCode": "klsf_dlq",
                    "remark": null
                }, {
                    "id": 100000000001953,
                    "ruleMasterName": "第七球",
                    "gameId": 63,
                    "sortNo": null,
                    "parentId": 0,
                    "ruleMasterCode": "klsf_dqq",
                    "remark": null
                }, {
                    "id": 100000000001954,
                    "ruleMasterName": "第八球",
                    "gameId": 63,
                    "sortNo": null,
                    "parentId": 0,
                    "ruleMasterCode": "klsf_dbq",
                    "remark": null
                }, {
                    "id": 100000000001955,
                    "ruleMasterName": "正码",
                    "gameId": 63,
                    "sortNo": null,
                    "parentId": 0,
                    "ruleMasterCode": "klsf_zm",
                    "remark": null
                }],
            "errorInformation": null
        },{
            "currentStatus": 0,
            "currentData": [{
                    "id": 100000000001917,
                    "ruleMasterName": "两面盘",
                    "gameId": 61,
                    "sortNo": null,
                    "parentId": 0,
                    "ruleMasterCode": "k8_lmp",
                    "remark": null
                }, {
                    "id": 100000000001918,
                    "ruleMasterName": "正码",
                    "gameId": 61,
                    "sortNo": null,
                    "parentId": 0,
                    "ruleMasterCode": "k8_zm",
                    "remark": null
                }],
            "errorInformation": null
        },{
            "currentStatus": 0,
            "currentData": [{
                    "id": 100000000001924,
                    "ruleMasterName": "两面盘",
                    "gameId": 62,
                    "sortNo": null,
                    "parentId": 0,
                    "ruleMasterCode": "ssc_lmp",
                    "remark": null
                }, {
                    "id": 100000000001925,
                    "ruleMasterName": "数字盘",
                    "gameId": 62,
                    "sortNo": null,
                    "parentId": 0,
                    "ruleMasterCode": "ssc_szp",
                    "remark": null
                }, {
                    "id": 100000000001926,
                    "ruleMasterName": "第一球",
                    "gameId": 62,
                    "sortNo": null,
                    "parentId": 0,
                    "ruleMasterCode": "ssc_dyq",
                    "remark": null
                }, {
                    "id": 100000000001927,
                    "ruleMasterName": "第二球",
                    "gameId": 62,
                    "sortNo": null,
                    "parentId": 0,
                    "ruleMasterCode": "ssc_deq",
                    "remark": null
                }, {
                    "id": 100000000001928,
                    "ruleMasterName": "第三球",
                    "gameId": 62,
                    "sortNo": null,
                    "parentId": 0,
                    "ruleMasterCode": "ssc_dsq",
                    "remark": null
                }, {
                    "id": 100000000001929,
                    "ruleMasterName": "跨度",
                    "gameId": 62,
                    "sortNo": null,
                    "parentId": 0,
                    "ruleMasterCode": "ssc_kd",
                    "remark": null
                }, {
                    "id": 100000000001930,
                    "ruleMasterName": "和数",
                    "gameId": 62,
                    "sortNo": null,
                    "parentId": 0,
                    "ruleMasterCode": "ssc_hs",
                    "remark": null
                }],
            "errorInformation": null
        }
    ]
}




// let needDistinguish = false;//用来判定后台传过来的showCode是否可直接使用，'-'不可，否则可
    // const _this = this;
    // creditPlayComDealData(paramData);

    // function  creditPlayComDealData(paramData){//处理传过来的数据
    //     paramData.forEach(elementA => {
    //         needDistinguish =  elementA.showCode.indexOf('-') == '-1';
    //         if( needDistinguish ){//如果可是直接使用的话
    //             const numberType = elementA.showCode;//获取值类型
    //             const indexType = getIndexColumn(titleType,numberType);
                
    //             if( index !== '' && indexType !== '' && _this[index].gameRuleDetailList ){
    //                 _this[index].gameRuleDetailList.forEach(function(item,_index){//遍历自定义的数组，并给匹配上的数据对应值
    //                     item && item.showName == indexType && ( item.ruleOdds = elementA.odds);
    //                 });
    //             }
    //         }else{
    //             const titleType = elementA.showCode.split('-')[0];//获取列类型
    //             const numberType = elementA.showCode.split('-')[1];//获取值类型
    //             const index = getIndexRow(titleType);
    //             const indexType = getIndexColumn(titleType,numberType);
                
    //             if( index !== '' && indexType !== '' && _this[index].gameRuleDetailList ){
    //                 _this[index].gameRuleDetailList.forEach(function(item,_index){//遍历自定义的数组，并给匹配上的数据对应值
    //                     item && item.showName == indexType && ( item.ruleOdds = elementA.odds);
    //                 });
    //             }
    //         }
    //     });
    //     console.log(_this);
    // }

    // function getIndexRow( titleType ){//根据对应的key获取列下标
    //     const index = _this.findIndex((item,index)=>{
    //         return  titleType == item.key;
    //     });

    //     if( titleType == 'lhh' && index == '-1' ){//为了解决在 sum 列表中含有 lhh 数据的问题
    //         return getIndexRow( 'sum' ); 
    //     }
    //     return index == '-1'?'':index;
    // }

    // function  getIndexColumn( titleType,numberType ){//根据对应的showCode字段代表的中文意思
    //     let indexType = '';
    //     if( titleType == 'w'||titleType == 'q'||titleType == 'b'||titleType == 's'||titleType == 'g' ){//整合盘
    //         if( numberType == 'big' ){//具体值类型
    //            indexType = '大';
    //         }else if( numberType == 'small' ){
    //            indexType = '小';
    //         }else if( numberType == 'single' ){
    //            indexType = '单';
    //         }else if( numberType == 'double' ){
    //            indexType = '双';
    //         }else if( !isNaN(parseInt(numberType)) ){
    //            indexType =  parseInt(numberType);           
    //         }
    //     }else if( titleType == 'sum' ){//和游戏
    //         if( numberType == 'dragon' ){//具体值类型
    //             indexType = '龙';
    //         }else if( numberType == 'tiger' ){
    //             indexType = '虎';
    //         }else if( numberType == 'sum' ){
    //             indexType = '和';
    //         }else if( numberType == 'big' ){//具体值类型
    //            indexType = '总和大';
    //         }else if( numberType == 'small' ){
    //            indexType = '总和小';
    //         }else if( numberType == 'single' ){
    //            indexType = '总和单';
    //         }else if( numberType == 'double' ){
    //            indexType = '总和双';
    //         }else if( !isNaN(parseInt(numberType)) ){
    //            indexType =  parseInt(numberType);           
    //         }
    //     }else if( titleType == 'lhh' ){//龙虎游戏
    //         if( numberType == 'dragon' ){//具体值类型
    //            indexType = '龙';
    //         }else if( numberType == 'tiger' ){
    //            indexType = '虎';
    //         }else if( numberType == 'sum' ){
    //            indexType = '和';
    //         }
    //     }
    //     return indexType;
    // }