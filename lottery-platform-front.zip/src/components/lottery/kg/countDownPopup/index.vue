<template>
  <div class="countdown_f" :class="{countdown_h:isContraction}">
    <span>{{issue}}</span>
    <span>{{gameTime}}</span>
    <a class="ripple" @click="isContraction=!isContraction"></a>
  </div>
</template>
<script>
  export default{
    name: 'countdown-popup',
    props: {
      issue: {
        type: String,
        default: ''
      },
      contraction: {
        type: Boolean,
        default: true
      },
      gameTime: {
        type: String,
        default: ''
      }
    },
    data () {
      return {
        isContraction: this.contraction
      }
    }
  }
</script>
