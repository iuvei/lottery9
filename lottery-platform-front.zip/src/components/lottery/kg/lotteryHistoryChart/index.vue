<template>
  <div class="lott_history"
       :class="{lott_pkHisHeight:pk10Show,pcEgg_history:isKlc()||isXgc(), happy_history:isK3()}">
    <div class="history_number">
      <ul class="history-ul game_dl" id="history-ul">
        <li class="history-li" :class="{cur:switchHistoryNav == 1}" id="history-li1"
            @mouseover="historyNum()">
          <a id="lotteryNumLink" target="_blank">号码</a></li>
        <li class="history-li" :class="{cur:switchHistoryNav == 2}" id="history-li2"
            @mouseover="historyBigOrSmall()">大小
        </li>
        <li class="history-li" :class="{cur:switchHistoryNav == 3}" id="history-li3"
            @mouseover="historySingleOrEven()">单双
        </li>
      </ul>
    </div>
    <!--号码期数-->
    <div class="history_issue history_issue1"
         :class="getIssueClass()">
      <ul v-if="isSsc()" class="history_issue-ul clearfix">
        <li>期号</li>
        <li>万千百十个</li>
      </ul>
      <ul v-if="isPk10()" class="historyPK_issue-ul clearfix">
        <li>期号</li>
        <li>冠亚三四五六七八九十</li>
      </ul>
      <ul v-if="is11x5()" class="history_issue-ul clearfix">
        <li>期号</li>
        <li>一二三四五</li>
      </ul>
      <ul v-if="isSsl()" class="history_issue-ul clearfix">
        <li>期号</li>
        <li>一二三</li>
      </ul>
      <ul v-if="isKlsf()" class="historyPK_issue-ul clearfix">
        <li>期号</li>
        <li>一二三四五六七八</li>
      </ul><!--
      <ul v-if="groupId == 4" class="history_issue-ul clearfix">
        <li :class="{pcEgg:gameId == 33,markSix_history:gameId == 34}">期号</li>
        <li>{{gameId == 34 ? "一二三四五六特" : "万千百"}}<span v-if="gameId == 33">和</span></li>
      </ul>-->
      <ul v-if="isXgc()" class="clearfix" :class="getXgcClass()">
        <li :class="{markSix_history:!isWclhc()}">期号</li>
        <li>{{"一二三四五六特"}}</li>
      </ul>
      <!--pc蛋蛋-->
      <ul v-if="isKlc()" class="history_issue-ul clearfix">
        <li class="pcEgg">期号</li>
        <li>{{"万千百和"}}</li>
      </ul>

      <div class="history_issue_list">
        <ul v-show="historyNumShow">
          <li class="cf" v-for="(item,i) in historyData">
            <div class="issue_list issue_inline">
              <b class="num_color">{{ item.lotteryResultNum }}</b>：
            </div>
            <div class="num_list">
              <span v-for="(v,i) in item.historyNumber">{{ v }}</span>
              <span v-if="isKlc()" class="history_sum" :class="getColor(getHistorySum(i))">{{getHistorySum(i)}}</span>
            </div>
          </li>
        </ul>
        <ul v-show="historyBigOrSmallShow">
          <li class="cf" v-for="(item,i) in historyData">
            <div class="issue_list issue_inline">
              <b class="num_color">{{ item.lotteryResultNum }}</b>：
            </div>
            <!-- 时时彩系列 -->
            <div class="num_list" v-if="isSsc()">
              <span :class="{'tab-tr_blue1':v<5,'tab-tr_red2':v>=5}"
                    v-for="(v,i) in item.historyNumber">{{ v >= 5 ? "大" : "小" }}</span>
            </div>
            <!-- 时时彩系列 -->
            <div class="num_list" v-if="isSsl()">
              <span :class="{'tab-tr_blue1':v<5,'tab-tr_red2':v>=5}"
                    v-for="(v,i) in item.historyNumber">{{ v >= 5 ? "大" : "小" }}</span>
            </div>
            <!-- 时时彩系列 -->
            <div class="num_list" v-if="isKl8()">
              <span :class="{'tab-tr_blue1':v<41,'tab-tr_red2':v>=41}"
                    v-for="(v,i) in item.historyNumber">{{ v >= 41 ? "大" : "小" }}</span>
            </div>
            <!-- 快乐彩系列 -->
            <div class="num_list" v-if="isKlsf()">
              <span :class="{'tab-tr_blue1':v<11,'tab-tr_red2':v>=11}"
                    v-for="(v,i) in item.historyNumber">{{ v >= 11 ? "大" : "小" }}</span>
            </div>

            <!-- 11x5系列 -->
            <div class="num_list" v-if="is11x5()">
              <span :class="get11x5SmallBallClass(v)"
                    v-for="(v,i) in item.historyNumber">{{c11x5Class(v)}}</span>
            </div>

            <!--PK10系列 Dream 2017年9月29日21:03:22  -->
            <div class="num_list" v-if="isPk10()">
              <span :class="{'tab-tr_blue1':v<=5,'tab-tr_red2':v>5}"
                    v-for="(v,i) in item.historyNumber">{{ v > 5 ? "大" : "小" }}</span>
            </div>

            <div class="num_list" v-if="isKlc()">
              <span :class="{'tab-tr_blue1':v<=3,'tab-tr_red2':v>3}"
                    v-for="(v,i) in item.historyNumber">{{ v > 3 ? "大" : "小" }}</span>
              <span v-if="isKlc()" class="history_sum"
                    :class="getColor(getHistorySum(i))">{{getHistorySum(i) <= 13 ? "小" : "大"}}</span>
            </div>
            <div class="num_list" v-if="isXgc()">
              <span :class="{'tab-tr_blue1':v<=24,'tab-tr_red2':v>24}"
                    v-for="(v,i) in item.historyNumber">{{ v > 24 ? "大" : "小" }}</span>
            </div>
            <div class="num_list" v-if="isK3()">
              <span :class="{'tab-tr_blue1':v<=3,'tab-tr_red2':v>3}"
                    v-for="(v,i) in item.historyNumber">{{ v > 3 ? "大" : "小" }}</span>
            </div>
            <div class="num_list" v-if="isSsc()">
              <span :class="{'tab-tr_blue1':v<=4,'tab-tr_red2':v>4}"
                    v-for="(v,i) in historyNumber[i]">{{ v > 4 ? "大" : "小" }}</span>
            </div>
          </li>
        </ul>
        <ul v-show="historySingleOrEvenShow">
          <li class="cf" v-for="(item,i) in historyData">
            <div class="issue_list issue_inline">
              <b class="num_color">{{ item.lotteryResultNum }}</b>：
            </div>
            <div class="num_list" v-if="is11x5()">
              <span :class="get11x5OddClass(v)"
                    v-for="(v,i) in item.historyNumber">{{get11x5SingleDouble(v)}}</span>
            </div>
            <div class="num_list" v-else>
              <span :class="{'tab-tr_blue1':v%2==0,'tab-tr_red2':v%2!=0}"
                    v-for="(v,i) in item.historyNumber">{{ v % 2 == 0 ? "双" : "单" }}</span>
              <span v-if="isKlc()" class="history_sum"
                    :class="getColor(getHistorySum(i))">{{getHistorySum(i) % 2 == 0 ? "双" : "单"}}</span>
            </div>
          </li>
        </ul>
      </div>
    </div>
  </div>
</template>
<script>
  export default{
    name: 'lottery-history-chart',
    props: {
      pk10Show: {
        type: Boolean,
        default: false
      },
      groupCode: {
        type: String
      },
      gameCode: {
        type: String
      },
      historyData: {
        type: Array,
        default: function () {
          return []
        }
      },
      historyNumber: {
        type: Array,
        default: function () {
          return []
        }
      }
    },
    data () {
      return {
        //切换历史排行显示导航条
        switchHistoryNav: 1,
        hisShow: true,
        //右侧开奖
        historyNumShow: true,
        historyBigOrSmallShow: false,
        historySingleOrEvenShow: false,
      }
    },
    methods: {
      isSsc(){
        return this.groupCode === 'ssc';
      },
      isPk10(){
        return this.groupCode === 'pk10';
      },
      is11x5(){
        return this.groupCode === 'c11x5';
      },
      isKlsf(){
        return this.groupCode === 'klsf';
      },
      isK3(){
        return this.groupCode === 'k3';
      },
      isKlc(){
        return this.groupCode === 'klc';
      },
      isXgc(){
        return this.groupCode === 'xgc';
      },
      isWclhc(){
        return this.gameCode === 'wclhc';
      },
      isKl8(){
        return this.groupCode === 'kl8';
      },
      isSsl(){
        return this.groupCode === 'ssl';
      },
      getXgcClass(){
        return this.isWclhc() ? 'historyPK_issue-ul' : 'history_issue-ul';
      },
      c11x5Class(v){
        if (v == 11)return '和';
        if (v >= 6)return '大';
        else {
          return '小';
        }
      },
      get11x5SingleDouble(v){
        if (v == 11)return '和';
        if (v % 2 == 0)return '双';
        else {
          return '单';
        }
      },
      get11x5OddClass(v){
        if (v == 11)return 'tab-tr_green2';
        if (v % 2 == 0)return 'tab-tr_red2';
        else {
          return 'tab-tr_blue1';
        }
      },
      getIssueClass(){
        if (this.isKlc() || this.isXgc()) {
          if (['wclhc'].indexOf(this.gameCode) !== -1) {
            return 'pcEgg_history_longissue';
          } else {
            return 'pcEgg_history_issue';
          }
        } else if (this.isK3()) {
          return 'happy_history_issue';
        }
      },
      //历史记录移入移除事件
      historyNum: function () {
        this.historyNumShow = true;
        this.historyBigOrSmallShow = false;
        this.historySingleOrEvenShow = false;
        this.switchHistoryNav = 1;
      },
      historyBigOrSmall: function () {
        this.historyNumShow = false;
        this.historyBigOrSmallShow = true;
        this.historySingleOrEvenShow = false;
        this.switchHistoryNav = 2;
      },
      historySingleOrEven: function () {
        this.historyNumShow = false;
        this.historyBigOrSmallShow = false;
        this.historySingleOrEvenShow = true;
        this.switchHistoryNav = 3;
      },
      //pc蛋蛋颜色
      getColor: function (i) {
        if (i == 0 || i == 13 || i == 14 || i == 27) {
          return 'yellow';
        } else if (i == 1 || i == 4 || i == 7 || i == 10 || i == 16 || i == 19 || i == 22 || i == 25) {
          return 'green';
        } else if (i == 2 || i == 5 || i == 8 || i == 11 || i == 17 || i == 20 || i == 23 || i == 26) {
          return '';
        } else {
          return 'red_bg';
        }
      },
      //pc蛋蛋颜色
      get11x5SmallBallClass: function (v) {
        if (v == 11)return 'tab-tr_green2';
        if (v >= 6)return 'tab-tr_red2';
        else {
          return 'tab-tr_blue1';
        }
      },
      //pc蛋蛋历史记录总和
      getHistorySum: function (n) {
        //var singleHistoryNum = this.historyData[n].lotteryNumber.split(" ");
        var singleHistoryNum = this.historyData[n].historyNumber;
        var sum = 0;
        for (let i = 0; i < singleHistoryNum.length; i++) {
          sum += parseInt(singleHistoryNum[i]);
        }
        return sum;
      },
    }
  }
</script>
<style scoped>
.history_issue_list li{
  text-align: left;
}
</style>

