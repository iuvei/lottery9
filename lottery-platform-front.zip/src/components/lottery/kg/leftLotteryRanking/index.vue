<template>
  <div class="phb-left" :class="{active:rankingShow}" v-on:click.stop>
    <div class="phb-btn" @click="rankingShow=!rankingShow">
      <i class="icon-phb"></i>
      <p>排行榜</p>
    </div>
    <div class="phb-win">
      <div class="phb-people">
        <h3>中奖排行</h3>
        <ol>
          <li v-for="(item,index) in randkingData">
            <div class="phb-people-img"><span>{{index + 1}}</span></div>
            <div class="phb-msg">
              <p>{{item.nickName}}</p>
              <small>{{item.gameName}}</small>
              <label v-amount="item.winAmount">元</label>
            </div>
          </li>
        </ol>
      </div>
      <div class="zj-news">
      </div>
      <div class="close" @click="rankingShow=false"></div>
    </div>
  </div>
</template>
<script>
  export default{
    name: 'LotteryRanking',
    props: {
      randkingData: {
        type: Array,
        default: function () {
          return []
        }
      },
      isShow: {
        type: Boolean,
        default: false
      }
    },
    data () {
      return {
        rankingShow: this.isShow
      }
    }
  }
</script>
<style scoped>
  .phb-left{position: fixed;left: 0;top: 256px;color: #7a7a7a;z-index: 4;}
  .phb-btn > p{width: 16px;display: block;line-height: 1.2em;margin: auto;}
  .icon-phb{width: 24px;height: 24px;margin:5px auto;display: block;font:22px iconfont;}
  .icon-phb::after{content:"\e60a";}
  .phb-left .phb-btn{background: #fff;width: 42px;height: 96px;border-radius: 0 4px 4px 0;cursor: pointer;position:relative;z-index:2;padding-top:2px;box-shadow: 0 1px 4px #999;}
  .phb-win{position: absolute;left:-292px;top: 0;background: #fff;width: 280px;text-align: left;color: #5a5a5a;border-radius: 4px;box-shadow: 0 1px 4px #999;cursor: auto;transition:.2s;}
  .phb-left.active .phb-win{left:43px;}
  .phb-win h3{font-size: 14px;text-align: center;border-bottom: 1px solid #ddd;padding-bottom: 10px;margin:15px 0 0;font-weight: bold;}
  .phb-people{padding: 0 15px;min-height:200px;}
  .phb-win .close{position:absolute;right:-12px;top:50%;cursor: pointer;height:60px;width:12px;background:#fff;border-top-right-radius:4px;border-bottom-right-radius:4px;box-shadow:1px 1px 1px #aaa;margin-top:-30px;}
  .phb-win .close::before{content:"";display:block;position:absolute;border-right:5px solid #666;border-top:5px solid transparent;border-bottom:5px solid transparent;left:2px;top:26px;}
  .phb-people li{border-bottom: 1px solid #ddd;padding: 12px 0;cursor: pointer;position: relative;}
  .phb-people li:last-child{border-bottom: 0;}
  .phb-people-img{width:36px;height:36px;display:inline-block;border-radius:50%;overflow:hidden;vertical-align:top;background: #ffc600;text-align:center;color:#fff;}
  .phb-people-img span{display:block;font-size:20px;line-height:36px;}
  .phb-people-img::after{line-height:36px;font:24px iconfont;display:block;padding-top:4px;}
  .phb-msg{display: inline-block;vertical-align: top;margin-left: 10px;color: #9a9a9a;}
  .phb-msg p{margin-bottom: 0;color: #5a5a5a;line-height:18px;height:20px;vertical-align: top;font-size:16px;}
  .phb-msg label{position: absolute;right: 0;top: 18px;color: #fa1f5c;}
  .icon-min-del{position: absolute;right: -8px;top: 7px;width: 10px;height: 10px;display: inline-block;}
  .phb-people .icon-min-del{display: none;}
  .phb-people li:hover .icon-min-del{display: block;}
  .phb-people li:nth-of-type(1) .phb-people-img{background:#ed553d;}
  .phb-people li:nth-of-type(2) .phb-people-img{background:#f27c1c;}
  .phb-people li:nth-of-type(3) .phb-people-img{background:#ffa800;}
  .phb-people li:nth-of-type(1) .phb-people-img span,.phb-people li:nth-of-type(2) .phb-people-img span,.phb-people li:nth-of-type(3) .phb-people-img span{display:none;}
  .phb-people li:nth-of-type(1) .phb-people-img::after,.phb-people li:nth-of-type(2) .phb-people-img::after,.phb-people li:nth-of-type(3) .phb-people-img::after{content:"\e63a";}
</style>
