<template>
  <div class="fl ssc_numBall" @keyup="contentKeyUpFun">
    <div class="ranking beautifyCss02">
      <div class="ssc_numBall_top clearfix mt0">
        <div v-for="(item,x) in firstDataList" :key="x">
          <p class="an_betNumTitle">
            <span>号</span>
            <span>赔率</span>
            <span>下注</span>
          </p>
          <ul>
            <template v-for="(info,y) in item">
              <template v-if="info && info.showName">
                <li class="ripple red_ripple"
                    :class="!integrationArr[getFirstIndex(x,y)]?'':'cur'"
                    :ref="`sscNumBall${getFirstIndex(x,y)}`"
                    :data-x="0" :data-y="getFirstIndex(x,y)" 
                    :data-showCode="info.showCode" 
                    :data-showName="info.showName"
                    :key="y">
                <span class="ranking_type" style="padding-left: 0px" v-if="isNumber(info.showName)"
                      @click="handleAddIntegration(getFirstIndex(x,y))">
                    <span class="icon_squares">{{info.showName}}</span>
                    <span class="ranking_span">{{info.ruleOdds||'0.00'}}</span>
                </span>
                  <span v-else class="ranking_type" @click="handleAddIntegration(getFirstIndex(x,y))"> {{info.showName}}
                   <span class="ranking_span">{{info.ruleOdds||'0.00'}}</span>
                </span>
                  <input type="text" v-model="integrationArr[getFirstIndex(x,y)]">
                </li>
              </template>
              <template v-else>
                <li :key="y"></li>
              </template>
            </template>
          </ul>
        </div>
      </div>
    </div>
    <div class="bet_content_data ssc_numBall_bottom">
      <p><span>{{secondDataList.ruleMasterName}}</span></p>
      <template v-for="(item,x) in secondDataList.gameRuleDetailList">
        <ul class="clearfix" :key="x">
          <template v-for="(info,y) in item">
            <template v-if="info && info.showName">
              <li class="ripple red_ripple"
                  :class="!integrationArr[getSecondIndex(x,y)]?'':'cur'"
                  :ref="`sscNumBall${getSecondIndex(x,y)}`"
                  :data-x="1" :data-y="x*4+y" 
                  :data-showCode="info.showCode" 
                  :data-showName="info.showName"
                  :key="y">
                  <span @click="handleAddIntegration(getSecondIndex(x,y))" class="ranking_type">
                       {{info.showName}} <span>{{info.ruleOdds||'0.00'}}</span>
                  </span>
                <input type="text" v-model="integrationArr[getSecondIndex(x,y)]">
              </li>
            </template>
            <template v-else>
              <li :key="y"></li>
            </template>
          </template>
        </ul>
      </template>
    </div>
  </div>
</template>
<script>
  import setPageData from '../setPageData/index'
  import {isNumber} from '../../../../utils/index'
  import {mapGetters} from 'vuex'
import Vue from 'vue';
  export default{
    name: 'NumBallPan',
    props: {
      renderData: {
        type: Array,
        default: function () {
          return []
        }
      },
      playName: {
        type: String,
        default: ''
      },
      betAmount: {
        type: [String, Number]
      }
    },
    data () {
      return {
        firstDataList: [],
        secondDataList: {
          key:'sum',
          ruleMasterTitle: '总',
          ruleMasterName: '总和/龙虎',
          gameRuleDetailList: [setPageData['ssc']['numBallPan'][0]]
        },  
        newArry:setPageData['ssc']['numBallPan'][1],
        lastData: []
      }
    },
    watch: {
      renderData: function (val) {
        const _this = this;
        if (val && val.length > 0) {
          _this.$nextTick(function () {
            _this.dealData();
            // _this.parseFirstData();
            // _this.parseSecondData();
          });
        }
      }
    },
    computed: {
      ...mapGetters([
        'integrationArr'
      ])
    },
    methods: {
      dealData(){//处理传过来的数据
        let _key,_this=this;
        switch (this.playName) {//获取第几场
          case '第一球':
            _key = 'w';
            break;
          case '第二球':
            _key = 'q';
            break;
          case '第三球':
            _key = 'b';
            break;
          case '第四球':
            _key = 's';
            break;
          case '第五球':
            _key = 'g';
            break;
          default:
            break;
        }
        
        this.newArry.forEach(element => {
          const key = element.showCode.split('-')[0];
          element.showCode = element.showCode.replace(key+'-',_key+'-');
        });

        this.secondDataList.gameRuleDetailList[0].dealData(_this.renderData);
        this.newArry.dealData(_this.renderData);
        //处理数组，显示为每三个一组
        let i = 0;
        this.newArry.forEach(function(item,index){
          if( !(index%3) ){
            Vue.set(_this.firstDataList,i,_this.newArry.slice(index,index+3));
            // _this.firstDataList[i] = _this.newArry.slice(index,index+3);
            i++;
          }
        });
      },
      isNumber,
      contentKeyUpFun: function () {
        this.validationBetAmount();
        this.onBetClick();
      },
      validationBetAmount: function () {
        for (let i = 0; i < this.integrationArr.length; i++) {
          let singleChip = this.integrationArr[i];
          if (singleChip !== undefined && (!isNumber(singleChip) || singleChip * 1 === 0)) {
            this.integrationArr.splice(i, 1, undefined);
          }
        }
      },
      removeBetByIndex: function (index) {
        this.integrationArr.splice(index, 1, undefined);
        this.onBetClick();
      },
      onBetClick: function () {
        this.$emit('onBetClick');
      },
      getBetList: function () {
        const _this = this;
        let arr = [];
        for (let i = 0; i < _this.integrationArr.length; i++) {
          const amount = _this.integrationArr[i];
          if (amount !== undefined && amount !== '') {
            const target = _this.$refs[`sscNumBall${i}`];
            if (target) {
              let showName;
              const renderDataItem = _this.renderData.filter((item,index)=>{
                if( item.showCode == target[0].getAttribute('data-showCode') ){
                  showName = target[0].getAttribute('data-showName');
                  return true;
                }
                 return false;
              })[0];
              
              if(renderDataItem){
                const  {odds,showCode,typeName} = renderDataItem;
                arr.push({
                  title: typeName,
                  ruleName: showName,
                  showCode:showCode,
                  odds: odds,
                  amount: amount,
                  index: i
                });
              }
            }
          }
        }
        return arr;
      },
      getFirstIndex: function (i, n) {
        return n + i * 3;
      },
      getSecondIndex: function (x, y) {
        return 14 + x * 4 + y;
      },
      handleAddIntegration: function (index) {
        this.integrationArr.splice(index, 1, this.integrationArr[index] ? undefined : this.betAmount);
        this.onBetClick();
      },
      parseFirstData: function () {
        if (this.renderData.length > 0) {
          const {gameRuleDetailList} = this.renderData[0];
          let index = 0;
          for (let i = 0; i < gameRuleDetailList.length; i++) {
            if (index < this.firstDataList.length) {
              this.firstDataList[index].splice((i + 3) % 3, 1, gameRuleDetailList[i])
              if ((i + 1) % 3 === 0) {
                index++;
              }
            }
          }
        }
      },
      parseSecondData: function () {
        if (this.renderData.length > 1) {
          const {ruleMasterName, gameRuleDetailList} = this.renderData[1];
          this.secondDataList.ruleMasterName = ruleMasterName;
          let index = 0;
          for (let i = 0; i < gameRuleDetailList.length; i++) {
            if (index < this.secondDataList.gameRuleDetailList.length) {
              this.secondDataList.gameRuleDetailList[index].splice((i + 4) % 4, 1, gameRuleDetailList[i]);
              if ((i + 1) % 4 === 0) {
                index++;
              }
            }
          }
        }
      }
    }
  }
</script>
