<template>
  <div class="ranking beautifyCss01" @keyup="contentKeyUpFun">
    <div class="clearfix mt0">
      <div v-for="(item,x) in firstDataList" :key="x">
        <p>
          <span class="tab-tr_blue1 mr5">{{ item.ruleMasterTitle }}</span>{{ item.ruleMasterName }}
        </p>
        <ul>
          <template v-for="(info,y) in item.gameRuleDetailList">
            <template v-if="info">
              <li class="ripple red_ripple"
                  :class="!integrationArr[0+y+x*14]?'':'cur'"
                  :ref="`ssc_integra_${getIndex(x,y)}`"
                  :data-x="x" :data-y="y" 
                  :data-showCode="info.showCode"
                  :data-showName="info.showName"
                  :key="y">
                <span @click="handleAddIntegration(0+y+x*14)" class="ranking_type">
                    <span :class="{icon_squares:isNumber(info.showName)}">{{info.showName}}</span>
                    <span class="numberValue"> {{info.ruleOdds||'0.00'}} </span>
                </span>
                <input type="text" v-model="integrationArr[0+y+x*14]">
              </li>
            </template>
            <template v-else>
              <li :key="y"><span class="ranking_type"></span></li>
            </template>
          </template>
        </ul>
      </div>
    </div>
  </div>
</template>
<script>
  import {isNumber} from '../../../../utils/index'
  import {mapGetters} from 'vuex'
  import setPageData from '../setPageData/index'
  export default{
    name: 'IntegrationPan',
    props: {
      betAmount: {
        type: [String, Number],
        default: 0
      },
      renderData: {
        type: Array,
        default: function () {
          return []
        }
      }
    },
    watch: {
      renderData: function (val) {
        const _this = this;
        if (val && val.length > 0) {
          _this.$nextTick(function () {
            _this.dealData();
          });
        }
      }
    },
    computed: {
      ...mapGetters([
        'integrationArr'
      ])
    },
    data () {
      return {
        firstDataList: [
          {
            ruleMasterTitle: '万',
            ruleMasterName: '第一球',
            gameRuleDetailList: setPageData['ssc']['integrationPan'][0]
          },
          {
            ruleMasterTitle: '千',
            ruleMasterName: '第二球',
            gameRuleDetailList: setPageData['ssc']['integrationPan'][1]
          },
          {
            ruleMasterTitle: '百',
            ruleMasterName: '第三球',
            gameRuleDetailList: setPageData['ssc']['integrationPan'][2]
          },
          {
            ruleMasterTitle: '十', 
            ruleMasterName: '第四球',
            gameRuleDetailList: setPageData['ssc']['integrationPan'][3]
          },
          { 
            ruleMasterTitle: '个',
            ruleMasterName: '第五球',
            gameRuleDetailList: setPageData['ssc']['integrationPan'][4]
          }]
      }
    },
    methods: {
      dealData(){//处理传过来的数据
        const _this = this;
        this.firstDataList.forEach(element => {
          element.gameRuleDetailList.dealData(_this.renderData);
        });
      },
      isNumber,
      removeBetByIndex: function (index) {
        this.integrationArr.splice(index, 1, undefined);
        this.onBetClick();
      },
      getBetList: function () {
        const _this = this;
        let arr = [];
        for (let i = 0; i < _this.integrationArr.length; i++) {
          const amount = _this.integrationArr[i];
          if (amount !== undefined && amount !== '') {
            const target = _this.$refs[`ssc_integra_${i}`];
            if (target) {
              let showName;
              const renderDataItem = _this.renderData.filter((item,index)=>{
                if( item.showCode == target[0].getAttribute('data-showCode') ){
                  showName = target[0].getAttribute('data-showName');
                  return true;
                }
                 return false;
              })[0];
              
              if(renderDataItem){
                const  {odds,showCode,typeName} = renderDataItem;
                arr.push({
                  title: typeName,
                  ruleName: showName,
                  showCode:showCode,
                  odds: odds,
                  amount: amount,
                  index: i
                });
              }
            }
          }
        }
        return arr;
      },
      getIndex: function (i, n) {
        return (n + i * 14);
      },
      handleAddIntegration: function (index) {
        this.integrationArr.splice(index, 1, this.integrationArr[index] ? undefined : this.betAmount);
        this.onBetClick();
      },
      contentKeyUpFun: function () {
        this.validationBetAmount();
        this.onBetClick();
      },
      onBetClick: function () {
        this.$emit('onBetClick');
      },
      validationBetAmount: function () {
        for (let i = 0; i < this.integrationArr.length; i++) {
          let singleChip = this.integrationArr[i];
          if (singleChip !== undefined && (!isNumber(singleChip) || singleChip * 1 === 0)) {
            this.integrationArr.splice(i, 1, undefined);
          }
        }
      }
    }
  }
</script>
