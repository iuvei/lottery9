import IntegrationPan from './integrationPan.vue'
import NumBallPan from './numBallPan.vue'
import NumberPan from './numberPan.vue'
import SscTwoSidesPan from './twoSidesPan.vue'

export {IntegrationPan, NumBallPan, NumberPan, SscTwoSidesPan}
