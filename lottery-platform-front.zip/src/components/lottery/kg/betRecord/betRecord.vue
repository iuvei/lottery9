<template>
  <div class="kg_game_template" style="position: absolute; bottom: 0; top: 0;">
    <div class="detail_r">

      <div class="report_cont" style="padding-top: 0;padding-bottom: 0">
        <div
          style="margin-bottom: 10px;background: #20a0ff;color: #fff;text-align: center;height: 45px;line-height: 45px;font-size: 20px;">
          <el-button icon="arrow-left" type="primary" @click="goBack()"
                     style="float: left;height: 45px;font-size: 20px;">返回游戏
          </el-button>
          <span style="margin-right: 161px">彩票投注记录</span>
        </div>
        <div class="plant_list">
          <div class="screen">
            <dl class="cf">
              <dt>投注时间：</dt>
              <dd>
                <el-date-picker v-model="value4" type="daterange" placeholder="请选择投注时间" :picker-options="pickerOptions2"
                                style="width:350px"></el-date-picker>
              </dd>
              <dd><label class="sreach_num">查询期号：<input type="text" v-model="sreachIndexNo" placeholder="输入期号"
                                                        style="height: 35px"></label>
              </dd>
              <dd><label class="sreach_num">查询订单号：<input type="text" v-model="sreachBillNo" placeholder="输入订单号"
                                                         style="height: 35px"></label>
              </dd>
            </dl>
            <ul class="full_range cf">
              <li @click.stop>
                <label>彩种：</label>
                <div class="ipt bet_lot" :class="{slide:slideLot}" @click="openLot()"><span>{{ lotName}}</span>
                  <ul class="bet_list" :class="{view:slideLot}" @click.stop>
                    <li @click="pickLot($event)" data-id="">全部</li>
                    <li v-for="(item,index) in lotGameList" :data-id="item.gameId" @click="pickLot($event)" :key="index">{{ item.gameName }}
                    </li>
                  </ul>
                </div>
              </li>
              <!-- <li @click.stop>
                <label>玩法：</label>
                <div class="ipt bet_play" :class="{slide:slidePlay}" v-if="gameTypeID==''" @click="notPick('彩种')">
                  <span>{{ gameTypeName }}</span></div>
                <div class="ipt bet_play" :class="{slide:slidePlay}" v-else @click="getUserMasterTop()">
                  <span>{{ gameTypeName }}</span>
                  <ul class="bet_play_list" :class="{view:slidePlay}" @click.stop>
                    <li data-id="" @click="pickGame($event)">全部</li>
                    <li v-for="item in playList" :data-id="item.id" @click="pickGame($event)">{{ item.ruleMasterName }}
                    </li>
                  </ul>
                </div>
                -
                <div class="ipt sm_play" :class="{slide:slideSmPlay}" v-if="playID==''" @click="notPick('玩法类型')">
                  <span>{{ gameSmName }}</span></div>
                <div class="ipt sm_play" :class="{slide:slideSmPlay}" v-else @click="getUserMasterList()">
                  <span>{{ gameSmName }}</span>
                  <ul class="smplay_list" :class="{view:slideSmPlay}" @click.stop>
                    <li data-id="" @click="pickSmType($event)">全部</li>
                    <li v-for="item in gameSmList" :data-id="item.id" @click="pickSmType($event)">{{ item.ruleMasterName
                      }}
                    </li>
                  </ul>
                </div>
              </li> -->
              <li @click.stop>
                <label>状态：</label>
                <div class="ipt stauts" :class="{slide:slideSta}" @click="openStaus()"><span>{{ gameStaus }}</span>
                  <ul class="all_stauts" :class="{view:slideSta}" @click.stop>
                    <li v-for="(val, key) in dicMap" :data-win="key" @click="pickStaus($event)" :key="key">{{val}}</li>
                  </ul>
                </div>
              </li>
              <li @click.stop>
                <label>中奖状态：</label>
                <div class="ipt stauts" :class="{slide:slideResult}"  @click="openResults"><span>{{gameResult.value}}</span>
                  <ul class="all_stauts" :class="{view:slideResult}"  @click.stop>
                    <li v-for="(val, key) in gameResults"  @click="pickGameResults(val)" :key="key">{{val.value}}</li>
                  </ul>
                </div>
              </li>
              <li @click.stop>
                <a class="a_btn a_btn1 bluet ripple" @click="sreachBetCord()">搜索</a>
                <a class="dark a_btn ripple" @click="resetInt()">重置</a>
              </li>
            </ul>
          </div>
          <div class="screen_result">
            <el-table v-loading="listLoading" :data="betCordList" height="550" border style="width: 100%">
              <el-table-column prop="lotteryGameName" label="彩种" align="center" show-overflow-tooltip></el-table-column>
              <el-table-column prop="lotteryGameNum" label="期号" align="center" width="120"
                               show-overflow-tooltip></el-table-column>
              <el-table-column label="投注号码" align="center" width="160">
                <template slot-scope="scope">
                  <span>{{scope.row.masterName}} - {{scope.row.betContent}}</span>
                </template>
              </el-table-column>
              <!-- <el-table-column prop="masterName" label="玩法" align="center" show-overflow-tooltip></el-table-column> -->
              <!-- <el-table-column prop="betContent" label="投注号码" align="center" show-overflow-tooltip></el-table-column> -->
              <el-table-column prop="lotteryResult" label="开奖号码" align="center" show-overflow-tooltip></el-table-column>
              <el-table-column prop="betAmount" label="投注金额" align="center" width="100"></el-table-column>
              <el-table-column prop="odds" label="赔率" align="center" width="80"></el-table-column>
              <el-table-column prop="gameNetBetAmount" label="派彩金额" align="center" width="100"></el-table-column>
              <el-table-column label="状态" align="center" width="80">
                <template slot-scope="scope">
                  <span :class="getBillStatusClass(scope.row.billStatus)">{{scope.row.billStatus | filterBillStatus}}</span>
                </template>
              </el-table-column>
              <el-table-column prop="betTime" label="投注时间" align="center" show-overflow-tooltip></el-table-column>
              <el-table-column prop="billSeqNo" label="订单号" align="center" show-overflow-tooltip></el-table-column>
            </el-table>
          </div>
          <div class="lotGameTotal">
            <el-tag class="elTag">
              <div>总下注笔数</div>
              <count-to class="card-panel-num" :startVal="0"
                        :endVal="lotGameTotal.sumBillSeqNo"
                        :duration="1000"></count-to>
            </el-tag>
            <el-tag class="elTag">
              <div>总下注额</div>
              <count-to class="card-panel-num" :startVal="0"
                        :endVal="lotGameTotal.sumBetAmount"
                        :duration="1000"></count-to>
            </el-tag>
            <el-tag class="elTag">
              <div>总派彩额</div>
              <count-to class="card-panel-num" :startVal="0"
                        :endVal="lotGameTotal.sumGameNetBetAmount"
                        :duration="1000"></count-to>
            </el-tag>
            <el-tag class="elTag">
              <div>下注笔数</div>
              <count-to class="card-panel-num" :startVal="0"
                        :endVal="lotGameTotal.countBillSeqNo"
                        :duration="1000"></count-to>
            </el-tag>
            <el-tag class="elTag">
              <div>下注额</div>
              <count-to class="card-panel-num" :startVal="0"
                        :endVal="lotGameTotal.countBetAmount"
                        :duration="1000"></count-to>
            </el-tag>
            <el-tag class="elTag">
              <div>派彩额</div>
              <count-to class="card-panel-num" :startVal="0"
                        :endVal="lotGameTotal.countGameNetBetAmount"
                        :duration="1000"></count-to>
            </el-tag>
          </div>
          <div class="page_block cf">
            <el-pagination
              @size-change="handleSizeChange"
              @current-change="CurChange"
              :current-page="currentPage"
              :page-sizes="[10, 20, 50]"
              :page-size="pageSize"
              layout="total, sizes, prev, pager, next, jumper"
              :total="cordListNum">
            </el-pagination>
          </div>
        </div><!--彩票投注记录结束-->
      </div>
    </div>
  </div>
</template>

<script>
  import CountTo from 'vue-count-to'
  import {getUserGameBetInfo, getUserGameList, getUserMasterTop, getUserMasterList} from '../../../../api/betRecord'
  let vm = null
  export default {
    components: {CountTo},
    data () {
      return {
        dicMap: {
          '0': '全部',
          '-1': '未派彩',
          '2': '已派彩',
          '3':'撤单'
        },
        listLoading: false,
        lotGameList: [],
        lotGameTotal: {
          sumBillSeqNo: 0,
          sumBetAmount: 0,
          sumGameNetBetAmount: 0,
          countBillSeqNo: 0,
          countBetAmount: 0,
          countGameNetBetAmount: 0
        },
        //是否显示彩种
        slideLot: false,
        //选中彩种名字
        lotName: "全部",
        //选中彩种ID
        gameTypeID: "",
        //是否显示玩法大类
        slidePlay: false,
        //选中玩法大类名字
        gameTypeName: "全部",
        //玩法大类列表
        playList: [],
        //选中玩法大类ID
        playID: "",
        //是否显示玩法小类
        slideSmPlay: false,
        //选中玩法小类名字
        gameSmName: "全部",
        //玩法小类列表
        gameSmList: [],
        //玩法小类ID
        gameSmID: "",
        //投注记录列表
        betCordList: [],
        //是否显示中奖状态
        slideSta: false,
        //选中状态
        gameStaus: "全部",
        //投注中奖状态
        winStatus: "",
        //用户名
        userName: "",
        //ag查询用户名
        agUserName: "",
        //bb查询用户名
        bbUserName: "",
        //pt查询用户名
        ptUserName: "",
        //mg查询用户名
        mgUserName: "",
        //查询订单号
        sreachBillNo: "",
        // 查询期号
        sreachIndexNo: "",
        //日期选择组件
        pickerOptions2: {
          shortcuts: [{
            text: '今天',
            onClick(picker) {
              const end = new Date();
              const start = new Date();
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 1);
              picker.$emit('pick', [start, end]);
            }
          }, {
            text: '最近一周',
            onClick(picker) {
              const end = new Date();
              const start = new Date();
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 7);
              picker.$emit('pick', [start, end]);
            }
          }, {
            text: '最近一个月',
            onClick(picker) {
              const end = new Date();
              const start = new Date();
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 30);
              picker.$emit('pick', [start, end]);
            }
          }, {
            text: '最近三个月',
            onClick(picker) {
              const end = new Date();
              const start = new Date();
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 90);
              picker.$emit('pick', [start, end]);
            }
          }, {
            text: '近半年',
            onClick(picker) {
              const end = new Date();
              const start = new Date();
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 180);
              picker.$emit('pick', [start, end]);
            }
          }]
        },
        //筛选时间
        value4: [],
        //记录总条数
        cordListNum: 0,
        //当前页码
        currentPage: 1,
        pageSize: 10,
        //开始时间
        betTimeBg: "",
        //结束时间
        betTimeEnd: "",
        gameResults: [
          {
            key: '',
            value: '全部'
          },{
            key: 0,
            value: '未开奖'
          },{
            key: 1,
            value: '未中奖'
          },{
            key: 2,
            value: '已中奖'
          }
        ],
        gameResult: {
          key: '',
          value: '全部'
        },
        slideResult: ''
      }
    },
    beforeRouteEnter(to, from, next){
      next(vm => {
        if (from.path == "/") return false;
        vm.getUserGameBetInfo();
        vm.getUserGameList();
        $(document).on("click", function () {
          vm.slideLot = false;
          vm.slidePlay = false;
          vm.slideSmPlay = false;
          vm.slideSta = false;
          $.each(vm.betCordList, function (i, e) {
            e.showMoreNum = false;
          });

        });
      });
    },
    created(){
      vm = this;
      this.$parent.footHtmlShow = false;
      this.sreachBetCord();
      this.getUserGameList();
    },
    beforeRouteLeave(to, from, next){
      next(true);
      $(document).off("click");
    },
    computed: {
      query: function () {
        return {
          pageSize: this.pageSize,
          pageNum: this.currentPage,
          betTimeBg: this.betTimeBg,
          betTimeEnd: this.betTimeEnd,
          sreachIndexNo: this.sreachIndexNo,
          sreachBillNo: this.sreachBillNo,
          gameTypeID: this.gameTypeID,
          playID: this.playID,
          gameSmID: this.gameSmID,
          winStatus: this.winStatus,
          openResultStatus: this.gameResult && this.gameResult['key']
        }
      }
    },
    filters: {
      filterBillStatus(val){
        return vm.dicMap[val] || val;
      }
    },
    methods: {
      getBillStatusClass(val){
        return val == 2 ? 'green' : 'red';
      },
      goBack(){
        this.$router.go(-1)
      },
      //获取彩种
      getUserGameList(){
        getUserGameList().then(res => {
          this.lotGameList = res.currentData;
        }).catch(error => {

        })
      },
      //展开玩法大类下拉
      getUserMasterTop(){
        this.slidePlay ? this.slidePlay = false : this.slidePlay = true;
        this.slideLot = this.slideSmPlay = this.slideSta = false;
        getUserMasterTop({gameId: this.gameTypeID}).then(res => {
          this.playList = res.currentData
        }).catch(error => {

        })
      },
      //展开玩法小类下拉
      getUserMasterList(){
        this.slideSmPlay ? this.slideSmPlay = false : this.slideSmPlay = true;
        this.slidePlay = this.slidePlay = this.slideSta = false;
        getUserMasterList({gameId: this.gameTypeID, masterId: this.playID}).then(res => {
          this.gameSmList = res.currentData
        }).catch(error => {

        })
      },
      //获取列表
      getUserGameBetInfo(){
        this.listLoading = true;
        getUserGameBetInfo(this.query).then(res => {
          this.listLoading = false;
          const {currentStatus, currentData} = res;
          if (currentStatus === 0 && currentData) {
            const {list, total, proxyGameBetInfoVo} = currentData;
            this.cordListNum = total;
            this.betCordList = list;
            this.lotGameTotal = proxyGameBetInfoVo
          } else {
            this.$message.error('加载数据失败');
          }
        }).catch(error => {
          this.listLoading = false;
        })
      },
      //展开彩种下拉
      openLot: function () {
        this.slideLot ? this.slideLot = false : this.slideLot = true;
        this.slidePlay = this.slideSmPlay = this.slideSta = false;
      },
      //选择彩种
      pickLot: function (event) {
        this.lotName = $(event.target).text();
        this.gameTypeID = $(event.target).attr("data-id");
        this.slideLot = false;
//        if(this.gameTypeID==""){
        this.playID = "";
        this.gameSmID = "";
        this.gameTypeName = "全部";
        this.gameSmName = "全部";
//        }
      },
      //选择玩法大类
      pickGame: function (event) {
        this.gameTypeName = $(event.target).text();
        this.playID = $(event.target).attr("data-id");
        this.slidePlay = false;
//        if(this.playID == ""){
        this.gameSmID = "";
        this.gameSmName = "全部";
//        }
      },
      //选择玩法小类
      pickSmType: function (event) {
        this.gameSmName = $(event.target).text();
        this.gameSmID = $(event.target).attr("data-id");
        this.slideSmPlay = false;
      },
      //展开中奖状态下拉
      openStaus: function () {
        this.slideSta ? this.slideSta = false : this.slideSta = true;
        this.slidePlay = this.slidePlay = this.slideLot = false;
      },
      //选择中奖状态
      pickStaus: function (event) {
        this.gameStaus = $(event.target).text();
        this.winStatus = $(event.target).attr("data-win");
        this.slideSta = false;
      },
      //展开中奖状态下拉
      openResults: function () {
        this.slideResult = !this.slideResult;
      },
      pickGameResults: function (item) {
        this.gameResult = item;
        this.slideResult = false
      },
      //搜索投注记录(可加参数)
      sreachBetCord: function () {
        if (this.value4.length > 0 && this.value4[0] != '' && this.value4[0] != null && this.value4[0] != undefined) {
          this.betTimeBg = new Date(this.value4[0]).format("yyyy-MM-dd 00:00:00");
          this.betTimeEnd = new Date(this.value4[1]).format("yyyy-MM-dd 23:59:59");

        } else {
          this.betTimeBg = "";
          this.betTimeEnd = ""
        }

        this.getUserGameBetInfo()
      },

      //重置搜索选项
      resetInt: function () {
        this.gameTypeName = this.lotName = this.gameSmName = this.gameStaus = "全部";
        this.gameTypeID = this.playID = this.gameSmID = this.userName = "";
        this.sreachBillNo = this.sreachIndexNo = "";
        this.currentPage = 1;
      },
      //翻页
      CurChange: function (val) {
        this.currentPage = val;
        this.getUserGameBetInfo()
      },
      handleSizeChange(val) {
        this.pageSize = val;
        this.getUserGameBetInfo()
      },
      //用户未选择
      notPick: function (txt) {
        this.$message({
          message: '您还未选择' + txt,
          type: 'warning'
        });
      }
    }
  }
</script>

<style scoped>
  .red {
    color: red;
  }

  .green {
    color: green;
  }

  .lotGameTotal {
    padding-top: 10px;
    overflow: hidden;
    padding-right: 40px;
    text-align: center;
    background: #ebedf2;
  }

  .lotGameTotal .elTag {
    display: inline-block;
    background-color: #fff;
    border: 1px solid #e2e6eb;
    height: 88px;
    width: 124px;
    font-size: 16px;
    padding-top: 20px;
    color: #000;
    text-align: center;
    border-radius: 10px;
    vertical-align: middle;
  }

  .lotGameTotal .elTag div {
    margin-bottom: 10px;
  }

  .lotGameTotal .elTag span {
    font-size: 18px;
    color: #3393e0;
  }

  .page_block {
    padding-bottom: 53px;
    background: #ebedf2;
  }

  .page_block .el-pagination {
    float: none;
    text-align: center;
  }

  .detail_r {
    padding-bottom: 0;
    width: 1300px;
    margin: 50px auto;
    border-radius: 5px;
  }
</style>

