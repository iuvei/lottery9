<template>
  <div class="ranking" @keyup="contentKeyUpFun">
    <div class="clearfix mt0">
      <div v-for="(item,x) in firstDataList" :key="x">
        <p>
          <span class="tab-tr_blue1 mr5">{{ item.ruleMasterTitle }}</span>{{ item.ruleMasterName }}
        </p>
        <ul>
          <template v-for="(info,y) in item.gameRuleDetailList">
            <template v-if="info && info.showName">
              <li class="ripple red_ripple"
                  :class="!integrationArr[0+y+x*14]?'':'cur'"
                  @click="handleAddIntegration(0+y+x*14)"
                  :ref="`ssc_integra_${getIndex(x,y)}`"
                  :data-x="x" :data-y="y" 
                  :data-showCode="info.showCode" 
                  :data-showName="info.showName"
                  :key="y">
                <span class="ranking_type">
                    <span :class="{icon_squares:isNumber(info.showName)}">{{info.showName}}</span>
                    <span> {{info.ruleOdds ||'0.00'}} </span>
                </span>
                <input type="text" v-model="integrationArr[0+y+x*14]">
              </li>
            </template>
            <template v-else>
              <li :key="y"><span class="ranking_type"></span></li>
            </template>
          </template>
        </ul>
      </div>
    </div>
  </div>
</template>
<script>
  import {isNumber} from '../../../../utils/index'
  import setPageData from '../setPageData/index'
  import {mapGetters} from 'vuex'
  export default{
    name: 'SslIntegration',
    props: {
      betAmount: {
        type: [String, Number],
        default: 0
      },
      renderData: {
        type: Array,
        default: function () {
          return []
        }
      }
    },
    watch: {
      renderData: function (val) {
        const _this = this;
        if (val && val.length > 0) {
          _this.$nextTick(function () {
            _this.getFirstData();
          });
        }
      }
    },
    computed: {
      ...mapGetters([
        'integrationArr'
      ])
    },
    data () {
      return {
        firstDataList: [
          {
            ruleMasterTitle: '万',
            ruleMasterName: '第一球',
            gameRuleDetailList: [{}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}]
          },
          {
            ruleMasterTitle: '千',
            ruleMasterName: '第二球',
            gameRuleDetailList: [{}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}]
          },
          {
            ruleMasterTitle: '百',
            ruleMasterName: '第三球',
            gameRuleDetailList: [{}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}]
          }
        ]
      }
    },
    methods: {
      isNumber,
      getFirstData: function () {
        if (this.renderData.length > 0) {
          for (let x = 0; x < this.renderData.length; x++) {
            if (x < this.firstDataList.length) {
              const {ruleMasterName, gameRuleDetailList} = this.renderData[x];
              const names = ruleMasterName.split('');
              this.firstDataList[x].ruleMasterTitle = names.shift();
              this.renderData[x].ruleMasterName = this.firstDataList[x].ruleMasterName = names.join('');
              if (!gameRuleDetailList && !gameRuleDetailList instanceof Array) return;
              for (let y = 0; y < gameRuleDetailList.length; y++) {
                if (y < this.firstDataList[x].gameRuleDetailList.length) {
                  this.firstDataList[x].gameRuleDetailList.splice((y + 14) % 14, 1, gameRuleDetailList[y]);
                }
              }
            }
          }
        }
      },
      removeBetByIndex: function (index) {
        this.integrationArr.splice(index, 1, undefined);
        this.onBetClick();
      },
      getBetList: function () {
        const _this = this;
        let arr = [];
        for (let i = 0; i < _this.integrationArr.length; i++) {
          const amount = _this.integrationArr[i];
          if (amount !== undefined && amount !== '') {
            const target = _this.$refs[`ssc_integra_${i}`];
            if (target) {
              let showName;
              const renderDataItem = _this.renderData.filter((item,index)=>{
                if( item.showCode == target[0].getAttribute('data-showCode') ){
                  showName = target[0].getAttribute('data-showName');
                  return true;
                }
                 return false;
              })[0];
              
              if(renderDataItem){
                const  {odds,showCode,typeName} = renderDataItem;
                arr.push({
                  title: typeName,
                  ruleName: showName,
                  showCode:showCode,
                  odds: odds,
                  amount: amount,
                  index: i
                });
              }
            }
          }
        }
        return arr;
      },
      getIndex: function (i, n) {
        return (n + i * 14);
      },
      handleAddIntegration: function (index) {
        this.integrationArr.splice(index, 1, this.integrationArr[index] ? undefined : this.betAmount);
        this.onBetClick();
      },
      contentKeyUpFun: function () {
        this.validationBetAmount();
        this.onBetClick();
      },
      onBetClick: function () {
        this.$emit('onBetClick');
      },
      validationBetAmount: function () {
        for (let i = 0; i < this.integrationArr.length; i++) {
          let singleChip = this.integrationArr[i];
          if (singleChip !== undefined && (!isNumber(singleChip) || singleChip * 1 === 0)) {
            this.integrationArr.splice(i, 1, undefined);
          }
        }
      }
    }
  }
</script>
<style scoped lang="less">
.ranking{
  &>div{
    &>div{
      width: 33.3333%;
      p{
        width: 100%;
      }
      li{
        width: 100%;
      }
    }
  }
}
.ranking_type > span:last-of-type {
  margin: 0 25px;
  color: #ff004e;
}
</style>
