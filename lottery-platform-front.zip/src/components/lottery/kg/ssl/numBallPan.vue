<template>
  <div class="fl ssc_numBall" @keyup="contentKeyUpFun">
    <div class="ranking">
      <div class="ssc_numBall_top clearfix mt0">
        <div v-for="(item,x) in firstDataList" style="width: 198px" :key="x">
          <p class="an_betNumTitle" style="width: 100%">
            <span style="margin-left: 20px;">号</span>
            <span>赔率</span>
            <span>下注</span>
          </p>
          <ul>
            <template v-for="(info,y) in item">
              <template v-if="info && info.showName">
                <li class="ripple red_ripple"
                    :class="!integrationArr[getFirstIndex(x,y)]?'':'cur'"
                    @click="handleAddIntegration(getFirstIndex(x,y))"
                    :ref="`sscNumBall${getFirstIndex(x,y)}`"
                    :data-x="0" :data-y="getFirstIndex(x,y)"
                    :data-showCode="info.showCode"
                    :data-showName="info.showName"
                    :key="y"
                    style="width: 198px">
                <span class="ranking_type" v-if="isNumber(info.showName)">
                    <span class="icon_squares">{{info.showName}}</span>
                    <span class="ranking_span">{{info.ruleOdds ||'0.00'}}</span>
                </span>
                  <span v-else class="ranking_type"> {{info.showName}}
                   <span class="ranking_span">{{info.ruleOdds ||'0.00'}}</span>
                </span>
                  <input type="text" v-model="integrationArr[getFirstIndex(x,y)]">
                </li>
              </template>
              <template v-else>
                <li :key="y"></li>
              </template>
            </template>
          </ul>
        </div>
      </div>
    </div>
    <div class="bet_content_data ssc_numBall_bottom">
      <p><span>{{secondDataList.ruleMasterName}}</span></p>
      <template v-for="(item,x) in secondDataList.gameRuleDetailList">
        <ul class="clearfix" :key="x">
          <template v-for="(info,y) in item">
            <template v-if="info && info.showName">
              <li class="ripple red_ripple"
                  :class="!integrationArr[getSecondIndex(x,y)]?'':'cur'"
                  @click="handleAddIntegration(getSecondIndex(x,y))"
                  :ref="`sscNumBall${getSecondIndex(x,y)}`"
                  :data-x="1" :data-y="x*4+y" 
                  :data-showCode="info.showCode" 
                  :data-showName="info.showName"
                  :key="y">
                  <span class="ranking_type">
                       {{info.showName}} <span>{{info.ruleOdds ||'0.00'}}</span>
                  </span>
                <input type="text" v-model="integrationArr[getSecondIndex(x,y)]">
              </li>
            </template>
            <template v-else>
              <li :key="y"></li>
            </template>
          </template>
        </ul>
      </template>
    </div>
  </div>
</template>
<script>
  import {isNumber} from '../../../../utils/index'
  import setPageData from '../setPageData/index'
  import {mapGetters} from 'vuex'
  export default{
    name: 'SslNumBall',
    props: {
      renderData: {
        type: Array,
        default: function () {
          return []
        }
      },
      playName: {
        type: String,
        default: ''
      },
      betAmount: {
        type: [String, Number]
      }
    },
    data () {
      return {
        firstDataList: setPageData['ssl']['numBallPan'][0],
        secondDataList: {ruleMasterName: '总和/龙虎', gameRuleDetailList: [setPageData['ssl']['numBallPan'][1], [{}, {}, {}, {}]]},
        lastData: []
      }
    },
    created() {
      this.dealData(); 
    },
    watch: {
      renderData: function (val) {
        const _this = this;
        if (val && val.length > 0) {
          _this.$nextTick(function () {
            _this.dealData();
            // _this.parseFirstData();
            // _this.parseSecondData();
          });
        }
      },
      playName(){
        this.dealData();
      }
    },
    computed: {
      ...mapGetters([
        'integrationArr'
      ])
    },
    methods: {
      dealData(){//处理传过来的数据
        const _this = this;
        let _index = this.getTitleIndex(this.playName);//表示当前第几球
        let showCodePre = '';
        if( _index == 1 ){
          showCodePre = '1';
        }else if( _index == 2 ){
          showCodePre = '2';
        }else if( _index == 3 ){
          showCodePre = '3';
        }

        if( _index &&  showCodePre ){
          this.firstDataList.forEach(function(item,index){
            item.forEach(function(_item,_index){
              _item.showCode = showCodePre + '-' + _item.showCode.split('-')[1];
            });
            item.dealData(_this.renderData);
          });
        }else{
          throw new Error('未知异常，判定当前属于第几球失败');
        }

        //处理第二个数组
        this.secondDataList.gameRuleDetailList[0].dealData(this.renderData);
      },
      getTitleIndex(index){
        let _index;
        switch (index) {
          case '第一球':
            _index = 1;
            break;
          case '第二球':
            _index = 2;
            break;
          case '第三球':
            _index = 3;
            break;
          default:
            break;
        }
        return _index;
      },
      isNumber,
      contentKeyUpFun: function () {
        this.validationBetAmount();
        this.onBetClick();
      },
      validationBetAmount: function () {
        for (let i = 0; i < this.integrationArr.length; i++) {
          let singleChip = this.integrationArr[i];
          if (singleChip !== undefined && (!isNumber(singleChip) || singleChip * 1 === 0)) {
            this.integrationArr.splice(i, 1, undefined);
          }
        }
      },
      removeBetByIndex: function (index) {
        this.integrationArr.splice(index, 1, undefined);
        this.onBetClick();
      },
      onBetClick: function () {
        this.$emit('onBetClick');
      },
      getBetList: function () {
        const _this = this;
        let arr = [];
        for (let i = 0; i < _this.integrationArr.length; i++) {
          const amount = _this.integrationArr[i];
          if (amount !== undefined && amount !== '') {
            const target = _this.$refs[`sscNumBall${i}`];
            if (target) {
              let showName;
              const renderDataItem = _this.renderData.filter((item,index)=>{
                if( item.showCode == target[0].getAttribute('data-showCode') ){
                  showName = target[0].getAttribute('data-showName');
                  return true;
                }
                 return false;
              })[0];
              
              if(renderDataItem){
                const  {odds,showCode,typeName} = renderDataItem;
                arr.push({
                  title: typeName,
                  ruleName: showName,
                  showCode:showCode,
                  odds: odds,
                  amount: amount,
                  index: i
                });
              }
            }
          }
        }
        return arr;
      },
      getFirstIndex: function (i, n) {
        return n + i * 4;
      },
      getSecondIndex: function (x, y) {
        return 16 + x * 4 + y;
      },
      handleAddIntegration: function (index) {
        this.integrationArr.splice(index, 1, this.integrationArr[index] ? undefined : this.betAmount);
        this.onBetClick();
      },
      parseFirstData: function () {
        if (this.renderData.length > 0) {
          const {gameRuleDetailList} = this.renderData[0];
          let index = 0;
          for (let i = 0; i < gameRuleDetailList.length; i++) {
            if (index < this.firstDataList.length) {
              this.firstDataList[index].splice((i + 4) % 4, 1, gameRuleDetailList[i])
              if ((i + 1) % 4 === 0) {
                index++;
              }
            }
          }
        }
      },
      parseSecondData: function () {
        if (this.renderData.length > 1) {
          const {ruleMasterName, gameRuleDetailList} = this.renderData[1];
          this.secondDataList.ruleMasterName = ruleMasterName;
          let index = 0;
          for (let i = 0; i < gameRuleDetailList.length; i++) {
            if (index < this.secondDataList.gameRuleDetailList.length) {
              this.secondDataList.gameRuleDetailList[index].splice((i + 4) % 4, 1, gameRuleDetailList[i]);
              if ((i + 1) % 4 === 0) {
                index++;
              }
            }
          }
        }
      }
    }
  }
</script>
