import SslIntegration from './integrationPan.vue'
import SslNumBall from './numBallPan.vue'
import SslNumber from './numberPan.vue'
import SslTwoSides from './twoSidesPan.vue'
import SslkdPan from './kdPan.vue'
import SslhsPan from './hsPan.vue'

export {SslIntegration, SslNumBall, SslNumber, SslTwoSides,SslkdPan,SslhsPan}
