<template>
  <div class="fl ssc_two">
    <div class="bet_content_data" v-for="(item,x) in firstDataList"
         @keyup="contentKeyUpFun"
         :key="x">
      <p>
          <span>
              <span class="tab-tr_blue1 mr5">{{ item.ruleMasterTitle }}</span>{{ item.ruleMasterName }}
          </span>
      </p>
      <ul class="clearfix">
        <template v-for="(info,y) in item.gameRuleDetailList">
          <template v-if="info && info.showName">
            <li class="ripple red_ripple"
                :class="!integrationArr[getIndex(x,y)]?'':'cur'"
                @click="handleAddIntegration(y+x*8)"
                :ref="'ssc_twosides_'+getIndex(x,y)"
                :data-x="x" :data-y="y" 
                :data-showCode="info.showCode" 
                :data-showName="info.showName"
                :key="y">
                <span class="ranking_type">
                  {{info.showName}}<span>{{info.ruleOdds ||'0.00'}}</span>
                </span>
              <input type="text" v-model="integrationArr[getIndex(x,y)]">
            </li>
          </template>
          <template v-else>
            <li :key="y"></li>
          </template>
        </template>
      </ul>
    </div>
  </div>
</template>
<script>
  import {isNumber, allIsNumber} from '../../../../utils/index'
  import setPageData from '../setPageData/index'
  import {mapGetters} from 'vuex'
  export default{
    name: 'SslTwoSides',
    props: {
      renderData: {
        type: Array,
        default: function () {
          return []
        }
      },
      betAmount: {
        type: [String, Number]
      }
    },
    data () {
      return {
        firstDataList: [{
          ruleMasterTitle: '百',
          ruleMasterName: '十合数',
          gameRuleDetailList: setPageData['ssl']['hsPan'][0]
        }, {
          ruleMasterTitle: '百',
          ruleMasterName: '个和数',
          gameRuleDetailList: setPageData['ssl']['hsPan'][1]
        }, {
          ruleMasterTitle: '十',
          ruleMasterName: '个合数',
          gameRuleDetailList: setPageData['ssl']['hsPan'][2]
        }, {
          ruleMasterTitle: '百',
          ruleMasterName: '十个和数',
          gameRuleDetailList: setPageData['ssl']['hsPan'][3]
        }],
        betTitle: [["万", "千", "百", "十", "个", "龙"], ["第一球", "第二球", "第三球", "第四球", "第五球", "总和/龙虎"]],
        betTwoVal: ["大", "小", "单", "双"],
        betTotalVal: ["总和大", "总和小", "总和单", "总和双"],
        betDragonTiger: ["龙", "虎", "和"]
      }
    },
    watch: {
      renderData: function (val) {
        const _this = this;
        if (val && val.length > 0) {
          _this.$nextTick(function () {
            _this.dealData();
            // _this.getFirstData();
          });
        }
      }
    },
    computed: {
      ...mapGetters([
        'integrationArr'
      ])
    },
    methods: {
      dealData(){//处理传过来的数据
        const _this = this;
        this.firstDataList.forEach((element,index) => {
          element.gameRuleDetailList.dealData(_this.renderData);
        });
      },
      getFirstData: function () {
        if (!this.renderData && !this.renderData instanceof Array) return;
        if (this.renderData.length > 0) {
          for (let x = 0; x < this.renderData.length; x++) {
            if (x < this.firstDataList.length) {
              const {ruleMasterName, gameRuleDetailList} = this.renderData[x];
              const names = ruleMasterName.split('');
              this.firstDataList[x].ruleMasterTitle = names.shift();
              this.renderData[x].ruleMasterName = this.firstDataList[x].ruleMasterName = names.join('');
              if (!gameRuleDetailList && !gameRuleDetailList instanceof Array) return;
              for (let y = 0; y < gameRuleDetailList.length; y++) {
                if (y < this.firstDataList[x].gameRuleDetailList.length) {
                  this.firstDataList[x].gameRuleDetailList.splice((y + 8) % 8, 1, gameRuleDetailList[y]);
                }
              }
            }
          }
        }
      },
      contentKeyUpFun: function () {
        this.validationBetAmount();
        this.onBetClick();
      },
      validationBetAmount: function () {
        for (let i = 0; i < this.integrationArr.length; i++) {
          let singleChip = this.integrationArr[i];
          if (singleChip !== undefined && (!isNumber(singleChip) || singleChip * 1 === 0)) {
            this.integrationArr.splice(i, 1, undefined);
          }
        }
      },
      getIndex(i, n){
        return n + i * 8;
      },
      removeBetByIndex: function (index) {
        this.integrationArr.splice(index, 1, undefined);
        this.onBetClick();
      },
      onBetClick: function () {
        this.$emit('onBetClick');
      },
      getBetList: function () {
        const _this = this;
        let arr = [];
        for (let i = 0; i < this.integrationArr.length; i++) {
          const amount = this.integrationArr[i];
          if (amount !== undefined && amount !== '') {
            const target = _this.$refs[`ssc_twosides_${i}`];
            if (target) {
              let showName;
              const renderDataItem = _this.renderData.filter((item,index)=>{
                if( item.showCode == target[0].getAttribute('data-showCode') ){
                  showName = target[0].getAttribute('data-showName');
                  return true;
                }
                 return false;
              })[0];
              
              if(renderDataItem){
                const  {odds,showCode,typeName} = renderDataItem;
                arr.push({
                  title: typeName,
                  ruleName: showName,
                  showCode:showCode,
                  odds: odds,
                  amount: amount,
                  index: i
                });
              }
            }
          }
        }
        return arr;
      },
      handleAddIntegration: function (index) {
        this.integrationArr.splice(index, 1, this.integrationArr[index] ? undefined : this.betAmount);
        this.onBetClick();
      }
    }
  }
</script>