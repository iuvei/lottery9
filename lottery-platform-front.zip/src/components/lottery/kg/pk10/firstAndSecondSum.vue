<template>
  <div class="fl pk10_airmender">
    <div class="ranking">
      <div class="bet_content_data mt0" @keyup="contentKeyUpFun">
        <p><span>{{firstDataList.ruleMasterName}}</span></p>
        <ul class="clearfix an_oddsNum">
          <template v-for="(item,x) in firstDataList.gameRuleDetailList">
            <template v-if="item && item.showName">
              <li class="add_style ripple red_ripple"
                  :ref="`pk10FASsum${x}`"
                  :data-x="0" :data-y="x" 
                  :data-showCode="item.showCode" 
                  :data-showName="item.showName"
                  :key="x"
                  :class="!integrationArr[x]?'':'cur'">
                <span @click="handleAddIntegration(x)" class="ranking_type">
                    <span class="icon_squares">{{item.showName}}</span>
                    <span class="w44">{{item.ruleOdds ||'0.00'}}</span>
                </span>
                <input type="text" v-model="integrationArr[x]">
              </li>
            </template>
            <template v-else>
              <li :key="x"></li>
            </template>
          </template>
        </ul>
        <ul class="clearfix an_odds">
          <template v-for="(item,x) in lastDataList.gameRuleDetailList">
            <template v-if="item && item.showName">
              <li class="ripple red_ripple"
                  :ref="`pk10FASsum${getIndex(1,x)}`"
                  :data-x="0" :data-y="getIndex(1,x)" 
                  :data-showCode="item.showCode" 
                  :data-showName="item.showName"
                  :key="x"
                  :class="!integrationArr[getIndex(1,x)]?'':'cur'">
           <span @click="handleAddIntegration(getIndex(1,x))" class="ranking_type">
             {{item.showName}} <span>{{item.ruleOdds ||'0.00'}}</span>
           </span>
                <input type="text" v-model="integrationArr[getIndex(1,x)]">
              </li>
            </template>
            <template v-else>
              <li :key="x"></li>
            </template>
          </template>
        </ul>
      </div>
    </div>
  </div>

</template>
<script>
  import setPageData from '../setPageData/index'
  import {isNumber} from '../../../../utils/index'
  import {mapGetters} from 'vuex'
  export default{
    name: 'first-and-second-sum',
    props: {
      renderData: {
        type: Array,
        default: function () {
          return []
        }
      },
      betAmount: {
        type: [String, Number],
        default: 0
      },
      playName: {
        type: String,
        default: ''
      }
    },
    data () {
      return {
        firstDataList: {
          ruleMasterName: '冠、亚军和',
          gameRuleDetailList: setPageData['pk10']['firstAndSecondSum'][0]
        },
        lastDataList: {ruleMasterName: '', gameRuleDetailList:setPageData['pk10']['firstAndSecondSum'][1]}
      }
    },
    watch: {
      renderData: function (val) {
        const _this = this;
        if (val && val.length > 0) {
          _this.$nextTick(function () {
            // _this.parseData();
            _this.dealData();
          });
        }
      }
    },
    computed: {
      ...mapGetters([
        'integrationArr'
      ])
    },
    methods: {
      dealData(){//处理传过来的数据
        this.firstDataList.gameRuleDetailList.dealData(this.renderData);
        this.lastDataList.gameRuleDetailList.dealData(this.renderData);
      },
      getIndex(x, y){
        return this.firstDataList.gameRuleDetailList.length * x + y;
      },
      removeBetByIndex: function (index) {
        this.integrationArr.splice(index, 1, undefined);
        this.onBetClick();
      },
      onBetClick: function () {
        this.$emit('onBetClick');
      },
      getBetList: function () {
        const _this = this;
        let arr = [];
        for (let i = 0; i < this.integrationArr.length; i++) {
          const amount = this.integrationArr[i];
          if (amount !== undefined && amount !== '') {
            const target = _this.$refs[`pk10FASsum${i}`];
            if (target) {
              let showName;
              const renderDataItem = _this.renderData.filter((item,index)=>{
                if( item.showCode == target[0].getAttribute('data-showCode') ){
                  showName = target[0].getAttribute('data-showName');
                  return true;
                }
                 return false;
              })[0];
              
              if(renderDataItem){
                const  {odds,showCode,typeName} = renderDataItem;
                arr.push({
                  title: typeName,
                  ruleName: showName,
                  showCode:showCode,
                  odds: odds,
                  amount: amount,
                  index: i
                });
              }
            }
          }
        }
        return arr;
      },
      contentKeyUpFun: function () {
        this.validationBetAmount();
        this.onBetClick();
      },
      validationBetAmount: function () {
        for (let i = 0; i < this.integrationArr.length; i++) {
          let singleChip = this.integrationArr[i];
          if (singleChip !== undefined && (!isNumber(singleChip) || singleChip * 1 === 0)) {
            this.integrationArr.splice(i, 1, undefined);
          }
        }
      },
      handleAddIntegration: function (index) {
        this.integrationArr.splice(index, 1, this.integrationArr[index] ? undefined : this.betAmount);
        this.onBetClick()
      },
      parseData: function () {
        if (this.renderData.length > 0) {
          for (let x = 0; x < this.renderData.length; x++) {
            if (x < 1) {
              const {ruleMasterName, gameRuleDetailList} = this.renderData[x];
              this.firstDataList.ruleMasterName = ruleMasterName;
              const firstChildrenLen = this.firstDataList.gameRuleDetailList.length,
                lastChildrenLen = this.lastDataList.gameRuleDetailList.length;
              for (let y = 0; y < gameRuleDetailList.length; y++) {
                if (y < firstChildrenLen) {
                  this.firstDataList.gameRuleDetailList.splice(y, 1, gameRuleDetailList[y]);
                } else {
                  if ((y - firstChildrenLen) < lastChildrenLen) {
                    this.lastDataList.gameRuleDetailList.splice((y - firstChildrenLen), 1, gameRuleDetailList[y]);
                  }
                }
              }
            }
          }
        }
      }
    }
  }
</script>
<style lang="less" scoped>
.kg_content .game-play-content .an_oddsNum input{
  display: inline-block;
  vertical-align: 15px;
}
</style>

