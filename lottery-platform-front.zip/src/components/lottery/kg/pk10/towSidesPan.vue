<template>
  <div class="fl pk10_two" @keyup="contentKeyUpFun">
    <div class="bet_content_data">
      <p>{{firstDataList.ruleMasterName}}</p>
      <ul class="clearfix">
        <template v-for="(item,x) in firstDataList.gameRuleDetailList">
          <template v-if="item && item.showName">
            <li class="ripple red_ripple"
                :class="!integrationArr[x]?'':'cur'"
                :ref="`pk10towSides${x}`"
                :data-x="0" :data-y="x" 
                :data-showCode="item.showCode"
                :data-showName="item.showName"
                :key="x">
                <span @click="handleAddIntegration(x)" class="pk10_ranking_type">
                    <span>{{item.showName}}</span>
                    <span>{{item.ruleOdds ||'0.00'}}</span>
                </span>
              <input type="text" v-model="integrationArr[x]">
            </li>
          </template>
          <template v-else>
            <li :key="x"></li>
          </template>
        </template>
      </ul>
    </div>
    <div class="ranking">
      <div class="top_five clearfix">
        <div v-for="(item,x) in secondDataList" :key="x">
          <p>{{item.ruleMasterName}}</p>
          <ul>
            <template v-for="(info,y) in item.gameRuleDetailList">
              <template v-if="info && info.showName">
                <li class="ripple red_ripple"
                    :ref="`pk10towSides${getSecondIndex(x,y)}`"
                    :data-x="1+x" :data-y="y" 
                    :data-showCode="info.showCode"
                    :data-showName="info.showName"
                    :key="y"
                    :class="!integrationArr[getSecondIndex(x,y)]?'':'cur'">
                    <span @click="handleAddIntegration(getSecondIndex(x,y))" class="ranking_type">
                    <span>{{info.showName}}</span>
                      <span class="red">{{info.ruleOdds ||'0.00'}}</span>
                    </span>
                  <input type="text" v-model="integrationArr[getSecondIndex(x,y)]">
                </li>
              </template>
              <template v-else>
                <li :key="y"></li>
              </template>
            </template>
          </ul>
        </div>
      </div>
      <div class="last_five clearfix">
        <div v-for="(item,x) in lastDataList" :key="x">
          <p> {{item.ruleMasterName}} </p>
          <ul>
            <template v-for="(info,y) in item.gameRuleDetailList">
              <template v-if="info && info.showName">
                <li class="ripple red_ripple"
                    :ref="`pk10towSides${getLastIndex(x,y)}`"
                    :data-x="6+x" :data-y="y"
                    :data-showCode="info.showCode"
                    :data-showName="info.showName"
                    :key="y"
                    :class="!integrationArr[getLastIndex(x,y)]?'':'cur'">
                  <span @click="handleAddIntegration(getLastIndex(x,y))" class="ranking_type">
                    <span>{{info.showName}}</span>
                    <span class="red">{{info.ruleOdds ||'0.00'}}</span>
                  </span>
                  <input type="text" v-model="integrationArr[getLastIndex(x,y)]">
                </li>
              </template>
              <template v-else>
                <li :key="y"></li>
              </template>
            </template>
          </ul>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
  import {isNumber} from '../../../../utils/index'
  import setPageData from '../setPageData/index'
  import {mapGetters} from 'vuex'
  export default{
    name: 'PkTowSidesPan',
    props: {
      renderData: {
        type: Array,
        default: function () {
          return []
        }
      },
      betAmount: {
        type: [Number, String]
      }
    },
    watch: {
      renderData: function (val) {
        const _this = this;
        if (val && val.length > 0) {
          _this.$nextTick(function () {
            _this.dealData();
            // _this.parseFirstData();
            // _this.parseSecondData();
            // _this.parseLastData();
          });
        }
      }
    },
    data () {
      return {
        firstDataList: {ruleMasterName: '冠、亚军和', gameRuleDetailList: setPageData['pk10']['towSidesPan'][0]},
        secondDataList: [
          {ruleMasterName: '冠军', gameRuleDetailList: setPageData['pk10']['towSidesPan'][1]},
          {ruleMasterName: '亚军', gameRuleDetailList: setPageData['pk10']['towSidesPan'][2]},
          {ruleMasterName: '第三名', gameRuleDetailList: setPageData['pk10']['towSidesPan'][3]},
          {ruleMasterName: '第四名', gameRuleDetailList: setPageData['pk10']['towSidesPan'][4]},
          {ruleMasterName: '第五名', gameRuleDetailList: setPageData['pk10']['towSidesPan'][5]}],
        lastDataList: [
          {ruleMasterName: '第六名', gameRuleDetailList: setPageData['pk10']['towSidesPan'][6]},
          {ruleMasterName: '第七名', gameRuleDetailList: setPageData['pk10']['towSidesPan'][7]},
          {ruleMasterName: '第八名', gameRuleDetailList: setPageData['pk10']['towSidesPan'][8]},
          {ruleMasterName: '第九名', gameRuleDetailList: setPageData['pk10']['towSidesPan'][9]},
          {ruleMasterName: '第十名', gameRuleDetailList: setPageData['pk10']['towSidesPan'][10]}],
        towData: [],
        threeData: []
      }
    },
    computed: {
      ...mapGetters([
        'integrationArr'
      ])
    },
    methods: {
      dealData(){//处理传过来的数据
        const _this = this;
        this.firstDataList.gameRuleDetailList.dealData(this.renderData);
        
        this.secondDataList.forEach(element => {
          element.gameRuleDetailList.dealData(_this.renderData);
        });

        this.lastDataList.forEach(element => {
          element.gameRuleDetailList.dealData(_this.renderData);
        });
      },
      getSecondIndex: function (i, n) {
        return 4 + i * 6 + n;
      },
      getLastIndex: function (i, n) {
        return 34 + i * 4 + n;
      },
      removeBetByIndex: function (index) {
        this.integrationArr.splice(index, 1, undefined);
        this.onBetClick();
      },
      onBetClick: function () {
        this.$emit('onBetClick');
      },
      getBetList: function () {
        const _this = this;
        let arr = [];
        for (let i = 0; i < this.integrationArr.length; i++) {
          const amount = this.integrationArr[i];
          if (amount !== undefined && amount !== '') {
            const target = _this.$refs[`pk10towSides${i}`];
            if (target) {
              let showName;
              const renderDataItem = _this.renderData.filter((item,index)=>{
                if( item.showCode == target[0].getAttribute('data-showCode') ){
                  showName = target[0].getAttribute('data-showName');
                  return true;
                }
                 return false;
              })[0];
              
              if(renderDataItem){
                const  {odds,showCode,typeName} = renderDataItem;
                arr.push({
                  title: typeName,
                  ruleName: showName,
                  showCode:showCode,
                  odds: odds,
                  amount: amount,
                  index: i
                });
              }
            }
          }
        }
        return arr;
      },
      contentKeyUpFun: function () {
        this.validationBetAmount();
        this.onBetClick();
      },
      validationBetAmount: function () {
        for (let i = 0; i < this.integrationArr.length; i++) {
          let singleChip = this.integrationArr[i];
          if (singleChip !== undefined && (!isNumber(singleChip) || singleChip * 1 === 0)) {
            this.integrationArr.splice(i, 1, undefined);
          }
        }
      },
      handleAddIntegration: function (index) {
        this.integrationArr.splice(index, 1, this.integrationArr[index] ? undefined : this.betAmount);
        this.onBetClick()
      },
      parseFirstData: function () {
        if (this.renderData.length > 0) {
          const {ruleMasterName, gameRuleDetailList} = this.renderData[0];
          if (!gameRuleDetailList && !gameRuleDetailList instanceof Array) return;
          this.firstDataList.ruleMasterName = ruleMasterName;
          for (let i = 0; i < gameRuleDetailList.length; i++) {
            if (i < this.firstDataList.gameRuleDetailList.length) {
              this.firstDataList.gameRuleDetailList.splice(i, 1, gameRuleDetailList[i]);
            }
          }
        }
      },
      parseSecondData: function () {
        if (this.renderData.length > 1) {
          for (let x = 1; x < this.renderData.length; x++) {
            if ((x - 1) < this.secondDataList.length) {
              const {ruleMasterName, gameRuleDetailList} = this.renderData[x];
              this.secondDataList[(x - 1)].ruleMasterName = ruleMasterName;
              for (let y = 0; y < gameRuleDetailList.length; y++) {
                if (y < this.secondDataList[(x - 1)].gameRuleDetailList.length) {
                  this.secondDataList[(x - 1)].gameRuleDetailList.splice(y, 1, gameRuleDetailList[y]);
                }
              }
            }
          }
        }
      },
      parseLastData: function () {
        if (this.renderData.length > 6) {
          for (let x = 6; x < this.renderData.length; x++) {
            if ((x - 6) < this.lastDataList.length) {
              const {ruleMasterName, gameRuleDetailList} = this.renderData[x];
              this.lastDataList[(x - 6)].ruleMasterName = ruleMasterName;
              for (let y = 0; y < gameRuleDetailList.length; y++) {
                if (y < this.lastDataList[(x - 6)].gameRuleDetailList.length) {
                  this.lastDataList[(x - 6)].gameRuleDetailList.splice(y, 1, gameRuleDetailList[y]);
                }
              }
            }
          }
        }
      }
    }
  }
</script>
