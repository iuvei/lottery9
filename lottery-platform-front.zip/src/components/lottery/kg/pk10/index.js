import FirstAndSecondSum from './firstAndSecondSum.vue'
import PkNumberPan from './numberPan.vue'
import PkTowSidesPan from './towSidesPan.vue'

export {FirstAndSecondSum, PkNumberPan, PkTowSidesPan}
