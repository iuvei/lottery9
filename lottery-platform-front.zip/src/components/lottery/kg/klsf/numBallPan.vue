<template>
  <div class="fl klsf_num_ball" @keyup="contentKeyUpFun">
    <div class="bet_content_data pc_ball beautifyCss05">
      <p v-for="(_,i) in firstDataList.length" :key="i">
        <span>点数</span>
        <span>赔率</span>
        <span>下注</span>
      </p>
      <ul class="clearfix" v-for="(item,x) in firstDataList" :key="'klsf_'+x">
        <template v-for="(info,y) in item">
          <template v-if="info && info.showName">
            <li class="ripple red_ripple"
                @click="handleAddIntegration(getFirstIndex(x,y))"
                :class="!integrationArr[getFirstIndex(x,y)]?'':'cur'"
                :ref="`klsf_num_ball${getFirstIndex(x,y)}`" 
                :data-x="0" 
                :data-y="getFirstIndex(x,y)"
                :data-showCode="info.showCode"
                :data-showName="info.showName"
                :key="y">
              <span class="ranking_type">
                <span class="klsf_ball" :class="getBallColor(info.showName)">{{info.showName}}</span>
                <span>{{info.ruleOdds ||'0.00'}}</span>
              </span>
              <input type="text" v-model="integrationArr[getFirstIndex(x,y)]"/>
            </li>
          </template>
          <template v-else>
            <li class="ripple" :key="y"><span class="rinking_type"></span></li>
          </template>
        </template>
      </ul>
    </div>
    <div class="bet_content_data second_content">
      <p>{{secondDataList.ruleMasterName}}</p>
      <ul class="clearfix">
        <template v-for="(item,i) in secondDataList.gameRuleDetailList">
          <template v-if="item && item.showName">
            <li class="ripple"
                @click="handleAddIntegration(getSecondIndex(i))"
                :class="!integrationArr[getSecondIndex(i)]?'':'cur'"
                :ref="`klsf_num_ball${getSecondIndex(i)}`" :data-x="1" :data-y="i" 
                :data-showCode="item.showCode"
                :data-showName="item.showName"
                :key="i">
                  <span class="ranking_type">
                     <span>{{item.showName}}</span>
                     <span>{{item.ruleOdds ||'0.00'}}</span>
                  </span>
              <input type="text" v-model="integrationArr[getSecondIndex(i)]">
            </li>
          </template>
          <template v-else>
            <li class="ripple red_ripple" :key="i"><span class="ranking_type"></span></li>
          </template>
        </template>
      </ul>
    </div>
  </div>
</template>

<script>
  import {isNumber} from '../../../../utils/index'
  import setPageData from '../setPageData/index'
  import {mapGetters} from 'vuex'
  export default{
    name: 'PcEgg',
    props: {
      renderData: {
        type: Array,
        default: function () {
          return []
        }
      },
      betAmount: {
        type: [String, Number],
        default: ''
      },
      playName: {
        type: [String, Number],
        default: ''
      }
    },
    data () {
      return {
        pcSelect1: 0,
        pcSelect2: 1,
        pcSelect3: 2,
        newArray:[],
        firstDataList: [
          [{}, {}, {}, {}, {}],
          [{}, {}, {}, {}, {}],
          [{}, {}, {}, {}, {}],
          [{}, {}, {}, {}, {}]],
        secondDataList: {
          ruleMasterName: '两面',
          gameRuleDetailList: setPageData['klsf']['numBallPan'][0]
        }

      }
    },
    watch: {
      renderData: function (val) {
        const _this = this;
        if (val && val.length > 0) {
          _this.$nextTick(function () {
            _this.dealData();
            // _this.parseFirstData();
            // _this.parseSecondData();
          });
        }
      },
      playName(){
        this.dealData();
      }
    },
    computed: {
      ...mapGetters([
        'integrationArr'
      ])
    },
    created() {
      this.dealData(); 
    },
    methods: {
      dealData(){//处理传过来的数据
        const _this = this;
        let _index = this.getTitleIndex(this.playName);//表示当前第几球

        if( _index ){
          let i = 1;
          while ( i < 21 ) {
            this.newArray[i-1] = {
              showCode :_index +'-'+ i,
              showName : i + ''  
            }
            i++;
          }
        }else{
          throw new Error('未知错误，当前title未匹配上');
        }

        //处理数组，显示为每几个一组
        this.newArray.dealData(_this.renderData);
        this.newArray.forEach(function(item,index){
          if( !(index%5) ){
            _this.firstDataList.splice(index/5,1,_this.newArray.slice(index,index+5));//使用该方法赋值，是vue视图渲染不接受常规赋值渲染，因为js特性如此（指针）
          }
        });

        //处理第二个数组
        this.secondDataList.gameRuleDetailList.forEach((item,index)=>{
          item.showCode = _index + item.showCode.slice(1);
        })
        this.secondDataList.gameRuleDetailList.dealData(this.renderData);
      },
      getTitleIndex(index){
        let _index;
        switch (index) {
          case '第一球':
            _index = 1;
            break;
          case '第二球':
            _index = 2;
            break;
          case '第三球':
            _index = 3;
            break;
          case '第四球':
            _index = 4;
            break;
          case '第五球':
            _index = 5;
            break;
          case '第六球':
            _index = 6;
            break;
          case '第七球':
            _index = 7;
            break;
          case '第八球':
            _index = 8;
            break;
          case '第九球':
            _index = 9;
            break;
          default:
            break;
        }
        return _index;
      },
      getBallColor: function (number) {
        if (['1', '4', '7', '10', '13', '16', '19'].indexOf(number) !== -1)return 'klsf_ball_red';
        else if (['2', '5', '8', '11', '14', '17', '20'].indexOf(number) !== -1)return 'klsf_ball_blue';
        else if (['3', '6', '9', '12', '15', '18', '21'].indexOf(number) !== -1)return 'klsf_ball_green';
      },
      onBetClick: function () {
        this.$emit('onBetClick');
      },
      handleAddIntegration: function (index) {
        this.integrationArr.splice(index, 1, this.integrationArr[index] ? undefined : this.betAmount);
        this.onBetClick();
      },
      contentKeyUpFun: function () {
        this.validationBetAmount();
        this.onBetClick();
      },
      validationBetAmount: function () {
        for (let i = 0; i < this.integrationArr.length; i++) {
          let singleChip = this.integrationArr[i];
          if (singleChip !== undefined && (!isNumber(singleChip) || singleChip * 1 === 0)) {
            this.integrationArr.splice(i, 1, undefined);
          }
        }
      },
      parseFirstData: function () {
        const len = 5;
        if (this.renderData.length > 0) {
          const {gameRuleDetailList} = this.renderData[0];
          if (!gameRuleDetailList && !gameRuleDetailList instanceof Array) return;
          let index = 0;
          for (let i = 0; i < gameRuleDetailList.length; i++) {
            if (index < this.firstDataList.length) {
              this.firstDataList[index].splice((i + len) % len, 1, gameRuleDetailList[i]);
              if ((i + 1) % len === 0) {
                index++;
              }
            }
          }
        }
      },
      parseSecondData: function () {
        if (this.renderData.length > 1) {
          const {ruleMasterName, gameRuleDetailList} = this.renderData[1];
          if (!gameRuleDetailList && !gameRuleDetailList instanceof Array) return;
          this.secondDataList.ruleMasterName = ruleMasterName;
          const demoLen = this.secondDataList.gameRuleDetailList.length;
          let dataIndex = 0;
          for (let i = 0; i < demoLen; i++) {
            if (i !== 15) {
              this.secondDataList.gameRuleDetailList.splice(i, 1, gameRuleDetailList.length > dataIndex ? gameRuleDetailList[dataIndex] : {});
              dataIndex++;
            }
          }
        }
      },
      isSpaceBox: function (x, y) {
        return ['1_15'].indexOf(`${x}_${y}`) !== -1;
      },
      getFirstIndex: function (x, y) {
        return y + x * this.firstDataList[0].length
      },
      getSecondIndex: function (i) {
        return 20 + i;
      },
      removeBetByIndex: function (index) {
        this.integrationArr.splice(index, 1, undefined);
        this.onBetClick();
      },
      getBetList: function () {
        const _this = this;
        let arr = [];
        for (let i = 0; i < this.integrationArr.length; i++) {
          const amount = this.integrationArr[i];
          if (amount !== undefined && amount !== '') {
            const target = _this.$refs[`klsf_num_ball${i}`];
            if (target) {
              let showName;
              const renderDataItem = _this.renderData.filter((item,index)=>{
                if( item.showCode == target[0].getAttribute('data-showCode') ){
                  showName = target[0].getAttribute('data-showName');
                  return true;
                }
                 return false;
              })[0];
              
              if(renderDataItem){
                const  {odds,showCode,typeName} = renderDataItem;
                arr.push({
                  title: typeName,
                  ruleName: showName,
                  showCode:showCode,
                  odds: odds,
                  amount: amount,
                  index: i
                });
              }
            }
          }
        }
        return arr;
      },
    },
    mounted(){


    }
  }
</script>

<style scoped lang="less">
  .klsf_num_ball {
    input {
      width: 88px;
      margin: 7px 7px 7px -5px;
    }
    div:first-of-type p {
      display: inline-block;
      width: 198px;
      text-align: left;
      color: #7a7a7a;
    }
    div:first-of-type ul {
      display: inline-block;
      width: 198px;
    }

    div:nth-of-type(2) li:nth-of-type(1),
    div:nth-of-type(2) li:nth-of-type(5),
    div:nth-of-type(2) li:nth-of-type(9),
    div:nth-of-type(3) li:nth-of-type(1),
    div:nth-of-type(3) li:nth-of-type(5),
    div:first-of-type ul:first-of-type li {
      border-left: none;
    }

    .bet_content_data .selectView {
      position: relative;
      display: inline;
      z-index: 1;
    }

    .selectView span {
      position: absolute;
      top: -2px;
      height: 20px;
      width: 23px;
      line-height: 20px;
      color: #6a6a6a;
    }

    .selectView span:nth-of-type(1) {
      left: -6px;
    }

    .selectView span:nth-of-type(2) {
      left: 108px;
    }

    .selectView span:nth-of-type(3) {
      left: 222px;
    }

    .ranking_type {
      width: 103px;
    }

    .klsf_ball {
      float: left;
      width: 30px;
      height: 30px;
      margin: 6px 0 0 10px;
      line-height: 30px;
      color: #fff;
      background: url("../../../../../static/assets/bo.png");
    }

    .klsf_ball_red {
      background: url("../../../../../static/assets/bo.png") 0 44px;
    }

    .klsf_ball_green {
      background: url("../../../../../static/assets/bo.png") 0 132px;
    }

    .klsf_ball_blue {
      background: url("../../../../../static/assets/bo.png") 0 88px;
    }

    .pc_ball p span:first-of-type {
      margin: 0 20px 0 11px;
    }

    .pc_ball p span:nth-of-type(2) {
      margin-right: 33px;
    }

    .second_content .ranking_type {
      text-align: left;
    }

    .second_content .ranking_type span {
      display: inline-block;
      margin: 0;
      text-align: center;
    }

    .second_content .ranking_type span:first-child {
      width: 50px;
    }

    .second_content .ranking_type span:last-child {
      width: 48px;
      margin-left: -5px;
      margin-right: 18px;
    }
    .bet_content_data.beautifyCss05 li span > span:last-child{
      margin-right: 24px;
    }
  }
</style>
