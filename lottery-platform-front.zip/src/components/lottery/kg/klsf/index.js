import KlsfTowSides from './towSides.vue'
import KlsfNumBallPan from './numBallPan.vue'
import KlsfOtherCode from './otherCode.vue'

export {KlsfTowSides, KlsfNumBallPan, KlsfOtherCode}
