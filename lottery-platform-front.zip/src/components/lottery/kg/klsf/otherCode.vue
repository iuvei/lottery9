<template>
  <div class="fl klsf_other_code" @keyup="contentKeyUpFun">
    <div class="bet_content_data clearfix">
      <p>{{firstDataList.ruleMasterName}}</p>
      <ul class="clearfix width198" v-for="(item,x) in firstDataList.gameRuleDetailList" :key="x">
        <template v-for="(info,y) in item">
          <template v-if="info && info.showName">
            <li class="ripple width198"
                :class="!integrationArr[getFirstIndex(x,y)]?'':'cur'"
                :ref="`klsf_other_code${getFirstIndex(x,y)}`"
                :data-x="0" :data-y="getFirstIndex(x,y)" 
                :data-showCode="info.showCode"
                :data-showName="info.showName"
                :key="y">
                <span @click="handleAddIntegration(getFirstIndex(x,y))"
                                                               class="ranking_type"><span class="klsf_ball"
                                                                                          :class="getBallColor(info.showName)">{{info.showName}}</span><span>{{info.ruleOdds ||'0.00'}}</span></span>
              <input type="text" v-model="integrationArr[getFirstIndex(x,y)]">
            </li>
          </template>
          <template v-else>
            <li class="ripple width198" :key="y"><span class="ranking_type"></span></li>
          </template>
        </template>
      </ul>
    </div>

    <div class="bet_content_data">
      <p>{{secondDataList.ruleMasterName}}</p>
      <ul class="clearfix">
        <template v-for="(item,i) in secondDataList.gameRuleDetailList">
          <template v-if="item && item.showName">
            <li class="ripple width264"
                :class="!integrationArr[getSecondIndex(i)]?'':'cur'"
                :ref="`klsf_other_code${getSecondIndex(i)}`"
                :data-x="1" :data-y="i" 
                :data-showCode="item.showCode"
                :data-showName="item.showName"
                :key="i">
                <span @click="handleAddIntegration(getSecondIndex(i))" class="ranking_type">
                  <span>{{item.showName}}</span>
                  <span>{{item.ruleOdds ||'0.00'}}</span>
                </span>
              <input type="text" v-model="integrationArr[getSecondIndex(i)]">
            </li>
          </template>
          <template v-else>
            <li class="ripple width264" :key="i"><span class="ranking_type"></span></li>
          </template>
        </template>
      </ul>
    </div>
  </div>
</template>
<script>
  import {isNumber} from '../../../../utils/index'
  import setPageData from '../setPageData/index'
  import {mapGetters} from 'vuex'
  export default{
    name: 'KlsfOtherCode',
    props: {
      betAmount: {
        type: [String, Number],
        default: ''
      },
      renderData: {
        type: Array,
        default: function () {
          return []
        }
      },
      currCode: {
        type: String
      }
    },
    data () {
      return {
        newArray:[],
        firstDataList: {
          ruleMasterName: '正码',
          gameRuleDetailList: [
            [{}, {}, {}, {}, {}],
            [{}, {}, {}, {}, {}],
            [{}, {}, {}, {}, {}],
            [{}, {}, {}, {}, {}]
          ]
        },
        secondDataList: {
          ruleMasterName: '总和',
          gameRuleDetailList: setPageData['klsf']['otherCode'][0]
        }
      }
    },
    watch: {
      renderData: function (val) {
        const _this = this;
        if (val && val.length > 0) {
          _this.$nextTick(function () {
            _this.dealData();
            // _this.parseFirstData();
            // _this.parseSecondData();
          });
        }
      }
    },
    computed: {
      ...mapGetters([
        'integrationArr'
      ])
    },
    created() {
      this.dealData(); 
    },
    methods: {
      dealData(){//处理传过来的数据
        const _this = this;
        let i = 1;
        while ( i < 21 ) {
          this.newArray[i-1] = {
            showCode :'zm-'+ i,
            showName : i + ''
          }
          i++;
        }

        //处理数组，显示为每几个一组
        this.newArray.dealData(_this.renderData);
        this.newArray.forEach(function(item,index){
          if( !(index%5) ){
            _this.firstDataList.gameRuleDetailList.splice(index/5,1,_this.newArray.slice(index,index+5));//使用该方法赋值，是vue视图渲染不接受常规赋值渲染，因为js特性如此（指针）
          }
        });

        //处理第二个数组
        this.secondDataList.gameRuleDetailList.dealData(this.renderData);
      },
      getBallColor: function (number) {
        if (['1', '4', '7', '10', '13', '16', '19'].indexOf(number) !== -1)return 'klsf_ball_red';
        else if (['2', '5', '8', '11', '14', '17', '20'].indexOf(number) !== -1)return 'klsf_ball_blue';
        else if (['3', '6', '9', '12', '15', '18', '21'].indexOf(number) !== -1)return 'klsf_ball_green';
      },
      getFirstIndex: function (x, y) {
        return y + x * 5
      },
      getSecondIndex: function (i) {
        return i + 20
      },
      parseFirstData: function () {
        const len = 5;
        if (this.renderData.length > 0) {
          const {ruleMasterName, gameRuleDetailList} = this.renderData[0];
          if (!gameRuleDetailList && !gameRuleDetailList instanceof Array) return;
          let index = 0;
          this.firstDataList.ruleMasterName = ruleMasterName;
          for (let i = 0; i < gameRuleDetailList.length; i++) {
            if (index < this.firstDataList.gameRuleDetailList.length) {
              this.firstDataList.gameRuleDetailList[index].splice((i + len) % len, 1, gameRuleDetailList[i]);
              if ((i + 1) % len === 0) {
                index++;
              }
            }
          }
        }
      },
      parseSecondData: function () {
        if (this.renderData.length > 1) {
          const {ruleMasterName, gameRuleDetailList} = this.renderData[1];
          if (!gameRuleDetailList && !gameRuleDetailList instanceof Array) return;
          this.secondDataList.ruleMasterName = ruleMasterName;
          for (let i = 0; i < gameRuleDetailList.length; i++) {
            if (i < this.secondDataList.gameRuleDetailList.length) {
              this.secondDataList.gameRuleDetailList.splice(i, 1, gameRuleDetailList[i]);
            }
          }
        }
      },
      handleAddIntegration: function (index) {
        this.integrationArr.splice(index, 1, this.integrationArr[index] ? undefined : this.betAmount);
        this.onBetClick();
      },
      validationBetAmount: function () {
        for (let i = 0; i < this.integrationArr.length; i++) {
          let singleChip = this.integrationArr[i];
          if (singleChip !== undefined && (!isNumber(singleChip) || singleChip * 1 === 0)) {
            this.integrationArr.splice(i, 1, undefined);
          }
        }
      },
      onBetClick: function () {
        this.$emit('onBetClick');
      },
      contentKeyUpFun: function () {
        this.validationBetAmount();
        this.onBetClick();
      },
      removeBetByIndex: function (index) {
        this.integrationArr.splice(index, 1, undefined);
        this.onBetClick();
      },
      getBetList: function () {
        const _this = this;
        let arr = [];
        for (let i = 0; i < _this.integrationArr.length; i++) {
          const amount = _this.integrationArr[i];
          if (amount !== undefined && amount !== '') {
            const target = _this.$refs[`klsf_other_code${i}`];
            if (target) {
              let showName;
              const renderDataItem = _this.renderData.filter((item,index)=>{
                if( item.showCode == target[0].getAttribute('data-showCode') ){
                  showName = target[0].getAttribute('data-showName');
                  return true;
                }
                 return false;
              })[0];
              
              if(renderDataItem){
                const  {odds,showCode,typeName} = renderDataItem;
                arr.push({
                  title: typeName,
                  ruleName: showName,
                  showCode:showCode,
                  odds: odds,
                  amount: amount,
                  index: i
                });
              }
            }
          }
        }
        return arr;
      },
    }
  }
</script>

<style scoped lang="less">
  .klsf_other_code {
    div:first-of-type ul:first-of-type {
      li {
        border-left: none;
      }
    }
    div:last-of-type ul li:first-of-type,
    div:last-of-type ul li:nth-of-type(4) {
      border-left: none;
    }
    .bet_content_data {
      width: 794px;
      border: 1px solid #e8e8e8;
      background: #fff;
      border-bottom: none;
      .ranking_type {
        width: 103px;
      }
      .klsf_ball {
        float: left;
        width: 30px;
        height: 30px;
        margin: 6px 0 0 10px;
        line-height: 30px;
        color: #fff;
        background: url("../../../../../static/assets/bo.png");
      }
      .klsf_ball_red {
        background: url("../../../../../static/assets/bo.png") 0 44px;
      }

      .klsf_ball_green {
        background: url("../../../../../static/assets/bo.png") 0 132px;
      }

      .klsf_ball_blue {
        background: url("../../../../../static/assets/bo.png") 0 88px;
      }
      .width198 {
        width: 198px;
      }
      .width264 {
        width: 264px;
      }
      .ripple {
        display: inline-block;
        position: relative;
        overflow: hidden;
        -webkit-user-select: none;
        -moz-user-select: none;
        -ms-user-select: none;
        user-select: none;
        transition: all .3s ease-out;
        cursor: pointer;
      }
      ul {
        display: inline-block;
        li {
          float: left;
          height: 44px;
          text-align: center;
          line-height: 44px;
          border: 1px solid #e8e8e8;
          border-bottom: none;
          border-right: none;
          transition: none;
        }
      }
    }
  }
</style>
