<template>
  <div class="fl klsf-two" @keyup="contentKeyUpFun">
    <div class="bet_content_data newCss">
      <p>{{firstDataList.ruleMasterName}}</p>
      <ul class="clearfix">
        <template v-for="(item,x) in firstDataList.gameRuleDetailList">
          <li v-if="item && item.showName" class="ripple red_ripple"
              :class="!integrationArr[x]?'':'cur'"
              :ref="`klsf_tow_sides${x}`"
              :data-x="0" :data-y="x" 
              :data-showCode="item.showCode" 
              :data-showName="item.showName"
              :key="x">
                <span @click="handleAddIntegration(x)" class="pk10_ranking_type beautifyCss04">
                    <span>{{item.showName}}</span>
                    <span>{{item.ruleOdds ||'0.00'}}</span>
                </span>
            <input type="text" v-model="integrationArr[x]">
          </li>
          <li :key="x" class="ripple red_ripple" v-else></li>
        </template>
      </ul>
    </div>

    <div class="ranking">
      <div class="top_five clearfix">
        <div v-for="(item,x) in secondDataList" :key="x">
          <p>{{item.ruleMasterName}}</p>
          <ul>
            <template v-for="(info,y) in item.gameRuleDetailList">
              <template v-if="info && info.showName">
                <li class="ripple red_ripple"
                    :ref="`klsf_tow_sides${getSecondIndex(x,y)}`"
                    :data-x="1+x" :data-y="y" 
                    :data-showCode="info.showCode" 
                    :data-showName="info.showName"
                    :key="y"
                    :class="!integrationArr[getSecondIndex(x,y)]?'':'cur'">
                    <span @click="handleAddIntegration(getSecondIndex(x,y))" class="ranking_type beautifyCss04">
                    <span>{{info.showName}}</span>
                      <span class="red">{{info.ruleOdds ||'0.00'}}</span>
                    </span>
                  <input type="text" v-model="integrationArr[getSecondIndex(x,y)]">
                </li>
              </template>
              <template v-else>
                <li class="ripple red_ripple" :key="y"></li>
              </template>
            </template>
          </ul>
        </div>
      </div>
      <div class="last_five clearfix">
        <div v-for="(item,x) in lastDataList" :key="x">
          <p> {{item.ruleMasterName}} </p>
          <ul>
            <template v-for="(info,y) in item.gameRuleDetailList">
              <template v-if="info && info.showName">
                <li class="ripple red_ripple"
                    :ref="`klsf_tow_sides${getLastIndex(x,y)}`"
                    :data-x="5+x" :data-y="y" 
                    :data-showCode="info.showCode" 
                    :data-showName="info.showName"
                    :key="y"
                    :class="!integrationArr[getLastIndex(x,y)]?'':'cur'">
                  <span @click="handleAddIntegration(getLastIndex(x,y))" class="ranking_type beautifyCss04">
                    <span>{{info.showName}}</span>
                    <span class="red">{{info.ruleOdds ||'0.00'}}</span>
                  </span>
                  <input type="text" v-model="integrationArr[getLastIndex(x,y)]">
                </li>
              </template>
              <template v-else>
                <li class="ripple red_ripple" :key="y"></li>
              </template>
            </template>
          </ul>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
  import {isNumber} from '../../../../utils/index'
  import setPageData from '../setPageData/index'
  import {mapGetters} from 'vuex'
  export default{
    name: 'KlsfTowSides',
    props: {
      renderData: {
        type: Array,
        default: function () {
          return []
        }
      },
      betAmount: {
        type: [Number, String]
      }
    },
    watch: {
      renderData: function (val) {
        const _this = this;
        if (val && val.length > 0) {
          _this.$nextTick(function () {
            _this.dealData();
            // _this.parseFirstData();
            // _this.parseSecondData();
            // _this.parseLastData();
          });
        }
      }
    },
    data () {
      return {
        firstDataList: {ruleMasterName: '总和-龙虎', gameRuleDetailList: setPageData['klsf']['towSides'][0] },
        secondDataList: [
          {ruleMasterName: '第一球', gameRuleDetailList: [{}, {}, {}, {}, {}, {}, {}, {}, {}, {}]},
          {ruleMasterName: '第二球', gameRuleDetailList: [{}, {}, {}, {}, {}, {}, {}, {}, {}, {}]},
          {ruleMasterName: '第三球', gameRuleDetailList: [{}, {}, {}, {}, {}, {}, {}, {}, {}, {}]},
          {ruleMasterName: '第四球', gameRuleDetailList: [{}, {}, {}, {}, {}, {}, {}, {}, {}, {}]}],
        lastDataList: [
          {ruleMasterName: '第五球', gameRuleDetailList: [{}, {}, {}, {}, {}, {}, {}, {}]},
          {ruleMasterName: '第六球', gameRuleDetailList: [{}, {}, {}, {}, {}, {}, {}, {}]},
          {ruleMasterName: '第七球', gameRuleDetailList: [{}, {}, {}, {}, {}, {}, {}, {}]},
          {ruleMasterName: '第八球', gameRuleDetailList: [{}, {}, {}, {}, {}, {}, {}, {}]}],
        towData: [],
        threeData: []
      }
    },
    computed: {
      ...mapGetters([
        'integrationArr'
      ])
    },
    created () {
      const _this = this;
      this.secondDataList.forEach((element,index) => {
        element.gameRuleDetailList = _this.initData(index+1);
      });

      this.lastDataList.forEach((element,index) => {
        element.gameRuleDetailList = _this.initData(index+5);
      });
    },
    methods: {
      dealData(){//处理传过来的数据
        const _this = this;
        this.firstDataList.gameRuleDetailList.dealData(this.renderData);

        this.secondDataList.forEach((element,index) => {
          element.gameRuleDetailList.dealData(_this.renderData);
        });

        this.lastDataList.forEach((element,index) => {
          element.gameRuleDetailList.dealData(_this.renderData);
        });
      },
      initData(index){
        //因为大于第五球的没有龙虎,showCodes内@符号根据index取值
        const showNames = ['大','小','单','双','尾大','尾小','合数单','合数双','龙','虎'];
        const showCodes = ['@-big','@-small','@-single','@-double','@-endbig','@-endsmall','@-sumsingle','@-sumdouble','@-dragon','@-tiger'];
        let newArr = index < 5 ? showNames:showNames.slice(0,showNames.length-2);
        return newArr.map(function(item,_index){
            return {
              showCode: index + '-' + showCodes[_index].split('-')[1] ,
              showName: item,
              ruleOdds: ''
            }
        });
      },
      getSecondIndex: function (i, n) {
        return this.firstDataList.gameRuleDetailList.length + i * this.secondDataList[0].gameRuleDetailList.length + n;
      },
      getLastIndex: function (i, n) {
        return (this.firstDataList.gameRuleDetailList.length +
          this.secondDataList.length *
          this.secondDataList[0].gameRuleDetailList.length) +
          i * this.lastDataList[0].gameRuleDetailList.length + n;
      },
      removeBetByIndex: function (index) {
        this.integrationArr.splice(index, 1, undefined);
        this.onBetClick();
      },
      onBetClick: function () {
        this.$emit('onBetClick');
      },
      getBetList: function () {
        const _this = this;
        let arr = [];
        for (let i = 0; i < this.integrationArr.length; i++) {
          const amount = this.integrationArr[i];
          if (amount !== undefined && amount !== '') {
            const target = _this.$refs[`klsf_tow_sides${i}`];
            if (target) {
              let showName;
              const renderDataItem = _this.renderData.filter((item,index)=>{
                if( item.showCode == target[0].getAttribute('data-showCode') ){
                  showName = target[0].getAttribute('data-showName');
                  return true;
                }
                 return false;
              })[0];
              
              if(renderDataItem){
                const  {odds,showCode,typeName} = renderDataItem;
                arr.push({
                  title: typeName,
                  ruleName: showName,
                  showCode:showCode,
                  odds: odds,
                  amount: amount,
                  index: i
                });
              }
            }
          }
        }
        return arr;
      },
      contentKeyUpFun: function () {
        this.validationBetAmount();
        this.onBetClick();
      },
      validationBetAmount: function () {
        for (let i = 0; i < this.integrationArr.length; i++) {
          let singleChip = this.integrationArr[i];
          if (singleChip !== undefined && (!isNumber(singleChip) || singleChip * 1 === 0)) {
            this.integrationArr.splice(i, 1, undefined);
          }
        }
      },
      handleAddIntegration: function (index) {
        this.integrationArr.splice(index, 1, this.integrationArr[index] ? undefined : this.betAmount);
        this.onBetClick()
      },
      parseFirstData: function () {
        if (this.renderData.length > 0) {
          const {ruleMasterName, gameRuleDetailList} = this.renderData[0];
          if (!gameRuleDetailList && !gameRuleDetailList instanceof Array) return;
          this.firstDataList.ruleMasterName = ruleMasterName;
          const demoLen = this.firstDataList.gameRuleDetailList.length;
          for (let i = 0; i < demoLen; i++) {
            this.firstDataList.gameRuleDetailList.splice(i, 1, gameRuleDetailList.length > i ? gameRuleDetailList[i] : {});
          }
        }
      },
      parseSecondData: function () {
        const len = 1;
        if (this.renderData.length > len) {
          for (let x = 0; x < this.secondDataList.length; x++) {
            const {ruleMasterName, gameRuleDetailList} = this.renderData[x + len] || {
              ruleMasterName: '',
              gameRuleDetailList: []
            };
            this.secondDataList[x].ruleMasterName = ruleMasterName;
            const demoListLen = this.secondDataList[x].gameRuleDetailList.length;
            for (let y = 0; y < demoListLen; y++) {
              this.secondDataList[x].gameRuleDetailList.splice(y, 1, gameRuleDetailList.length > y ? gameRuleDetailList[y] : {});
            }
          }
        }
      },
      parseLastData: function () {
        const len = 5;
        if (this.renderData.length > len) {
          for (let x = 0; x < this.lastDataList.length; x++) {
            const {ruleMasterName, gameRuleDetailList} = this.renderData[x + len] || {
              ruleMasterName: '',
              gameRuleDetailList: []
            };
            this.lastDataList[x].ruleMasterName = ruleMasterName;
            const demoListLen = this.lastDataList[x].gameRuleDetailList.length;
            for (let y = 0; y < demoListLen; y++) {
              this.lastDataList[x].gameRuleDetailList.splice(y, 1, gameRuleDetailList.length > y ? gameRuleDetailList[y] : {});
            }
          }
        }
      }
    }
  }
</script>
<style scoped lang="less">
  .klsf-two {
    .ranking_type {
      width: 103px;
    }
    .ranking {
      div > div {
        float: left;
        width: 198px;
      }
      div > div p {
        width: 200px;
        height: 36px;
        text-align: center;
        line-height: 36px;
        color: #5a5a5a;
        border-left: 1px solid #e8e8e8;
        border-bottom: 1px solid #e8e8e8;
        background: #f8f8f8;
      }
      div > div li {
        width: 200px;
        height: 43px;
        margin-bottom: -3px;
        text-align: center;
        line-height: 43px;
        border-left: 1px solid #e8e8e8;
        border-bottom: 1px solid #e8e8e8;
      }
    }
  }
</style>
