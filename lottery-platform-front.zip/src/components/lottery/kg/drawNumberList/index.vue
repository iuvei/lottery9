<template>
  <div class="top clearfix">
    <div class="kg_lottery_reciprocal fl">
      <div>
        {{gameName}}&nbsp;&nbsp;<span>{{currentIssue}}</span> 期 &nbsp;&nbsp;
        <p>
          离投注截止还有：<span id="betsEndTime">{{gameTime}}</span>
          &nbsp;&nbsp;
          <!--距开奖：<span id="gameGetTime">{{gameLotteryTime}}</span>-->
        </p>
      </div>
    </div>
    <div class="kg_lottery_box fl">
      <div class="fl w655">
        <div class="reciprocal_data">
          第 <span>{{winningIssue}}</span> 期
          <p>开奖号码</p>
        </div>
        <div class="kg_lottery_date_now" :class="{kg_lottery_number:hisShow}">
          <div v-if="winningGet" class="kg-number-title">开奖中...</div>
          <template v-else>
            <ul v-if="gameId == 33" class="clearfix kg-number-new">
              <li class="pcEggSumColor pc_egg_ball" :class="getColor(pcGetSum)">
                <div><span>{{pcGetSum}}</span></div>
              </li>
              <li class="operator">=</li>
              <li class="pc_egg_ball pc_egg_computed">
                <div><span>0</span></div>
              </li>
              <li class="operator">+</li>
              <li class="pc_egg_ball pc_egg_computed">
                <div><span>0</span></div>
              </li>
              <li class="operator">+</li>
              <li class="pc_egg_ball pc_egg_computed">
                <div><span>0</span></div>
              </li>
            </ul>
            <ul v-else class="clearfix kg-number-new">
              <li v-for="(list,index) in lotteryNum" :class="setMarkSixColor()[index]">
                <div><span>{{list}}</span></div>
              </li>
            </ul>
          </template>
        </div>
      </div>
      <div class="kg_explain_tendency fr">
        <p @click="play_dialogVisible=true" class="play_explain">玩法说明</p>
        <p class="play_numberTrend" v-if="gameId!=5&&gameId!=4"><a id="kgTrendLink" target="_blank" :href="trendLink">号码走势</a></p>
      </div>
    </div>
    <!--玩法说明-->
    <el-dialog title="规则" v-model="play_dialogVisible" class="w940">
      <div class="play_box" v-if="gameId==1||gameId==2||gameId==3||gameId==15||gameId==16||gameId==17">
        <h3>高频彩</h3>
        <div>
          <h3>两面玩法</h3>
          <p class="ml25">开奖结果万位、仟位、佰位、拾位或个位数字为1、3、5、7、9时为“单”，若为0、2、4、6、8时为“双”，当投注位数单双与开奖结果的位数单双相符时，即为中奖。</p>
          <p class="ml25">※举例:投注者购买佰位单，当期开奖结果如为20130（1为单），则视为中奖。</p>
        </div>
        <table class="play_dialog_table">
          <tr>
            <th>单</th>
            <th>双</th>
          </tr>
          <tr>
            <td>1、 3、 5、 7、 9</td>
            <td>0、 2、 4、 6、 8</td>
          </tr>
        </table>
        <div>
          <h3>◎大小玩法说明</h3>
          <p class="ml25">开奖结果万位、仟位、佰位、拾位或个位数字为5、6、7、8、9时为“大”，若为0、1、2、3、4时为“小”，当投注位数大小与开奖结果的位数大小相符时，即为中奖。</p>
          <p class="ml25">※举例：投注者购买佰位小，当期开奖结果如为20352（3为小），则视为中奖。</p>
        </div>
        <table class="play_dialog_table">
          <tr>
            <th>大</th>
            <th>小</th>
          </tr>
          <tr>
            <td>5、 6、 7、 8、 9</td>
            <td>0、 1、 2、 3、 4</td>
          </tr>
        </table>
        <div v-for="(v,n) in 2">
          <h3>{{playSSCVal[0][n]}}</h3>
          <p class="ml25">{{playSSCVal[1][n]}}</p>
          <p class="ml25">{{playSSCVal[2][n]}}</p>
          <p class="ml25">{{playSSCVal[3][n]}}</p>
          <p class="ml25">{{playSSCVal[4][n]}}</p>
        </div>
      </div>
      <div class="play_box" v-if="gameId==6||gameId==7||gameId==8">
        <h3>PK10</h3>
        <div>
          <h2>◎单码/双面规则说明</h2>
          <div>
            <h3>◎定位</h3>
            <p class="ml25">指冠军、亚军、季军、第四、第五、第六、第七、第八、第九、第十名出现的顺序与号码为派彩依据</p>
            <p class="ml25">如现场第一个开奖号码为3号，投注冠军为3则视为中奖，其它号码视为不中奖。</p>
          </div>
          <div>
            <h3>◎大小</h3>
            <p class="ml25">开出的号码大于或等于6为大，小于或等于5为小 。</p>
          </div>
          <div>
            <h3>◎单双</h3>
            <p class="ml25">号码为双数叫双，如4、6；号码为单数叫单，如3、5。</p>
          </div>
          <div>
            <h3>◎龙虎</h3>
            <div class="clearfix play_playPrizeBox">
              <ul class="play_playPrize">
                <li v-for="(_,n) in 5">{{playPrizeVal[n]}}</li>
              </ul>
              <ul class="play_playPrize">
                <li v-for="(v,n) in 5">
                  <p>{{playPrizeValRight[0][n]}}</p>
                  <p>{{playPrizeValRight[1][n]}}</p>
                </li>
              </ul>
            </div>
            <div v-for="(v,n) in 3">
              <h3>{{playPrizeBottom[0][n]}}</h3>
              <p class="ml25">{{playPrizeBottom[1][n]}}</p>
            </div>
          </div>
        </div>
      </div>
      <div class="play_box" v-if="gameId == 4">
        <div>
          <h2>◎PC蛋蛋规则说明</h2>
          <div>
            <h3>①.大小玩法</h3>
            <p class="ml25">数字14-27为大 数字0-13为小 出13押小回本金 出14押大回本本金。</p>
          </div>
          <div>
            <h3>②.单双玩法</h3>
            <p class="ml25">数字1，3，5，~27为单 数字0，2，4~26为双 出13压单回本出14押双回本。</p>
          </div>
          <div>
            <h3>③.极值玩法</h3>
            <p class="ml25">[极小0-5] 10倍 [极大22-27] 10倍 举例：买极小100元 开奖结果为0-5其中一个数字就中1000元（包括本金）极大反之。</p>
          </div>
          <div>
            <h3>④.组合玩法</h3>
            <p class="ml25">数字14，16，~26为大双 数字0，2，4，~12为小双。</p>
            <p class="ml25">数字15，17，~27为大单 数字1，3，5，~13为小单。</p>
            <p class="ml25">开13，14组合回本，举例 买100元小单开13就回本金 买100元大双开14就回本金。</p>
            <!-- p class="ml25">其余买大单 小单 大双 小双 奖金为本金的4倍。</p -->
          </div>
          <div>
            <h3>⑤.定位玩法(单点数字玩法)</h3>
            <p class="ml25">从数字0-27中选取一个数字 中奖以对应赔率含本金奖励</p>
          </div>
          <div>
            <h3>⑥.波色</h3>
            <p class="ml25">绿波号码：1 , 4 , 7 , 10 , 16 , 19 , 22 , 25</p>
            <p class="ml25">蓝波号码：2 , 5 , 8 , 11 , 17 , 20 , 23 , 26</p>
            <p class="ml25">红波号码：3 , 6 , 9 , 12 , 15 , 18 , 21 , 24</p>
            <!-- p class="ml25">赔率 1 : 3</p -->
            <p class="ml25">开黄波下注色波任何一个都视为不中奖</p>
          </div>
          <div>
            <h3>⑦.豹子</h3>
            <p class="ml25">当期3个开奖号码一致则中奖, 如当期开奖结果为 3+3+3=9 则中奖豹子</p>
          </div>
          <div>
            <h3>⑧.特码包三</h3>
            <p class="ml25">选取三个特码,三个特码中有任一号码和开奖结果一致即中奖。</p>
          </div>
        </div>
      </div>
      <div class="play_box" v-if="(gameId >= 9 && gameId <= 14)">
        <div>
          <h2>◎快三规则说明</h2>
          <div>
            <h3>◎双面</h3>
            <p class="ml25">以全部开出的三个号码、加起来的总和来判定。</p>
            <p class="ml25">大小：三个开奖号码总和值11~17 为大；总和值4~10 为小；若三个号码相同、则不算中奖(为输)。</p>
          </div>
          <div>
            <h3>◎三军</h3>
            <p class="ml25">三个开奖号码其中一个与所选号码相同时、即为中奖。</p>
            <p class="ml25">※举例：如开奖号码为1、1、3，则投注三军1或三军3皆视为中奖。</p>
            <p class="ml25">※备注：不论当局指定点数出现几次，仅派彩一次(不翻倍)。</p>
          </div>
          <div>
            <h3>◎围骰/全骰</h3>
            <p class="ml25">围骰: 开奖号码三字同号、且与所选择的围骰组合相符时，即为中奖。</p>
            <p class="ml25">全骰: 全选围骰组合、开奖号码三字同号，即为中奖。</p>
          </div>
          <div>
            <h3>◎点数</h3>
            <p class="ml25">开奖号码总和值为4、5、6、7、8、9、10、11、12、13、14、15、16、17 时，即为中奖；若开出3、18，则不算中奖。</p>
            <p class="ml25">※举例：如开奖号码为1、2、3、总和值为6、则投注「6」即为中奖。</p>
          </div>
          <div>
            <h3>◎长牌</h3>
            <p class="ml25">任选一长牌组合、当开奖结果任2码与所选组合相同时，即为中奖。</p>
            <p class="ml25">※举例：如开奖号码为1、2、3、则投注长牌12、长牌23、长牌13皆视为中奖。</p>
          </div>
          <div>
            <h3>◎短牌</h3>
            <p class="ml25">开奖号码任两字同号、且与所选择的短牌组合相符时，即为中奖。</p>
            <p class="ml25">※举例：如开奖号码为1、1、3、则投注短牌1、1，即为中奖。</p>
          </div>
        </div>
      </div>
      <div class="play_box" v-if="gameId == 5">
        <div>
          <h2>◎香港六合彩规则说明</h2>
          <div>
            <h3>1.特码</h3>
            <p class="ml25">香港六合彩公司当期开出的最後一码为特码。</p>
          </div>
          <div>
            <h3>2.特码大小</h3>
            <p class="ml25">特小：开出的特码，(01~24)小于或等于24。</p>
            <p class="ml25">特大：开出的特码，(25~48)小于或等于48。</p>
          </div>
          <div>
            <h3>3.特码单双</h3>
            <p class="ml25">特双：特码为双数，如18、20、34、42。</p>
            <p class="ml25">特单：特码为单数，如01，11，35，47。</p>
          </div>
          <div>
            <h3>4.特码合数单双</h3>
            <p class="ml25">特双：指开出特码的个位加上十位之和为‘双数’，如02，11，33，44。</p>
            <p class="ml25">特单：指开出特码的个位加上十位之和为‘单数’，如01，14，36，47。</p>
          </div>
          <div>
            <h3>5.特码尾数大小</h3>
            <p class="ml25">特尾大：5尾~9尾为大，如05、18、19。</p>
            <p class="ml25">特尾小：0尾~4尾为小，如01，32，44。</p>
          </div>
          <div>
            <h3>6.特码半特</h3>
            <p class="ml25">以特码大小与特码单双游戏为一个投注组合；当期特码开出符合投注组合，即视为中奖；若当期特码开出49号，其余情形视为不中奖。</p>
            <p class="ml25">大单：25、27、29、31、33、35、37、39，41、43、45、47</p>
            <p class="ml25">大双：26、28、30、32、34、36、38、40，42、44、46、48</p>
            <p class="ml25">小单：01、03、05、07、09、11、13、15，17、19、21、23</p>
            <p class="ml25">小双：02、04、06、08、10、12、14、16，18、20、22、24</p>
          </div>
          <div>
            <h3>7.特码合数大小</h3>
            <p class="ml25">合数大：特码的个位加上十位之和来决定大小，和数大于或等于7为大。</p>
            <p class="ml25">合数小：特码的个位加上十位之和来决定大小，和数小于或等于6为小</p>
          </div>
          <div>
            <h3>8.正码</h3>
            <p class="ml25">香港六合彩公司每期开出的前面六个号码为正码，下注号码如在六个正码号码里中奖。</p>
            <p class="ml25">特大：开出的特码，(25~48)小于或等于48。</p>
          </div>
          <div>
            <h3>9.总和大小</h3>
            <p class="ml25">总和大：所以七个开奖号码的分数总和大于或等于175。</p>
            <p class="ml25">总和小：所以七个开奖号码的分数总和小于或等于174。</p>
          </div>
          <div>
            <h3>10.总和单双</h3>
            <p class="ml25">总和单：所以七个开奖号码的分数总和是‘单数’，如分数总和是133、197。</p>
            <p class="ml25">总和双：所以七个开奖号码的分数总和是‘双数’，如分数总和是120、188。</p>
          </div>
          <div>
            <h3>11.特肖</h3>
            <p class="ml25">生肖顺序为 鼠 >牛 >虎 >兔 >龙 >蛇 >马 >羊 >猴 >鸡 >狗 >猪 。</p>
            <p class="ml25">如今年是鸡年，就以羊为开始，依顺序将49个号码分为12个生肖(如下)，再以生肖下注。</p>
            <p class="ml25">鸡 01 , 13 , 25 , 37 , 49</p>
            <p class="ml25">狗 12 , 24 , 36 , 48</p>
            <p class="ml25">猪 11 , 23 , 35 , 47</p>
            <p class="ml25">鼠 10 , 22 , 34 , 46</p>
            <p class="ml25">牛 09 , 21 , 33 , 45</p>
            <p class="ml25">虎 08 , 20 , 32 , 44</p>
            <p class="ml25">兔 07 , 19 , 31 , 43</p>
            <p class="ml25">龙 06 , 18 , 30 , 42</p>
            <p class="ml25">蛇 05 , 17 , 29 , 41</p>
            <p class="ml25">马 04 , 16 , 28 , 40</p>
            <p class="ml25">羊 03 , 15 , 27 , 39</p>
            <p class="ml25">猴 02 , 14 , 26 , 38</p>
            <p class="ml25">若当期特别号，落在下注生肖范围内，视为中奖 。</p>
          </div>
          <div>
            <h3>12.正码1-6</h3>
            <p class="ml25">
              香港六合彩公司当期开出之前6个号码叫正码。第一时间出来的叫正码1，依次为正码2、正码3┅┅ 正码6(并不以号码大小排序)。正码1、正码2、正码3、正码4、正码5、正码6的大小单双合单双和特别号码的大小单双规则相同，如正码1为31，则正码1为大，为单，为合双，为合小；正码2为08，则正码2为小，为双，为合双，为合大；号码为49则为和。假如投注组合符合中奖结果，视为中奖。 正码1-6色波下注开奖之球色与下注之颜色相同时，视为中奖。其余情形视为不中奖。</p>
          </div>
          <div>
            <h3>13.特码色波</h3>
            <p class="ml25">香港六合彩49个号码球分别有红、蓝、绿三种颜色，以特码开出的颜色和投注的颜色相同视为中奖，颜色代表如下:</p>
            <p class="ml25">红波：01 ,02 ,07 ,08 ,12 ,13 ,18 ,19 ,23 ,24 ,29 ,30 ,34 ,35 ,40 ,45 ,46</p>
            <p class="ml25">蓝波：03 ,04 ,09 ,10 ,14 ,15 ,20 ,25 ,26 ,31 ,36 ,37 ,41 ,42 ,47 ,48</p>
            <p class="ml25">绿波：05 ,06 ,11 ,16 ,17 ,21 ,22 ,27 ,28 ,32 ,33 ,38 ,39 ,43 ,44 ,49</p>
          </div>
          <div>
            <h3>10.总和单双</h3>
            <p class="ml25">总和单：所以七个开奖号码的分数总和是‘单数’，如分数总和是133、197。</p>
            <p class="ml25">总和双：所以七个开奖号码的分数总和是‘双数’，如分数总和是120、188。</p>
          </div>
          <div>
            <h3>11.正肖</h3>
            <p class="ml25">以开出的6个正码做游戏，只要有1个落在下注生肖范围内，视为中奖。如超过1个正码落在下注生肖范围内 ，派彩将倍增！如：下注＄100.-正肖龙倍率1.8。</p>
            <p class="ml25">6个正码开出01，派彩为＄80</p>
            <p class="ml25">6个正码开出01，13，派彩为＄160</p>
            <p class="ml25">6个正码开出01，13，25，派彩为＄240</p>
            <p class="ml25">6个正码开出01，13，25，37，派彩为＄320</p>
            <p class="ml25">6个正码开出01，13，25，37，49，派彩为＄320</p>
          </div>
        </div>
      </div>
      <span slot="footer" class="dialog-footer">
                <el-button @click="play_dialogVisible = false">取 消</el-button>
                <el-button type="primary" @click="play_dialogVisible = false">确 定</el-button>
            </span>
    </el-dialog>
  </div>
</template>
<script>
  export default{
    name: 'draw-number-list',
    props: {
      gameId: {
        type: String,
        default: ''
      },
      gameName: {
        type: String,
        default: ''
      },
      lotteryNum: {
        type: Array,
        default: function () {
          return []
        }
      },
      currentIssue: {
        type: String,
        default: ''
      },
      gameTime: {
        type: String,
        default: ''
      },
      winningIssue: {
        type: String,
        default: ''
      },
      hisShow: {
        type: Boolean,
        default: true
      },
      winningGet: {
        type: Boolean,
        default: false
      },
      pcGetSum: {
        type: Number,
        default: 0
      },
      markSixNum: {
        type: String,
        default: ''
      },
      ssc_playShow: {
        type: Boolean,
        default: false
      },
      pk10_playShow: {
        type: Boolean,
        default: false
      }
    },
    data () {
      return {
        //Kg所有彩种
        lotteryKgOption: [],
        play_dialogVisible: false,
        //高频彩玩法静态值
        playSSCVal: [["◎龙虎和玩法说明", "◎总和玩法说明"],
          ["龙：开出之号码第一球(万位)的中奖号码大于第五球(个位)的中奖号码，如出和局为打和。如：第一球开出4，第五球开出2； 第一球开出9，第五球开出8； 第一球开出5，第五球开出1...中奖为龙。",
            "总大：开奖结果5个号码加起的总和，大于等于23为总大。※举例：投注者购买总和大，当期开奖结果如为总数为28，则视为中奖。"],
          ["虎：开出之号码第一球(万位)的中奖号码小于第五球(个位)的中奖号码，如出和局为打和。如：第一球开出7，第五球开出9； 第一球开出3，第五球开出5； 第一球开出5，第五球开出8...中奖为虎。",
            "总小：开奖结果5个号码加起的总和，小于等于22为总小。※举例：投注者购买总和小，当期开奖结果如为总数为18，则视为中奖。"],
          ["和：开出之号码第一球(万位)的中奖号码等于第五球(个位)的中奖号码 如：2***2则投注和局者视为中奖，其他视为不中奖。",
            "总单：开奖结果5个号码加起的总和为单数。※举例：投注者购买总和单，当期开奖结果如为总数为29，则视为中奖。"],
          ["", "总双：开奖结果5个号码加起的总和为双数。※举例：投注者购买总和双，当期开奖结果如为总数为18，则视为中奖。"]],
        //pk10玩法静态值
        playPrizeVal: ["冠军龙虎", "亚军龙虎", "季军龙虎", "第四名龙虎", "第五名龙虎"],//pk10表格左边
        //pk10表格右边
        playPrizeValRight: [["* 龙：冠军号码大于第十名号码视为“龙”中奖，如冠军开出07，第十名开出03。",
          "* 龙：亚军号码大于第九名号码视为“龙”中奖，如亚军开出07，第九名开出03。",
          "* 龙：季军号码大于第八名号码视为“龙”中奖，如季军开出07，第八名开出03。",
          "* 龙：第四名号码大于第七名号码视为“龙”中奖，如第四名开出07，第七名开出03。",
          "* 龙：第五名号码大于第六名号码视为“龙”中奖，如第五名开出07，第六名开出03。"],
          ["* 虎：冠军号码小于第十名号码视为“虎”中奖，如冠军开出03，第十名开出07。",
            "* 虎：亚军号码小于第九名号码视为“虎”中奖，如亚军开出03，第九名开出07。",
            "* 虎：季军号码小于第八名号码视为“虎”中奖，如季军开出03，第八名开出07。",
            "* 虎：第四名号码小于第七名号码视为“虎”中奖，如第四名开出03，第七名开出07。",
            "* 虎：第五名号码小于第六名号码视为“虎”中奖，如第五名开出03，第六名开出07。"]],
        //pk10后面三个
        playPrizeBottom: [["◎冠亚军和", "◎冠亚军和大小", "◎冠亚军和单双",],
          ["冠军号码与亚军号码的和值区间为3~19，当投注组合符合冠亚军和值，即视为中奖 ",
            "当开奖结果冠军号码与亚军号码的和值大于11为大，投注“和大”则视为中奖；小于等于11为小，投注“和小”则视为中奖。",
            "当开奖结果冠军号码与亚军号码的和值为单数如9、13，投注“和单”则视为中奖；为双数如12、16，投注“和双”则视为中奖。"]],
      }
    },
    computed: {
      trendLink(){
        return 'index.html#/trend/' + this.gameId;
      }
    },
    methods: {
      getColor: function (numColor) {
        if (numColor == 0 || numColor == 13 || numColor == 14 || numColor == 27) {
          return 'yellow';
        } else if (numColor == 1 || numColor == 4 || numColor == 7 || numColor == 10 || numColor == 16 || numColor == 19 || numColor == 22 || numColor == 25) {
          return 'green';
        } else if (numColor == 2 || numColor == 5 || numColor == 8 || numColor == 11 || numColor == 17 || numColor == 20 || numColor == 23 || numColor == 26) {
          return '';
        } else {
          return 'red_bg';
        }
      },
      setMarkSixColor: function () {
        var classArr = [];
        var numArr = this.markSixNum.split(" ").reverse();
        for (let i = 0; i < numArr.length; i++) {
          if (numArr[i].charAt(0) == 0) {
            numArr[i] = numArr[i].charAt(1);
          }
        }
        for (let j = 0; j < numArr.length; j++) {
          switch (this.gameId / 1) {
            case 34:
              classArr.push(this.markSixballColor(numArr[j]) + ' pc_egg_ball');
              break;
            case 32:
            case 38:
            case 39:
              classArr.push('pc_egg_ball');
              break;
          }
        }
        return classArr;
      },
      //香港彩波色类名计算
      markSixballColor: function (n) {
        switch (true) {
          case n == 1 || n == 2 || n == 7 || n == 8 || n == 12 || n == 13 || n == 18 || n == 19 || n == 23 || n == 24 || n == 29 || n == 30 || n == 34 || n == 35 || n == 40 || n == 45 || n == 46:
            return "red_ball";
            break;
          case n == 3 || n == 4 || n == 9 || n == 10 || n == 14 || n == 15 || n == 20 || n == 25 || n == 26 || n == 31 || n == 36 || n == 37 || n == 41 || n == 42 || n == 47 || n == 48:
            return "blue_ball";
            break;
          case n == 5 || n == 6 || n == 11 || n == 16 || n == 17 || n == 21 || n == 22 || n == 27 || n == 28 || n == 32 || n == 33 || n == 38 || n == 39 || n == 43 || n == 44 || n == 49:
            return "green_ball";
            break;
        }
      }
    }
  }
</script>
