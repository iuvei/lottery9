export default {
  show: false,
  drawAnimation: ["1", "2", "3", "4", "5", "6", "7", "8", "9", "0"],
  plays: {
    ssc_zhp: {
      show: false,
      isDewdropShow: true,
      winLongRankShow: true,
      ref: 'sscIntegration'
    },
    ssc_lmp: {
      show: false,
      isDewdropShow: true,
      winLongRankShow: true,
      ref: 'sscTwoSidesPan'
    },
    ssc_szp: {
      show: false,
      isDewdropShow: true,
      winLongRankShow: true,
      ref: 'sscNumberPan'
    },
    ssc_dyq: {
      show: false,
      isDewdropShow: true,
      winLongRankShow: true,
      ref: 'sscNumberBall'
    },
    ssc_deq: {
      show: false,
      isDewdropShow: true,
      winLongRankShow: true,
      ref: 'sscNumberBall'
    },
    ssc_dsanq: {
      show: false,
      isDewdropShow: true,
      winLongRankShow: true,
      ref: 'sscNumberBall'
    },
    ssc_dsiq: {
      show: false,
      isDewdropShow: true,
      winLongRankShow: true,
      ref: 'sscNumberBall'
    },
    ssc_dwq: {
      show: false,
      isDewdropShow: true,
      winLongRankShow: true,
      ref: 'sscNumberBall'
    },
  }
}
