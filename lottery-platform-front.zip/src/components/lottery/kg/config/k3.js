export default {
  show: false,
  drawAnimation: ["1", "2", "3", "4", "5", "6"],
  plays: {
    ks_sb: {
      show: false,
      isDewdropShow: false,
      winLongRankShow: false,
      ref: 'happyThree'
    },
  }
}
