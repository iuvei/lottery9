export default {
  show: false,
  drawAnimation: ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20"],
  plays: {
    klsf_lmp: {
      show: false,
      isDewdropShow: true,
      winLongRankShow: true,
      ref: 'klsf_tow_sides_ref'
    },
    klsf_dyq: {
      show: false,
      isDewdropShow: true,
      winLongRankShow: true,
      ref: 'klsf_num_ball_ref'
    },
    klsf_deq: {
      show: false,
      isDewdropShow: true,
      winLongRankShow: true,
      ref: 'klsf_num_ball_ref'
    },
    klsf_dsq: {
      show: false,
      isDewdropShow: true,
      winLongRankShow: true,
      ref: 'klsf_num_ball_ref'
    },
    klsf_dsiq: {
      show: false,
      isDewdropShow: true,
      winLongRankShow: true,
      ref: 'klsf_num_ball_ref'
    },
    klsf_dwq: {
      show: false,
      isDewdropShow: true,
      winLongRankShow: true,
      ref: 'klsf_num_ball_ref'
    },
    klsf_dlq: {
      show: false,
      isDewdropShow: true,
      winLongRankShow: true,
      ref: 'klsf_num_ball_ref'
    },
    klsf_dqq: {
      show: false,
      isDewdropShow: true,
      winLongRankShow: true,
      ref: 'klsf_num_ball_ref'
    },
    klsf_dbq: {
      show: false,
      isDewdropShow: true,
      winLongRankShow: true,
      ref: 'klsf_num_ball_ref'
    },
    klsf_zm: {
      show: false,
      isDewdropShow: true,
      winLongRankShow: true,
      ref: 'klsf_other_code_ref'
    }
  }
}
