import xgc from './xgc'
import c11x5 from './c11x5'
import k3 from './k3'
import kl8 from './kl8'
import klc from './klc'
import klsf from './klsf'
import pk10 from './pk10'
import ssc from './ssc'
import ssl from './ssl'

export default {
  xgc,
  k3,
  c11x5,
  kl8,
  klc,
  klsf,
  pk10,
  ssc,
  ssl
}
