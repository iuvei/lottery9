export default {
  show: false,
  drawAnimation: ["01", "02", "03", "04", "05", "06", "07", "08", "09", "00"],
  plays: {
    k8_zm: {
      show: false,
      isDewdropShow: false,
      winLongRankShow: false,
      ref: 'k8Integration'
    },
    k8_lmp: {
      show: false,
      isDewdropShow: false,
      winLongRankShow: false,
      ref: 'k8TwoSidesPan'
    }
  }
}
