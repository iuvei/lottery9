export default {
  show: false,
  drawAnimation: ["1", "2", "3", "4", "5", "6", "7", "8", "9", "0"],
  plays: {
    ssc_zhp: {
      show: false,
      isDewdropShow: false,
      winLongRankShow: false,
      ref: 'sslIntegration'
    },
    ssc_lmp: {
      show: false,
      isDewdropShow: false,
      winLongRankShow: false,
      ref: 'sslTwoSidesPan'
    },
    ssc_szp: {
      show: false,
      isDewdropShow: false,
      winLongRankShow: false,
      ref: 'sslNumberPan'
    },
    ssc_dyq: {
      show: false,
      isDewdropShow: false,
      winLongRankShow: false,
      ref: 'sslNumberBall'
    },
    ssc_deq: {
      show: false,
      isDewdropShow: false,
      winLongRankShow: false,
      ref: 'sslNumberBall'
    },
    ssc_dsq: {
      show: false,
      isDewdropShow: false,
      winLongRankShow: false,
      ref: 'sslNumberBall'
    },
    ssc_kd: {
      show: false,
      isDewdropShow: false,
      winLongRankShow: false,
      ref: 'sslkdPan'
    },
    ssc_hs: {
      show: false,
      isDewdropShow: false,
      winLongRankShow: false,
      ref: 'sslhsPan'
    }
  }
}
