export default {
  show: false,
  drawAnimation: ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31", "32", "33", "34", "35", "36", "37", "38", "39", "40", "41", "42", "43", "44", "45", "46", "47", "48", "49"],
  plays: {
    klc_tm: {
      show: false,
      winLongRankShow: false,
      isDewdropShow: false,
      ref: 'specialCodeShow'
    },
    klc_tx: {
      show: false,
      winLongRankShow: false,
      isDewdropShow: false,
      ref: 'specialAnimalShow'
    },
    klc_zm: {
      show: false,
      winLongRankShow: false,
      isDewdropShow: false,
      ref: 'orthocodeShow'
    },
    klc_zm1: {
      show: false,
      winLongRankShow: false,
      isDewdropShow: false,
      ref: 'orthocodeNumShow'
    },
    klc_zm2: {
      show: false,
      winLongRankShow: false,
      isDewdropShow: false,
      ref: 'orthocodeNumShow'
    },
    klc_zm3: {
      show: false,
      winLongRankShow: false,
      isDewdropShow: false,
      ref: 'orthocodeNumShow'
    },
    klc_zm4: {
      show: false,
      winLongRankShow: false,
      isDewdropShow: false,
      ref: 'orthocodeNumShow'
    },
    klc_zm5: {
      show: false,
      winLongRankShow: false,
      isDewdropShow: false,
      ref: 'orthocodeNumShow'
    },
    klc_zm6: {
      show: false,
      winLongRankShow: false,
      isDewdropShow: false,
      ref: 'orthocodeNumShow'
    },
    klc_tmtw: {
      show: false,
      winLongRankShow: false,
      isDewdropShow: false,
      ref: 'specialCodeHeadAndEndShow'
    },
    klc_wx: {
      show: false,
      winLongRankShow: false,
      isDewdropShow: false,
      ref: 'wuxingAndBanboShow'
    },
    klc_bb: {
      show: false,
      winLongRankShow: false,
      isDewdropShow: false,
      ref: 'wuxingAndBanboShow'
    },
    klc_qm: {
      show: false,
      winLongRankShow: false,
      isDewdropShow: false,
      ref: 'specialCodeQimaShow'
    }
  }
}
