export default {
  show: false,
  drawAnimation: ["01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11"],
  plays: {
    c11x5_lmp: {
      show: false,
      isDewdropShow: true,
      winLongRankShow: true,
      ref: 'c11x5_two_sides_ref'
    },
    c11x5_dm: {
      show: false,
      isDewdropShow: true,
      winLongRankShow: true,
      ref: 'c11x5_single_code_ref'
    }
  }
}
