export default {
  show: false,
  drawAnimation: ["01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "00"],
  plays: {
    pk10_lmp: {
      show: false,
      isDewdropShow: true,
      winLongRankShow: true,
      ref: 'pk10twoSides'
    },
    pk10_1_10m: {
      show: false,
      isDewdropShow: true,
      winLongRankShow: true,
      ref: 'pk10Number'
    },
    pk10_gyh: {
      show: false,
      isDewdropShow: true,
      winLongRankShow: true,
      ref: 'pk10Airmender'
    },
  }
}
