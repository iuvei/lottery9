import ssc from './ssc/index.js'
import pcdd from './pcdd/index.js'
import pk10 from './pk10/index.js'
import k3 from './k3/index.js'
import lottery from './lottery/index.js'
import get11x5 from './11x5/index.js'
import klsf from './klsf/index.js'
import k8 from './k8/index.js'
import ssl from './ssl/index.js'

export default {
    ssc:ssc,
    pcdd:pcdd,
    pk10:pk10,
    k3:k3,
    lottery:lottery,
    get11x5:get11x5,
    klsf:klsf,
    k8:k8,
    ssl:ssl
}