<template>
  <div class="number_select_cont">
    <div v-for="(item,x) in dataList" class="number_select_item">
      <div class="send"
           :class="{active:selectArr[x].length > 0,s_and_d:['ssc_dxds_dxds','ffc_dxds_dxds'].indexOf(playDetailCode)!==-1}">
        {{item.showName}}
      </div>
      <div class="ballNum"
           :class="[ballClass,{s_and_d:['ssc_dxds_dxds','ffc_dxds_dxds'].indexOf(playDetailCode)!==-1}]">
        <a v-for="(numberBall,y) in item.betDetail" @click="selectNum(x,numberBall)" class="num ripple red_ripple"
           :class="{active:selectArr[x].indexOf(numberBall)!==-1}"
           :style="{fontSize:numberBall.length>1&&!ballClass?28+'px':''}">{{numberBall}}</a>
      </div>
      <div class="ball-control" v-if="isShowBallTools">
        <a @click="handleSelect(x,'all')" title="全选所有号码" class="ripple red_ripple"
           :class="{active:'all'===selectMap[x]}">全</a>
        <a @click="handleSelect(x,'big')" title="选取所有大号" class="ripple red_ripple"
           :class="{active:'big'===selectMap[x]}">大</a>
        <a @click="handleSelect(x,'small')" title="选取所有小号" class="ripple red_ripple"
           :class="{active:'small'===selectMap[x]}">小</a>
        <a @click="handleSelect(x,'odd')" title="选取所有奇数" class="ripple red_ripple"
           :class="{active:'odd'===selectMap[x]}">奇</a>
        <a @click="handleSelect(x,'even')" title="选取所有偶数" class="ripple red_ripple"
           :class="{active:'even'===selectMap[x]}">偶</a>
        <a @click="handleSelect(x,'')" title="清除所选" class="ripple red_ripple">清</a>
      </div>
      <div v-if='coldHotShow' class="hot-cool">
        <div class="hot-label"><span>冷热</span></div>
        <div class="hot-num">
          <span v-for='no in item.hotCold'>{{no.text}}</span>
        </div>
      </div>
      <div v-if='missingShow' class="hot-cool">
        <div class="hot-label"><span>遗漏</span></div>
        <div class="hot-num">
          <span v-for='no in item.missing'>{{no.text}}</span>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
  import {MathArray} from '../../../../../utils/index'
  function noop() {}
  export default {
    name: 'NumberSelect',
    components: {},
    props: {
      playId: {
        type: [String, Number]
      },
      playDetailCode: {
        type: String,
        default: ''
      },
      coldHotShow: {
        type: Boolean,
        default: false
      },
      missingShow: {
        type: Boolean,
        default: false
      },
      playDetailId: {
        type: [String, Number]
      },
      selectArr: {
        type: Array,
        default: function () {
          return [[], [], [], [], [], [], [], [], [], []];
        }
      },
      dataList: {
        type: Array,
        default: function () {
          return [];
        }
      },
      selectNumber: {
        type: Function,
        default: noop
      },
      onSelect: {
        type: Function,
        default: noop
      }
    },
    data(){
      return {
        activeType: '',
        ballClass: '',
        selectMap: {},
        isShowBallTools: true
      }
    },
    watch: {
      'playDetailCode': {
        immediate: true,
        handler() {
          this.cleanSelectedAll();
          this.$nextTick(function () {
            this.ballClass = this.getBallClass();
            this.isShowBallTools = this.isRenderBallTools();
          });
        }
      }
    },
    methods: {
      getBallClass: function () {
        if ([915, 916, 1035, 1036].indexOf(this.playId) !== -1) {
          return 'ballLine taste';
        }
        return '';
      },
      isRenderBallTools: function () {
        if ([915, 916, 1035, 1036].indexOf(this.playId) !== -1) {
          return false;
        }
        return true;
      },
      cleanSelectedAll: function () {
        this.selectMap = {};
      },
      handleSelect: function (x, mode) {
        const _this = this;
        if (!_this.selectMap[x]) {
          let obj = {};
          obj[x] = mode;
          _this.selectMap = Object.assign({}, _this.selectMap, obj);
        } else {
          _this.selectMap[x] = mode;
        }
        this.onSelect(x, mode);
      },
      selectNum: function (x, number) {
        this.selectNumber(x, number);
      },
    }
  }
</script>
