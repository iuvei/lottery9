<template>
  <div class="bet-single cf">
    <div class="upload_div" v-if="fileUpload">
      <h3>上传规则:</h3>
      <ol>
        <li>必须是txt文件</li>
        <li>每组投注号码之间以空格或逗号隔开</li>
        <li>文件大小不超过1M</li>
      </ol>
      <a class="btn_file" @click="selectFileBtn()">选择文件</a>
      <input type="file" @change="handleChange($event)" name="file" ref="input" class="upload__input" accept="text/plain">
    </div>
    <div class="input-frame">
      <textarea v-model="singleNum" @input="textLengthJY($event)" placeholder="输入号码" class="single_text"></textarea>
    </div>
    <div class="button-frame">
      <a class="btn btn-primary ripple" id="game-d-repeat" @click="deleteRepeat()">删除重复号</a>
      <a class="btn btn-primary ripple" @click="fileUpload=true">导入文件</a>
      <a class="btn btn-primary ripple" id="game-clear" @click="handleClean()">清空</a>
    </div>
  </div>
</template>
<script>
  import {StringToArray} from '../../../../../utils'
  function noop() {
  }
  export default {
    name: 'UploadContent',
    components: {},
    props: {
      isAlterNum: {
        type: Boolean
      },
      minCustomChoice: {
        type: Number
      },
      customChoice: {
        type: Number
      },
      setNumber: {
        type: Function,
        default: noop
      },
      onRepeat: {
        type: Function,
        default: noop
      },
      onClean: {
        type: Function,
        default: noop
      }
    },
    data(){
      return {
        fileUpload: false,
        singleNum: '',
        selectArr: [[], [], [], [], [], [], [], [], [], []]
      }
    },
    methods: {
      deleteRepeat: function () {
        this.onRepeat();
      },
      cleanBalls: function () {
        this.singleNum = '';
      },
      setRadomBalls: function (val) {
        this.singleNum = val;
      },
      selectFileBtn: function () {
        this.$refs.input.value = null;
        this.$refs.input.click();
      },
      handleChange: function (event) {
        let _this = this, temFile = event.srcElement.files[0], reader = new FileReader();
        if (temFile) {
          reader.readAsText(temFile);
          _this.singleNum = '';
        }
        reader.onload = function (e) {
          _this.singleNum = e.target.result;
          _this.textLengthJY();
        }
      },
      textLengthJY: function (event) {
        let _this = this, value = _this.singleNum.replace(/\D+/g, ""),
          numlen = _this.isAlterNum ? _this.customChoice : _this.minCustomChoice, array = [];
        if (value.length % numlen === 0) {
          array = StringToArray(value, numlen);
          _this.selectArr[0] = array;
          _this.setNumber(_this.selectArr);
          if (event && event.keyCode !== 8 && array.length > 0) {
            _this.singleNum = array.join(",") + ",";
          } else {
            _this.singleNum = array.join(",");
          }
        } else if (event && event.keyCode === 8) {
          _this.selectArr[0] = StringToArray(value, numlen);
          _this.setNumber(_this.selectArr);
        }
      },
      handleClean: function () {
        this.onClean();
      }
    }
  }
</script>
<style>
  .upload__input {
    display: none;
  }
</style>
