<template>
  <div class="chase" @click.stop="handleOnClose()">
    <div class="chase_box" @click.stop>
      <h2 class="chase_title">追号设置<span class="chase_close icon-del" @click.stop="handleOnClose()"></span></h2>
      <div class="chase_con">
        <ul class="chase_tab cf">
          <li class="ripple" :class="{active:chaseMode==0}" @click="chaseSet(0)">利润率追号</li>
          <li class="ripple" :class="{active:chaseMode==1}" @click="chaseSet(1)">同倍追号</li>
          <li class="ripple" :class="{active:chaseMode==2}" @click="chaseSet(2)">翻倍追号</li>
        </ul>
        <div class="chase_option">
          <span>追号期数：
            <span>
              <input type="radio" name="chaseNum" id="chaseNum1" value="5" v-model="chaseIssNum">
              <label :class="{active:chaseIssNum==5}" for="chaseNum1">5期</label>
              <input type="radio" name="chaseNum" id="chaseNum2" value="10" v-model="chaseIssNum">
              <label :class="{active:chaseIssNum==10}" for="chaseNum2">10期</label>
              <input type="radio" name="chaseNum" id="chaseNum3" value="15" v-model="chaseIssNum">
              <label :class="{active:chaseIssNum==15}" for="chaseNum3">15期</label>
              <input type="radio" name="chaseNum" id="chaseNum4" value="20" v-model="chaseIssNum">
              <label :class="{active:chaseIssNum==20}" for="chaseNum4">20期</label>
              <input type="radio" name="chaseNum" id="chaseNum5" value="25" v-model="chaseIssNum">
              <label :class="{active:chaseIssNum==25}" for="chaseNum5">25期</label>
            </span>
          </span>
          <span>
            <input type="text" v-model="chaseIssNum">期
          </span>
          <span v-if="chaseMode<2">
            起始倍数：<input type="text" v-model="chaseStartTimes">
          </span>
          <span v-if="chaseMode==0">
            最低收益率：<input type="text" v-model="chaseGain">%
          </span>
          <span v-if="chaseMode==2">
            隔<input type="text" v-model="chaseInterval">期
          </span>
          <span v-if="chaseMode==2">
            倍×<input type="text" v-model="chaseTimes">
          </span>
          <a class="bluet ripple" @click="createChase()">生成追号计划</a>
        </div>
        <div class="chase_table">
          <table>
            <thead>
            <tr>
              <td>序号</td>
              <td><input type="checkbox" @change="chaseSelectAll()" v-model="chaseAll">追号期次</td>
              <td>倍数</td>
              <td>金额</td>
              <td>开奖时间</td>
            </tr>
            </thead>
            <tbody>
            <tr v-for="(item,index) in futureIssue">
              <td>{{index < 9 ? "0" + (index + 1) : index + 1}}</td>
              <td>
                <label>
                  <input type="checkbox" @change="selectIssue(index)" v-model="item.select">{{item.issue}}
                </label>
                <span class="label label-danger label-sm" v-if="item.issue == currentIssue">当前期</span>
              </td>
              <td>
                <input v-if="item.select" type="text" v-model="item.num" @change="chaseTime(index)"
                       :disabled="!item.select">倍
              </td>
              <td>
                <span v-amount="item.money"></span>
              </td>
              <td>
                {{item.scheduledLotteryTime}}
              </td>
            </tr>
            </tbody>
          </table>
        </div>
        <div class="chase_foot">
          共追号
          <span class="red">{{chaseAmount}}</span>
          期，金额<span class="red" v-amount="chaseMoney"></span>元
          <el-checkbox v-model="chaseStop">中奖后停止追号</el-checkbox>
          <div>
            <a class="btn btn-red-ling ripple">清除追号</a>
            <a class="btn btn-red">追号投注</a>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
  function noop() {

  }
  export default {
    name: 'chaseSettingDialog',
    components: {},
    props: {
      futureIssue: {
        type: Array,
        default: function () {
          return [];
        }
      },
      onClose: {
        type: Function,
        default: noop
      }
    },
    data(){
      return {
        chaseMode: 0,
        chaseIssNum: 5,
        chaseStartTimes: 1,
        chaseGain: 50,
        chaseInterval: 1,
        chaseTimes: 2,
        chaseAll: false,
        currentIssue: '',
        chaseAmount: 0,
        chaseMoney: 0,
        chaseStop: true
      }
    },
    methods: {
      chaseSet: function (index) {
        this.chaseMode = index;
      },
      createChase: function () {

      },
      chaseSelectAll: function () {

      },
      selectIssue: function (index) {

      },
      handleOnClose: function () {
        this.onClose();
      }
    }
  }
</script>
