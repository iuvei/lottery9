<template>
  <div class="total-btn">
    <a class="btn btn-primary ripple" @click="handleRandom()"><i class="icon-j1"></i> 机选一注</a>
    <a class="btn btn-primary ripple" @click="handleRandom5()"><i class="icon-j5"></i> 机选五注</a>
    <a class="btn btn-warning ripple" :class="{btn_disabled:!isChaseNumber}" @click.stop="handleChaseNumber()"><i
      class="icon-set"></i> 智能追号</a>
    <!--<a class="btn btn-danger btn-lg ripple">追号投注</a>-->
    <a class="btn btn-danger btn-lg ripple" :class="{btn_disabled:!isChaseNumber}">确认投注</a>
  </div>
</template>
<script>
  function noop() {

  }
  export default {
    name: 'TotalBtns',
    components: {},
    props: {
      isRandom: {
        type: Boolean,
        default: false
      },
      isRandom5: {
        type: Boolean,
        default: false
      },
      isChaseNumber: {
        type: Boolean,
        default: false
      },
      onRandom: {
        type: Function,
        default: noop
      },
      chaseNumber: {
        type: Function,
        default: noop
      }
    },
    data(){
      return {}
    },
    methods: {
      handleChaseNumber: function () {
        if (this.isChaseNumber) {
          this.chaseNumber();
        }
      },
      handleRandom: function () {
        this.onRandom(1,true);
      },
      handleRandom5:function () {
        this.onRandom(5,true);
      }
    }
  }
</script>
