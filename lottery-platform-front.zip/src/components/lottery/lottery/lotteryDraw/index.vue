<template>
  <div class="game-bar-title cf">
    <div class="game-logo">
      <img :src="gameLogoSrc">
    </div>
    <div class="game_info">
      <p>售：<span>{{lotteryOpeningTime}}</span></p>
      <p>频率：<span>{{lotteryDrawPeriod / 60}}</span>分钟</p>
      <p>每天共：<span>{{lotteryTotalIssue}}</span>期</p>
    </div>
    <div class="countdown-time">
      <div class="cur_issue" :class="{small:gameTime.length>5}">
        <p>第 <span>{{nextLotteryIssue}}</span> 期</p>
        <h4>离投注截止还有</h4>
      </div>
      <ul v-if="gameTime.length>5" class="timing timing_h">
        <li id="timeHour0"><span class="time_in">0</span></li>
        <li id="timeHour1"><span class="time_in">0</span></li>
        <li class="time_point">:</li>
        <li id="timeMinute0"><span class="time_in">0</span></li>
        <li id="timeMinute1"><span class="time_in">0</span></li>
        <li class="time_point">:</li>
        <li id="timeSecond0"><span class="time_in">0</span></li>
        <li id="timeSecond1"><span class="time_in">0</span></li>
      </ul>

      <ul v-else class="timing timing_m">
        <li id="timeMinute0"><span class="time_in">0</span></li>
        <li id="timeMinute1"><span class="time_in">0</span></li>
        <li class="time_point">:</li>
        <li id="timeSecond0"><span class="time_in">0</span></li>
        <li id="timeSecond1"><span class="time_in">0</span></li>
      </ul>
    </div>
    <div class="game-kj">
      <div class="game-date-next">
        <p>第 <span>{{lotteryIssue}}</span> 期</p>
        <h4 class="kj-number-btn" id="dLabel">
          <a id="lotteryNumLink" target="_blank">开奖号码 <i class="icon-double-down"></i></a>
          <div class="hostory" :class="[anClass]">
            <ul class="hostory-header">
              <li>
                <div>期号</div>
                <div>开奖号码</div>
              </li>
            </ul>
            <ul class="hostory-body">
              <li v-for="item in hostIssue.list">
                <div>{{item.issue}}</div>
                <div v-if="item.lotteryNumber.length>0">
                  <span v-for="list in item.lotteryNumber">{{list}}</span>
                </div>
                <div v-else>开奖中……</div>
              </li>
            </ul>
          </div>
        </h4>
      </div>
      <div class="kj-ing" :class="[anClass]" v-if="lotteryIsDrawing">开奖中...</div>
      <ul v-else class="kj-number-new" :class="[anClass]">
        <li v-for="item in lotteryDrawBalls">
          <div><span>{{item}}</span></div>
        </li>
      </ul>
      <div class="kj_3" :class="[anClass]">
        <a class="help_show" href="javascript:;"><i class="icon-help"></i> <i>玩法说明</i>
          <div class="triangle-isosceles">
            <p class="how-to-play">玩法：<span id="game-demo-help">{{playHelp}}</span></p>
            <p class="example">演示：<span id="game-demo-examle">{{playExample}}</span></p>
          </div>
        </a>
        <span v-if="groupId==4"></span>
        <a v-else id="trendLink" target="_blank"><i class="icon-hmzs" title="号码走势"></i> <i>号码走势</i></a>
      </div>
    </div>
  </div>
</template>
<script>
  import {getGameOneResult} from '../../../../api/lottery'
  //import {getLotteryDraw} from '../../../../api/lottery'
  export default {
    name: 'LotteryDraw',
    components: {},
    data(){
      const lotteryDrawBallAnimateMap = {
        'ssc': ["1", "2", "3", "4", "5", "6", "7", "8", "9", "0"],
        'ffc': ["1", "2", "3", "4", "5", "6", "7", "8", "9", "0"],
        '11x5': ["01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "00"],
        '3d/p3': ["1", "2", "3", "4", "5", "6", "7", "8", "9", "0"],
        'klc': ["01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31", "32", "33", "34", "35", "36", "37", "38", "39", "40", "41", "42", "43", "44", "45", "46", "47", "48", "49", "50", "51", "52", "53", "54", "55", "56", "57", "58", "59", "60", "61", "62", "63", "64", "65", "66", "67", "68", "69", "70", "71", "72", "73", "74", "75", "76", "77", "78", "79", "80", "00"],
        'pk10': ["01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "00"],
        'k3': ["1", "2", "3", "4", "5", "6", "0"]
      };
      const lotteryAnimateClassMap = {
        'ssc': '',
        'ffc': '',
        '11x5': 'eleven',
        '3d/p3': '',
        'klc': 'happy',
        'pk10': 'pk',
        'k3': ''
      };
      return {
        lotteryDrawBallAnimateMap,
        lotteryAnimateClassMap,
        gameLogoSrc: '',
        anClass: "",//开奖动画class
        hostIssue: {
          name: "",
          list: []
        },//历史期号
        playHelp: '从万位、千位、百位、十位、个位中选择一个5位数号码组成一注，所选号码与开奖号码全部相同，且顺序一致，即为中奖。',//玩法说明
        playExample: "",//玩法演示
        groupId: '',
        drawTimerIntervalId: -1,
        timerIntervalId: '',
        lotteryId: '',
        lotteryType: '',
        lotteryIssue: '000000',
        lotteryTotalIssue: '0',
        lotteryOpeningTime: '',
        lotteryDrawPeriod: 300,
        lotteryIsDrawing: false,
        lotteryDrawBalls: [],
        lotteryDrawBallAnimate: [],
        nextLotteryIssue: '000000',
        nextLotteryDrawTime: 0,
        gameTime: '00:00',
        setAnTimerMap: {},//设置动画延迟时间对象
      }
    },
    methods: {
      timerClean: function () {
        const _this = this;
        Object.keys(_this.setAnTimerMap).forEach(key => {
          clearTimeout(_this.setAnTimerMap[key]);
        });
        clearInterval(_this.timerIntervalId);
        clearInterval(_this.drawTimerIntervalId);
      },
      setTimerOptions: function (options) {
        const _this = this, {lotteryGameId, gameCode, gameResult, nextGameResultNum, nextLotteryTime, dateTime, gameResultNum, openTime, openResultNum} = options,
          nextTime = Number(nextLotteryTime);
        _this.lotteryId = lotteryGameId;
        _this.lotteryType = gameCode;
        _this.lotteryIssue = gameResultNum;
        _this.lotteryTotalIssue = openResultNum || '加载中...';
        _this.lotteryOpeningTime = openTime || '加载中...';
        _this.lotteryDrawPeriod = dateTime;
        _this.lotteryDrawBalls = gameResult ? gameResult.split(',') : [];
        _this.nextLotteryIssue = nextGameResultNum;
        if (nextTime > 1) {
          _this.lotteryIsDrawing = false;
          _this.nextLotteryDrawTime = nextTime;
        } else {
          _this.lotteryIsDrawing = true;
          _this.getLotteryDrawInfoByTimer({lotteryGameId: lotteryGameId});
          _this.nextLotteryDrawTime = dateTime;
        }
        _this.anClass = _this.lotteryAnimateClassMap[gameCode] || '';
        _this.lotteryDrawBallAnimate = _this.lotteryDrawBallAnimateMap[gameCode] || [];
        if (!_this.lotteryIsDrawing) {
          _this.timerClean();
          _this.drawBallsAnimate(_this.lotteryDrawBalls);
        }
      },
      drawBallsAnimate: function (lotteryBallsArr) {
        const _this = this;
        lotteryBallsArr.forEach((item, index) => {
          lotteryBallsArr[index] = item.length === 1 ? '0' : '00';
          _this.setAnTimerMap[index] = setTimeout(function () {
            _this.startAnimate($(".kj-number-new li:eq(" + index + ") div:eq(0)"), item, _this.lotteryDrawBallAnimate, 4000, "swing");
          }, index * 400);
        });
      },
      getLotteryDrawInfoByTimer: function (param) {
        const _this = this;
        if (_this.drawTimerIntervalId !== -1) {
          clearInterval(_this.drawTimerIntervalId);
        }
        _this.drawTimerIntervalId = setInterval(function () {
          _this.requestLotteryDrawInfo(param);
        }, 2000);
      },
      requestLotteryDrawInfo: function (param) {
        getGameOneResult(param).then(res => {
          if (res.currentStatus === 0 && res.currentData.gameResultNum >= this.lotteryIssue){
            clearInterval(this.drawTimerIntervalId);
            const {gameResultNum, gameResult, nextGameResultNum, nextLotteryTime} = res.currentData;
            this.lotteryIsDrawing = false;
            this.nextLotteryDrawTime = Number(nextLotteryTime);
            this.lotteryIssue = gameResultNum;
            this.nextLotteryIssue = nextGameResultNum;
            this.drawBallsAnimate(gameResult.split(','));
          }
        }).catch(err => {
          console.log('requestLotteryDrawInfo error:%s', err);
        });
      },
      startAnimate: function (target, num, arr, sp, ease, call) {
        let str = "", h = target.outerHeight(), t = h * arr.length * 5 - h, po = arr.indexOf(num), p = h * po;
        for (let a = 0; a < 5; a++) {
          arr.forEach(item => {
            str += `<span>${item}</span>`;
          });
        }
        target.html(str).stop().css("top", -t + "px").animate({top: -p + "px"}, sp, ease, function () {
          $(this).empty().html(`<span>${num}</span>`).css("top", "0px");
          if (call) call();
        });
      },
      changeLotteryDrawInfo: function () {
        const _this = this;
        _this.getLotteryDrawInfoByTimer({lotteryGameId: _this.lotteryId});
        _this.lotteryIssue = Number(_this.nextLotteryIssue);
        _this.nextLotteryIssue++;
      },
      timerStart: function () {
        const _this = this;
        let hour, minute, second;
        _this.timerIntervalId = setInterval(function () {
          updateTimer();
          formatterTime();
        }, 1000);

        function updateTimer() {
          if (_this.nextLotteryDrawTime <= 0) {
            _this.nextLotteryDrawTime = _this.lotteryDrawPeriod;
            _this.changeLotteryDrawInfo();
            _this.lotteryIsDrawing = true;
          } else {
            _this.nextLotteryDrawTime--;
          }
        }

        function formatterTime() {
          hour = parseInt(parseInt(_this.nextLotteryDrawTime / 60) / 60);
          minute = parseInt(_this.nextLotteryDrawTime / 60) % 60;
          second = parseInt(_this.nextLotteryDrawTime) % 60;
          if (hour < 10) {
            hour = "0" + hour;
          }
          if (minute < 10) {
            minute = "0" + minute;
          }
          if (second < 10) {
            second = "0" + second;
          }
          if (hour * 1 > 0) {
            _this.gameTime = hour + ":" + minute + ":" + second;
          } else {
            _this.gameTime = minute + ":" + second;
          }
          if ($("#timeSecond1").length > 0) move($("#timeSecond1"), ("" + second).charAt(1));
          if ($("#timeSecond0").length > 0) move($("#timeSecond0"), ("" + second).charAt(0));
          if ($("#timeMinute1").length > 0) move($("#timeMinute1"), ("" + minute).charAt(1));
          if ($("#timeMinute0").length > 0) move($("#timeMinute0"), ("" + minute).charAt(0));
          if ($("#timeHour1").length > 0) move($("#timeHour1"), ("" + hour).charAt(1));
          if ($("#timeHour0").length > 0) move($("#timeHour0"), ("" + hour).charAt(0));
        }

        function move(obj, time) {
          let inObj = obj.find(".time_in");
          let span = $("<span></span>");
          let h = inObj.outerHeight();
          if (inObj.text() != time) {
            span.text(time).css("top", -h + "px");
            inObj.css("top", "0px").siblings().remove();
            inObj.before(span);
            inObj.stop().animate({top: h + "px"}, 300, function () {
              $(this).text(time).css("top", "0px");
              $(this).siblings().remove();
            }).prev().stop().animate({top: "0px"}, 300);
          } else {
            inObj.text(time);
          }
        }
      }
    }
  }
</script>
