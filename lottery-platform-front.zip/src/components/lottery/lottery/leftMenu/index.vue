<template>
  <div class="left-menu">
    <ul>
      <li v-for="item in groupList" :class="{active:groupId==item.id}">
        <a class="ripple">{{item.menuName}}</a>
        <div class="left-menu-dropdown">
          <span class="caret-left"></span>
          <div class="cz-title">{{item.menuName}}</div>
          <div class="lottery_nav cz-list cf">
            <router-link class="ripple red_ripple" v-for="detail in item.childrenList" :key="detail.id"
                         :class="{cur:lotteryId==detail.id}"
                         :to='{name:"lotteryLayout",params:{gameId:detail.id,groupId:item.id,gameName:detail.menuName}}'>{{detail.menuName}}
            </router-link>
          </div>
        </div>
      </li>
    </ul>
  </div>
</template>
<script>
  export default {
    name: 'LeftMenu',
    components: {},
    props: {
      lotteryId: {
        type: [String, Number]
      },
      groupId: {
        type: [String, Number]
      },
      groupList: {
        type: Array,
        default: function () {
          return [];
        }
      }
    },
    data(){
      return {}
    },
    methods: {}
  }
</script>
