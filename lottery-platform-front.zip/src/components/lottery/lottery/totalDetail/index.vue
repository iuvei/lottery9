<template>
  <div class="total">
    <div class="money-units pull-left">
      <a v-for="(item,index) in scaleList" :data-val="item.value" class="ripple red_ripple"
         :class="{active:item==activeCaiScale}" @click="handleSelectScale(item)">{{item}}</a>
    </div>
    <div class="input-group spinner pull-left cf">
      <div class="input-group-addon ripple red_ripple" @click=cutMultiple>-</div>
      <input type="text" class="form-control" v-model="caiMultiple" maxlength="5">
      <div class="input-group-addon ripple red_ripple" @click=addMultiple>+</div>
    </div>
    <div class="total-word pull-left">倍</div>
    <div class="total-word pull-left margin1em-left">
      奖金/返点：<span class="user_rebate">{{userRebate}}</span>
    </div>
    <div class="fandian pull-left">
      <el-select v-model="userRebate" class="form-control selectpicker bs-select-hidden">
        <el-option v-for="option in rebateList" :key="option.value" :label="option.text"
                   :value="option.value"></el-option>
      </el-select>
    </div>
    <div class="total-word pull-left margin1em-left">
      已选 <span class="text-red">{{betCount}}</span> 注
    </div>
    <div class="total-word pull-left margin1em-left">
      共 <span class="text-red">￥<i v-amount="betAmount"></i></span>
    </div>
    <div class="pull-right">
      <a class="btn btn-red ripple" :class="{btn_disabled:!betCount>0}" @click="handleOnBet()">直接投注</a>
    </div>
    <div class="pull-right">
      <a class="btn btn-red-ling ripple" :class="{btn_disabled:!betCount>0}" @click="handleAddBetContainer()">加入投注篮</a>
    </div>
  </div>
</template>
<script>
  function noop() {
  }
  export default {
    name: 'TotalDetail',
    components: {},
    props: {
      scaleList: {
        type: Array,
        default: function () {
          return [];
        }
      },
      betCount: {
        type: [String, Number],
        default: 0
      },
      betAmount: {
        type: [String, Number],
        default: 0
      },
      selectScale: {
        type: Function,
        default: noop
      },
      onChange: {
        type: Function,
        default: noop
      },
      addContainer: {
        type: Function,
        default: noop
      },
      rebateList: {
        type: Array,
        default: function () {
          return [];
        }
      }
    },
    data(){
      return {
        activeCaiScale: '',
        caiMultiple: 1,
        userRebate: '',
        betMoney: 0
      }
    },
    computed: {},
    methods: {
      cutMultiple: function () {
        if (this.caiMultiple > 1) {
          this.caiMultiple--
        }
        this.onChange(this.caiMultiple);
      },
      addMultiple: function () {
        if (this.caiMultiple < 99999) {
          this.caiMultiple++
        }
        this.onChange(this.caiMultiple);
      },
      handleSelectScale: function (val) {
        this.activeCaiScale = val;
        this.selectScale(val);
      },
      handleOnBet: function () {

      },
      handleAddBetContainer: function () {
        if (this.betCount > 0) {
          this.addContainer();
        }
      }
    }
  }
</script>
