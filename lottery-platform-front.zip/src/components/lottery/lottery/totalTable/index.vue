<template>
  <form>
    <div class="total-table-header">
      <span class="td1">玩法</span>
      <span class="td2">号码</span>
      <span class="td3">单位</span>
      <span class="td4">倍数</span>
      <span class="td5">注数</span>
      <span class="td6">金额</span>
      <span class="td7"><i class="icon-ljt" @click="delAll()"></i></span>
    </div>
    <div class="total-table-main">
      <div v-for="(item,index) in dataList" class="total-list-row">
        <div class="total-table-col td1">
          {{item.gameName}}
        </div>
        <div class="total-table-col td2">
          <span class="num">{{item.num}}</span>
          <span v-if="item.singled==true" class="label label-danger label-sm">单挑</span>
          <input type='hidden' v-model="item.num" name="content">
        </div>
        <div class="total-table-col td3">
          <select v-model="item.scale" name="moneyUnitCode" class="select-box">
            <option v-for="option in item.scaleList" :value="option">{{option}}</option>
          </select>
        </div>
        <div class="total-table-col td4">
          <input v-model="item.multiple" name="bmultipe" class="form-control input-sm" type="text"> 倍
        </div>
        <div class="total-table-col td5">
          {{item.betCount}} 注
        </div>
        <div class="total-table-col td6">
          ￥<i v-amount="item.betAmount"></i>
        </div>
        <div class="total-table-col td7"><i @click="delBet(index)" class="icon-del"></i></div>
      </div>
    </div>
    <div class="total-table-footer">
      <div class="total-word pull-left">
        已选 <span class="text-red">{{betTotalCount}}</span> 注
      </div>
      <div class="total-word pull-left margin1em-left">
        共 <span class="text-red">￥<i v-amount="betTotalAmount"></i></span>
      </div>
      <div class="total-word pull-right">
        <el-checkbox v-model="fastChase">快速追号</el-checkbox>
        <span v-if="fastChase">
          <input type="text" v-model='fastChaseNum' class="txt">期
          <el-checkbox v-model="chaseStop">中奖后停止追号</el-checkbox>
        </span>
      </div>
    </div>
  </form>
</template>
<script>
  function noop() {

  }
  export default {
    name: 'TotalTable',
    components: {},
    props: {
      onDelete: {
        type: Function,
        default: noop
      },
      deleteAll: {
        type: Function,
        default: noop
      },
      dataList: {
        type: Array,
        default: function () {
          return [];
        }
      },
      betTotalCount: {
        type: Number,
        default: 0
      },
      betTotalAmount: {
        type: Number,
        default: 0
      }
    },
    data(){
      return {
        fastChase: false,
        fastChaseNum: 0,
        chaseStop: false
      }
    },
    methods: {
      delAll: function () {
        if (this.dataList.length > 0) {
          this.$confirm('是否删除所有号码？点击确定后清空投注篮。', '确认删除', {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning'
          }).then(() => {
            this.deleteAll();
          }).catch(() => {

          });
        }
      },
      delBet: function (index) {
        this.onDelete(index);
      }
    }
  }
</script>
