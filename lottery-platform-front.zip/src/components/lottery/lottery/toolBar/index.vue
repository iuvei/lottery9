<template>
  <div class="tab-pane cf">
    <div class="help-block pull-left">
      <i class="icon-deng"></i>
      <small>{{playDescription}}</small>
    </div>
    <div class="pull-right word-ball">
      <a class="ripple red_ripple" @click="handleOnHotClick()" :class="{active:coldHotShow}" title="显示/隐藏冷热">热</a>
      <a class="ripple red_ripple" @click="handleOnMissedClick()" :class="{active:missingShow}" title="显示/隐藏遗漏">遗</a>
      <a class="ripple red_ripple" @click="handleOnClean()" title="清除选择号码">清</a>
      <a class="ripple red_ripple" @click="handleRandom()" title="机选号码">机</a>
      <a class="icon-shengyin ripple red_ripple" :class="{active:!notSound}" @click="handleOnChangeSound()" title="声音开关"></a>
      <a class="icon_scoket ripple red_ripple" :class="{active:scoket}" title="侧边提示开关" @click="handleOnChangeSocket()"></a>
    </div>
  </div>
</template>
<script>
  function noop() {}
  export default {
    components: {},
    props: {
      playDescription: {
        type: String,
        default: ''
      },
      onColdHotClick: {
        type: Function,
        default: noop
      },
      onMissedClick: {
        type: Function,
        default: noop
      },
      onClean: {
        type: Function,
        default: noop
      },
      onRandom: {
        type: Function,
        default: noop
      },
      onSoundChange: {
        type: Function,
        default: noop
      },
      onSocketChange: {
        type: Function,
        default: noop
      }
    },
    data(){
      return {
        coldHotShow: false,
        missingShow: false,
        notSound: true,
        scoket: true
      }
    },
    methods: {
      handleOnHotClick: function () {
        this.coldHotShow = true;
        this.missingShow = false;
        this.onColdHotClick()
      },
      handleOnMissedClick: function () {
        this.coldHotShow = false;
        this.missingShow = true;
        this.onMissedClick()
      },
      handleOnClean: function () {
        this.onClean()
      },
      handleRandom: function () {
        this.onRandom(1,false)
      },
      handleOnChangeSound: function () {
        this.notSound = !this.notSound;
        this.onSoundChange(this.notSound);
      },
      handleOnChangeSocket: function () {
        this.scoket = !this.scoket;
        this.onSocketChange(this.scoket);
      }
    }
  }
</script>
