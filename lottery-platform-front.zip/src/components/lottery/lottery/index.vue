<template>
  <div class="page-center">
    <div class="ssc">
      <div class="main-container">
        <lottery-draw ref="lotteryDraw"></lottery-draw>
        <div class="bet_content cf">
          <left-menu :lotteryId="gameId" :groupId="groupId" :groupList="lotteryGroupList"></left-menu>
          <div class="game-betCont">
            <play-nav-bar :playId="playId" :playTypeList="lotteryPlays" :on-change="onPlayChange"></play-nav-bar>
            <div class="tab-content">
              <transition name="fade" mode="out-in" appear>
                <play-detail v-if="playDetailIsShow"
                             :betTypeList="lotteryPlayDetailList"
                             :playDetailId="playDetailId"
                             :on-change="onPlayDetailChange"
                             :on-close="onPlayClose"></play-detail>
                <div class="shuaixuan2" v-else>
                  <a class="bet_type_show" @click="playDetailIsShow=true">当前游戏：{{playDetailName}}</a>
                </div>
              </transition>
              <tool-bar :playDescription="playDescription" :on-clean="cleanSelectedFun"
                        :on-random="randomFun"></tool-bar>
              <position-toolbar v-if="betPositionIsShow"
                                ref="positionToolBar"
                                :minCustomChoice="minCustomChoice"
                                :playDetailCode="playDetailCode"
                                :on-change="positionChange"></position-toolbar>
              <number-select v-if="showType" ref="ballSelect"
                             :playId="playId"
                             :playDetailCode="playDetailCode"
                             :playDetailId="playDetailId"
                             :dataList="playBetContent"
                             :selectArr="selectArr"
                             :select-number="selectNumFun"
                             :on-select="numberSelectFun"></number-select>
              <upload-content v-else
                              ref="uploadContent"
                              :isAlterNum="isAlterNum"
                              :minCustomChoice="minCustomChoice"
                              :customChoice="customChoice"
                              :set-number="setNumberFun"
                              :on-repeat="onUploadRepeatFun"
                              :on-clean="onUploadCleanFun"></upload-content>
              <total-detail :betCount="betCount"
                            :betAmount="betAmount"
                            :scaleList="scaleList"
                            :on-change="onBetMultipleChange"
                            :select-scale="onSelectScale"
                            :add-container="addBetContainerFun"></total-detail>
            </div>
            <div class="total-list-box">
              <total-table :dataList="betTableList"
                           :betTotalCount="betTotalCount"
                           :betTotalAmount="betTotalAmount"
                           :on-delete="onBetDelete"
                           :delete-all="deleteAllBet"></total-table>
              <total-btns :isChaseNumber="betTableList.length>0"
                          :chase-number="onChaseNumber"
                          :on-random="randomFun"></total-btns>
            </div>
          </div>
        </div>
      </div>
    </div>
    <transition name="fade" mode="out-in" appear>
      <chase-setting-dialog v-if="chaseSetDialogIsShow" :onClose="chaseSetDialogCloseFun"></chase-setting-dialog>
    </transition>
    <!--大老板-->
    <!--<countdown-Popup v-if="!$parent.floatTime"
                     :gameTime="gameTime"
                     :issue="currentIssue"
                     :contraction="false"></countdown-Popup>-->
    <lottery-ranking :randkingData="winning" :isShow="rankingIsShow"></lottery-ranking>
    <right-toolbar-tabs :hasBetData="false"
                        :betRecordsByList="betRecordsByList"
                        :betRecordsNotList="betRecordsNotList"></right-toolbar-tabs>
  </div>
</template>
<script>
  import countDownPopup from './../kg/countDownPopup/index'
  import lotteryRanking from './../kg/leftLotteryRanking/index'
  import rightToolbarTabs from './../kg/rigthToolBarTabs/index'
  import lotteryDraw from './lotteryDraw/index'
  import leftMenu from './leftMenu/index'
  import playNavBar from './playNavBar/index'
  import playDetail from './playDetail/index'
  import toolBar from './toolBar/index'
  import numberSelect from './betContent/numberSelect/index'
  import uploadContent from './betContent/uploadContent/index'
  import totalTable from './totalTable/index'
  import totalBtns from './totalBtns/index'
  import totalDetail from './totalDetail/index'
  import chaseSettingDialog from './chaseSettingDialog/index'
  import positionToolbar from './positionToolbar/index'
  import {getLotteryPlays, getMasterList} from '../../../api/lotteryKg'
  import {getGameOneResult} from '../../../api/lottery'
  import {
    uniquePK10,
    unique11X5ZuXuan,
    unique11X5ZhiXuan,
    uniqueCnm6,
    uniqueCnm,
    unique,
    Combination,
    Cnm,
    MathArray,
    save
  } from '../../../utils'
  export default {
    components: {
      countDownPopup,
      lotteryRanking,
      rightToolbarTabs,
      lotteryDraw,
      leftMenu,
      playNavBar,
      playDetail,
      toolBar,
      numberSelect,
      uploadContent,
      totalTable,
      totalBtns,
      chaseSettingDialog,
      totalDetail,
      positionToolbar
    },
    data(){
      const positionToolShowDic = ['ssc_rx2_zxds', 'ssc_rx2_zxhz', 'ssc_rx2_zuxfs', 'ssc_rx2_zuxds', 'ssc_rx2_zxhz', 'ssc_rx3_zxds', 'ssc_rx3_zxhz', 'ssc_rx3_zlfs', 'ssc_rx3_zlds', 'ssc_rx3_zsfs', 'ssc_rx3_zsds', 'ssc_rx3_hhzx', 'ssc_rx4_zxds', 'ssc_rx4_zx24', 'ssc_rx4_zx12', 'ssc_rx4_zx6', 'ssc_rx4_zx4', 'ffc_rx2_zxds', 'ffc_rx2_zxhz', 'ffc_rx2_zuxfs', 'ffc_rx2_zuxds', 'ffc_rx2_zxhz', 'ffc_rx3_zxds', 'ffc_rx3_zxhz', 'ffc_rx3_zlfs', 'ffc_rx3_zlds', 'ffc_rx3_zsfs', 'ffc_rx3_zsds', 'ffc_rx3_hhzx', 'ffc_rx4_zxds', 'ffc_rx4_zx24', 'ffc_rx4_zx12', 'ffc_rx4_zx6', 'ffc_rx4_zx4'];
      return {
        positionToolShowDic,
        typeId: '',
        gameId: '',
        groupId: '',
        playId: '',
        playDetailId: '',
        playDetailGroupName: '',
        playDetailName: '',
        playDetailCode: '',
        playDetailList: [],
        playBetContent: [],
        playBetContentType: '',
        gameName: '',
        gameTime: '',
        lotteryGroupList: [],
        lotteryPlays: [],
        lotteryPlayDetailList: [],
        scaleList: [],
        currentIssue: '',
        winning: [],
        rankingIsShow: false,
        betRecordsByList: [],
        betRecordsNotList: [],
        hasBetData: false,
        playDetailIsShow: true,
        playDescription: '',
        showType: true,
        chaseSetDialogIsShow: false,
        errorArray: [],
        betCount: 0,
        betAmount: 0,
        betTableList: [],
        caiMultiple: 1,
        scale: '',
        betTotalAmount: 0,
        lotteryIssue: '',
        lotteryDrawPeriod: 0,
        lotteryIsDrawing: false,
        lotteryDrawBalls: [],
        nextLotteryIssue: '',
        nextLotteryDrawTime: '',
        betPositionIsShow: false,
        maxCustomChoice: 0,
        minCustomChoice: 0,
        customChoice: 0,
        isAlterNum: true,
        customBit: [],
        selectArr: [[], [], [], [], [], [], [], [], [], []],
      }
    },
    beforeRouteEnter(to, from, next){
      if (!from.path)  return false;
      next(vm => {
        const obj = {
          typeId: to.params.typeId,
          groupId: to.params.groupId,
          gameId: to.params.gameId,
          gameName: to.params.gameName
        };
        vm.init(obj);
      });
    },
    beforeRouteLeave(to, from, next) {
      const target = this.$refs['lotteryDraw'];
      if (target) {
        target.timerClean();
      }
      next(true);
    },
    computed: {
      betTotalCount: function () {
        let totalCount = 0;
        this.betTableList.forEach(item => {
          totalCount += item.betCount;
        });
        this.betTotalAmount = totalCount * 2;
        return totalCount;
      }
    },
    methods: {
      setNumberFun: function (arr) {
        this.selectArr = arr;
        this.computedBetCount();
      },
      positionChange: function (plan) {
        this.positionPlan = plan;
        this.computedBetCount();
      },
      deleteAllBet: function () {
        this.betTableList = [];
      },
      onBetDelete: function (index) {
        this.betTableList.splice(index, 1);
      },
      onSelectScale: function (val) {
        this.scale = val;
      },
      onBetMultipleChange: function (val) {
        this.caiMultiple = val;
      },
      onPlayChange: function (val) {
        this.playId = val;
        this.resetSelectBalls();
        this.resetBetCount();
        this.requestLotteryBetDetail();
      },
      onPlayDetailChange: function (val, x, y) {
        this.resetSelectBalls();
        this.resetBetCount();
        this.playDetailId = val;
        const info = this.lotteryPlayDetailList[x].list[y];
        this.playDescription = info.remark;
        this.playDetailCode = info.masterCode;
        this.playDetailGroupName = this.lotteryPlayDetailList[x].name;
        this.playDetailName = this.lotteryPlayDetailList[x].list[y].ruleMasterName;
        console.log('code:%s,icon:%s', info.masterCode, info.icon);
        this.betPositionIsShow = this.positionToolShowDic.indexOf(info.masterCode) !== -1;
        if (info.icon !== 'ball') {
          this.showType = false;
        } else {
          this.showType = true;
          const obj = this.lotteryPlayDetailList[x].list[y];
          this.scaleList = obj.monetaryUnit;
          this.playBetContent = obj.gameRuleDetailList;
        }
        this.simplexInit(info.masterCode);
      },
      onPlayClose: function () {
        this.playDetailIsShow = false;
      },
      onChaseNumber: function () {
        this.chaseSetDialogIsShow = true;
      },
      onUploadRepeatFun: function () {
        this.selectArr[0] = Array.from(new Set(this.selectArr[0]));
        this.$refs['uploadContent'].setRadomBalls(this.selectArr[0].join(','));
      },
      onUploadCleanFun: function () {
        this.resetSelectBalls();
        this.resetBetCount();
      },
      addBetContainerFun: function () {
        const _this = this;
        let betInfo = {
          gameName: _this.playDetailGroupName + "_" + _this.playDetailName,
          num: _this.betArrToString(),
          singled: _this.betCount === 1,
          scaleList: _this.scaleList,
          scale: _this.scale,
          multiple: _this.caiMultiple,
          betCount: _this.betCount,
          betAmount: _this.betAmount
        };
        this.betTableList.unshift(betInfo);
        this.resetSelectBalls();
        this.resetBetCount();
      },
      betArrToString: function () {
        const _this = this;
        let tempStr = '';
        _this.selectArr.forEach((item, index) => {
          if (item.length > 0) {
            tempStr += item.join(',') + getSplitStr(_this.selectArr, index + 1);
          }
        });
        function getSplitStr(arr, index) {
          if (arr[index] && arr[index].length > 0) {
            return '|'
          }
          return '';
        }

        return tempStr;
      },
      selectNumFun: function (dataIndex, selectedNumber) {
        const index = this.selectArr[dataIndex].indexOf(selectedNumber);
        if (index !== -1) {
          this.selectArr[dataIndex].splice(index, 1);
        } else {
          this.selectArr[dataIndex].push(selectedNumber);
        }
        this.computedBetCount();
      },
      numberSelectFun: function (dataIndex, mode) {
        switch (mode) {
          case 'all':
            this.selectAllFun(dataIndex);
            break;
          case 'big':
            this.selectBigFun(dataIndex);
            break;
          case 'small':
            this.selectSmallFun(dataIndex);
            break;
          case 'odd':
            this.selectOddFun(dataIndex);
            break;
          case 'even':
            this.selectEvenFun(dataIndex);
            break;
          default:
            this.selectCleanFun(dataIndex);
            break;
        }
        this.computedBetCount();
      },
      computedBetCount: function () {
        this.betCount = this.countstat(this.playDetailCode);
        this.betAmount = this.betCount * 2;
      },
      cleanSelectedFun: function () {
        this.resetSelectBalls();
        this.resetBetCount();
      },
      cleanSelectedByIndex: function (index) {
        this.selectArr[index].length = 0;
      },
      selectCleanFun: function (dataIndex) {
        this.cleanSelectedByIndex(dataIndex);
      },
      selectAllFun: function (dataIndex) {
        const _this = this;
        _this.playBetContent[dataIndex].betDetail.forEach(item => {
          if (_this.selectArr[dataIndex].indexOf(item) === -1) {
            _this.selectArr[dataIndex].push(item);
          }
        });
      },
      selectBigFun: function (dataIndex) {
        const _this = this, len = _this.playBetContent[dataIndex].betDetail.length, str = len / 2;
        _this.cleanSelectedByIndex(dataIndex);
        _this.playBetContent[dataIndex].betDetail.forEach((item, index) => {
          if (index >= str && _this.selectArr[dataIndex].indexOf(item) === -1) {
            _this.selectArr[dataIndex].push(item);
          }
        });
      },
      selectSmallFun: function (dataIndex) {
        const _this = this, len = _this.playBetContent[dataIndex].betDetail.length, str = len / 2;
        _this.cleanSelectedByIndex(dataIndex);
        _this.playBetContent[dataIndex].betDetail.forEach((item, index) => {
          if (index < str && _this.selectArr[dataIndex].indexOf(item) === -1) {
            _this.selectArr[dataIndex].push(item);
          }
        });
      },
      selectOddFun: function (dataIndex) {
        const _this = this;
        _this.cleanSelectedByIndex(dataIndex);
        _this.playBetContent[dataIndex].betDetail.forEach(item => {
          if (item * 1 % 2 === 1 && _this.selectArr[dataIndex].indexOf(item) === -1) {
            _this.selectArr[dataIndex].push(item);
          }
        });
      },
      selectEvenFun: function (dataIndex) {
        const _this = this;
        _this.cleanSelectedByIndex(dataIndex);
        _this.playBetContent[dataIndex].betDetail.forEach(item => {
          if (item * 1 % 2 === 0 && _this.selectArr[dataIndex].indexOf(item) === -1) {
            _this.selectArr[dataIndex].push(item);
          }
        });
      },
      randomFun: function (count, isAdd) {
        const _this = this;
        for (let i = 0; i < count; i++) {
          _this.randomBet();
          if (!_this.showType && i === 0) {
            _this.$refs['uploadContent'].setRadomBalls(this.selectArr[0][0]);
          }
          if (isAdd) {
            _this.addBetContainerFun();
          } else {
            _this.computedBetCount();
          }
        }
      },
      resetSelectBalls: function () {
        if (this.showType) {
          this.$refs['ballSelect'].cleanSelectedAll();
        } else {
          this.$refs['uploadContent'].cleanBalls();
        }
        this.selectArr = [[], [], [], [], [], [], [], [], [], []];
      },
      resetBetCount: function () {
        this.betCount = 0;
        this.betAmount = 0;
      },
      randomBet: function () {
        this.resetSelectBalls();
        let wei0, wei1, wei2, wei3, wei4, wei5, wei6, wei7, wei8, wei9, randomArray = [], newRandomArray = [], i, j, k,
          randomArrayL, randomFor;

        function arrToStr(arr) {
          let temp = [];
          arr.forEach(item => {
            temp.push("" + item);
          });
          return temp;
        }

        switch (this.playDetailCode) {
          case 'ssc_wx_zxfs':	//五星_直选复式
          case 'ssc_wx_wxzh':	//五星_组合
          case 'ffc_wx_zxfs':
          case 'ffc_wx_wxzh':
            randomArray = MathArray(5, 0, 9);
            for (i = 0; i < 5; i++) {
              save(this.selectArr[i], "" + randomArray[i], "reverse");
            }
            break;
          case 'ssc_wx_zxds':	//五星_直选单式
          case 179:
            randomArray = MathArray(5, 0, 9);
            randomArray = randomArray.join("");
            save(this.selectArr[0], randomArray, "reverse");
            break;
          case 'ssc_wx_zx120':	//五星_组选120
          case 'ffc_wx_zx120':
            randomArray = MathArray(5, 0, 9);
            for (i = 0; i < 5; i++) {
              save(this.selectArr[0], "" + randomArray[i], "reverse");
            }
            break;
          case 'ssc_wx_zx60':	//五星_组选60
          case 'ffc_wx_zx60':
            wei0 = MathArray(1, 0, 9);
            wei1 = MathArray(3, 0, 9);
            while (wei1.indexOf(wei0 / 1) !== -1) {
              wei0 = MathArray(1, 0, 9);
            }
            wei0 = arrToStr(wei0);
            wei1 = arrToStr(wei1);
            this.selectArr.unshift(wei0, wei1);
            break;
          case 'ssc_wx_zx30':	//五星_组选30
          case 'ffc_wx_zx30':
            wei0 = MathArray(2, 0, 9);
            wei1 = MathArray(1, 0, 9);
            while (wei0.indexOf(wei1 / 1) !== -1) {
              wei1 = MathArray(1, 0, 9);
            }
            wei0 = arrToStr(wei0);
            wei1 = arrToStr(wei1);
            this.selectArr.unshift(wei0, wei1);
            break;
          case 'ssc_wx_zx20':	//五星_组选20
          case 'ffc_wx_zx20':
          case 'ssc_sx_zx12':	//四星_组选12
          case 'ffc_sx_zx12':
          case 'ssc_rx4_zx12':	//任四_组选12
          case 'ffc_rx4_zx12':
            wei0 = MathArray(1, 0, 9);
            wei1 = MathArray(2, 0, 9);
            while (wei1.indexOf(wei0 / 1) !== -1) {
              wei0 = MathArray(1, 0, 9);
            }
            wei0 = arrToStr(wei0);
            wei1 = arrToStr(wei1);
            this.selectArr.unshift(wei0, wei1);
            break;
          case 'ssc_wx_zx10':		//五星_组选10
          case 'ffc_wx_zx10':
          case 'ssc_wx_zx5':		//五星_组选5
          case 'ffc_wx_zx5':
          case 'ssc_sx_zx4':	//四星_组选4
          case 'ffc_sx_zx4':
          case 'ssc_qe_zxfs':	//前二_直选复式
          case 'ffc_qe_zxfs':
          case 'ssc_he_zxfs':	//后二_直选复式
          case 'ffc_he_zxfs':
          case 'ssc_rx4_zx4':	//任四_组选4
          case 'ffc_rx4_zx4':
            wei0 = MathArray(1, 0, 9);
            wei1 = MathArray(1, 0, 9);
            while (wei0 / 1 === wei1 / 1) {
              wei0 = MathArray(1, 0, 9);
            }
            randomArray.push(wei0, wei1);
            for (i = 0; i < 2; i++) {
              save(this.selectArr[i], "" + randomArray[i], "reverse");
            }
            break;
          case 'ssc_dxds_qe':	//大小单双前二后二
          case 'ssc_dxds_he':
          case 283:
          case 284:
            wei0 = MathArray(1, 0, 3);
            wei1 = MathArray(1, 0, 3);
            while (wei0 / 1 === wei1 / 1) {
              wei0 = MathArray(1, 0, 3);
            }
            randomArray.push(wei0, wei1);
            for (i = 0; i < 2; i++) {
              save(this.selectArr[i], this.playBetContent[i].betDetail[Number(randomArray[i])], "reverse");
            }
            break;
          case 'ssc_sx_zxfs':	//四星_直选复式
          case 'ffc_sx_zxfs':
          case 'ssc_sx_sxzh':	//四星_组合
          case 'ffc_sx_sxzh':
            randomArray = MathArray(4, 0, 9);
            for (i = 0; i < 4; i++) {
              save(this.selectArr[i], "" + randomArray[i], "reverse");
            }
            break;
          case 'ssc_sx_zxds':	//四星_直选单式
          case 'ffc_sx_zxds':
          case 'ssc_rx4_zxds':	//任四_直选单式
          case 'ffc_rx4_zxds':
            randomArray = MathArray(4, 0, 9);
            randomArray = randomArray.join("");
            save(this.selectArr[0], randomArray, "reverse");
            break;
          case 'ssc_sx_zx24':	//四星_组选24
          case 'ffc_sx_zx24':
          case 'ssc_rx4_zx24':	//任四_组选24
          case 'ffc_rx4_zx24':
            randomArray = MathArray(4, 0, 9);
            for (i = 0; i < 4; i++) {
              save(this.selectArr[0], "" + randomArray[i], "reverse");
            }
            break;
          case 'ssc_sx_zx6':	//四星_组选6
          case 'ffc_sx_zx6':
          case 'ssc_qs_zsfs':	//前三_组三复式
          case 'ssc_zs_zsfs':	//中三_组三复式
          case 'ssc_hs_zsfs':	//后三_组三复式
          case 'ffc_qs_zsfs':
          case 'ffc_zs_zsfs':
          case 'ffc_hs_zsfs':
          case 'ssc_qe_zxze':	//前二_组选复式
          case 'ssc_he_zxze':	//后二_组选复式
          case 'ffc_qe_zxze':
          case 'ffc_he_zxze':
          case 'ssc_rx2_zuxfs':	//任二_组选复式
          case 'ffc_rx2_zuxfs':
          case 'ssc_rx3_zsfs':	//任三_组三复式
          case 'ffc_rx3_zsfs':
          case 'ssc_rx4_zx6':	//任四_组选6
          case 'ffc_rx4_zx6':
          case 'ssc_bdwd_qsem':	//不定位_前三二码
          case 'ssc_bdwd_zsem':	//不定位_中三二码
          case 'ssc_bdwd_hsem':	//不定位_后三二码
          case 'ssc_bdwd_sxem':	//不定位_四星二码
          case 'ffc_bdwd_qsem':
          case 'ffc_bdwd_zsem':
          case 'ffc_bdwd_hsem':
          case 'ffc_bdwd_sxem':
          case 'ffc_bdwd_wxem':
          case 'ssc_bdwd_wxem':	//不定位_五星二码
            wei0 = MathArray(1, 0, 9);
            wei1 = MathArray(1, 0, 9);
            while (wei0 / 1 === wei1 / 1) {
              wei0 = MathArray(1, 0, 9);
            }
            randomArray.push(wei0, wei1);
            for (i = 0; i < 2; i++) {
              save(this.selectArr[0], "" + randomArray[i], "reverse");
            }
            break;
          case 'ssc_qs_zxfs':	//前三_直选复式
          case 'ssc_zs_zxfs':	//中三_直选复式
          case 'ssc_hs_zxfs':	//后三_直选复式
          case 'ffc_qs_zxfs':
          case 'ffc_zs_zxfs':
          case 'ffc_hs_zxfs':
            randomArray = MathArray(3, 0, 9);
            for (i = 0; i < 3; i++) {
              save(this.selectArr[i], "" + randomArray[i], "reverse");
            }
            break;
          case 'ssc_qs_zxds':	//前三_直选单式
          case 'ssc_zs_zxds':	//中三_直选单式
          case 'ssc_hs_zxds':	//后三_直选单式
          case 'ffc_qs_zxds':
          case 'ffc_zs_zxds':
          case 'ffc_hs_zxds':
          case 'ssc_qs_zlds':	//前三_组六单式
          case 'ssc_zs_zlds':	//中三_组六单式
          case 'ssc_hs_zlds':	//后三_组六单式
          case 'ffc_qs_zlds':
          case 'ffc_zs_zlds':
          case 'ffc_hs_zlds':
          case 'ssc_qs_zxhh':	//前三_组选混合
          case 'ssc_zs_zxhh':	//中三_混合组选
          case 'ssc_hs_zxhh':	//后三_组选混合
          case 'ffc_qs_zxhh':
          case 'ffc_zs_zxhh':
          case 'ffc_hs_zxhh':
          case 'ssc_rx3_zxds':	//任三_直选单式
          case 'ffc_rx3_zxds':
          case 'ssc_rx3_zlds':	//任三_组六单式
          case 'ffc_rx3_zlds':
          case 'ssc_rx3_hhzx':	//任三_组选混合
          case 'ffc_rx3_hhzx':
            randomArray = MathArray(3, 0, 9);
            randomArray = randomArray.join("");
            save(this.selectArr[0], randomArray, "reverse");
            break;
          case 'ssc_qs_zxhz':	//前三_直选和值
          case 'ssc_zs_zxhz':	//中三_直选和值
          case 'ssc_hs_zxhz':	//后三_直选和值
          case 'ffc_qs_zxhz':
          case 'ffc_zs_zxhz':
          case 'ffc_hs_zxhz':
          case 'ssc_rx3_zxhz':	//任三_直选和值
          case 'ffc_rx3_zxhz':
            randomArray = MathArray(1, 0, 27);
            randomArray = randomArray.join("");
            save(this.selectArr[0], randomArray, "reverse");
            break;
          case 'ssc_hs_zxkd':	//前三_直选跨度
          case 'ssc_zs_zxkd':	//中三_直选跨度
          case 'ssc_qs_zxkd':	//后三_直选跨度
          case 'ffc_hs_zxkd':
          case 'ffc_zs_zxkd':
          case 'ffc_qs_zxkd':
          case 'ssc_qe_zxkd':	//前二_直选跨度
          case 'ssc_he_zxkd':	//后二_直选跨度
          case 'ffc_qe_zxkd':
          case 'ffc_he_zxkd':
          case 'ssc_qe_zxbd':	//前二_组选包胆
          case 'ssc_he_zxbd':	//后二_组选包胆
          case 'ffc_qe_zxbd':
          case 'ffc_he_zxbd':
          case 'ssc_bdwd_qsym':	//不定位_前三一码
          case 'ssc_bdwd_zsym':	//不定位_中三一码
          case 'ssc_bdwd_hsym':	//不定位_后三一码
          case 'ssc_bdwd_sxym':	//不定位_四星一码
          case 'ffc_bdwd_qsym':
          case 'ffc_bdwd_zsym':
          case 'ffc_bdwd_hsym':
          case 'ffc_bdwd_sxym':
          case 'ssc_qw_yffs':	//一帆风顺
          case 'ssc_qw_hscs':	//好事成双
          case 'ssc_qw_sxbx':	//三星报喜
          case 'ssc_qw_sjfc':	//四季发财
          case 'ffc_qw_yffs':
          case 'ffc_qw_hscs':
          case 'ffc_qw_sxbx':
          case 'ffc_qw_sjfc':
            randomArray = MathArray(1, 0, 9);
            randomArray = randomArray.join("");
            save(this.selectArr[0], randomArray, "reverse");
            break;
          case 'ssc_dxds_dxds':	//大小单双总和
          case 'ffc_dxds_dxds':
            randomArray = MathArray(1, 0, 3);
            randomArray = randomArray.join("");
            save(this.selectArr[0], randomArray, "reverse");
            break;
          case 'ssc_lh_wq':	//龙虎
          case 'ssc_lh_wb':
          case 'ssc_lh_ws':
          case 'ssc_lh_wg':
          case 'ssc_lh_qb':
          case 'ssc_lh_qs':
          case 'ssc_lh_qg':
          case 'ssc_lh_bs':
          case 'ssc_lh_bg':
          case 'ssc_lh_sg':
          case 'ffc_lh_wq':
          case 'ffc_lh_wb':
          case 'ffc_lh_ws':
          case 'ffc_lh_wg':
          case 'ffc_lh_qb':
          case 'ffc_lh_qs':
          case 'ffc_lh_qg':
          case 'ffc_lh_bs':
          case 'ffc_lh_bg':
          case 'ffc_lh_sg':
            randomArray = MathArray(1, 0, 2);
            save(this.selectArr[0], this.playBetContent[0].betDetail[Number(randomArray[0])], "reverse");
            break;
          case 'ssc_qs_zsds':	//前三_组三单式
          case 'ssc_zs_zsds':	//中三_组三单式
          case 'ssc_hs_zsds':	//后三_组三单式
          case 'ffc_qs_zsds':
          case 'ffc_zs_zsds':
          case 'ffc_hs_zsds':
          case 'ssc_rx3_zsds':	//任三_组三单式
          case 'ffc_rx3_zsds':
            wei0 = MathArray(1, 0, 9);
            wei1 = MathArray(1, 0, 9);
            wei2 = MathArray(1, 0, 9);
            while (wei0 / 1 !== wei1 / 1) {
              if (wei0 / 1 === wei1 / 1 === wei2 / 1) continue;
              if (wei0 / 1 === wei2 / 1 || wei1 / 1 === wei2 / 1) break;
              wei0 = MathArray(1, 0, 9);
              wei1 = MathArray(1, 0, 9);
              wei2 = MathArray(1, 0, 9);
            }
            randomArray.push(wei0, wei1, wei2);
            randomArray = randomArray.sort(this.asc_sort);
            randomArray = randomArray.join("");
            save(this.selectArr[0], randomArray, "reverse");
            break;
          case 'ssc_qs_zlfs':	//前三_组六复式
          case 'ssc_zs_zlfs':	//中三_组六复式
          case 'ssc_hs_zlfs':	//后三_组六复式
          case 'ffc_qs_zlfs':
          case 'ffc_zs_zlfs':
          case 'ffc_hs_zlfs':
          case 'ssc_rx3_zlfs':	//任三_组六复式
          case 'ffc_rx3_zlfs':
          case 'ssc_bdwd_wxsm':	//不定位_五星三码
          case 'ffc_bdwd_wxsm':
            randomArrayL = MathArray(3, 0, 9);
            wei0 = randomArrayL[0];
            wei1 = randomArrayL[1];
            wei2 = randomArrayL[2];
            randomArray.push(wei0, wei1, wei2);
            for (i = 0; i < 3; i++) {
              save(this.selectArr[0], "" + randomArray[i], "reverse");
            }
            break;
          case 'ssc_qe_zxds':	//前二_直选单式
          case 'ssc_he_zxds':	//后二_直选单式
          case 49:	//前二_组选单式
          case 56:	//后二_组选单式
          case 'ffc_qe_zxds':
          case 'ffc_he_zxds':
          case 226:
          case 233:
          case 'ssc_rx2_zxds':	//任二_直选单式
          case 'ssc_rx2_zuxds':	//任二_组选单式
          case 'ffc_rx2_zxds':
          case 'ffc_rx2_zuxds':
            randomArray = MathArray(2, 0, 9);
            randomArray = randomArray.join("");
            save(this.selectArr[0], randomArray, "reverse");
            break;
          case 'ssc_qe_zxhz':	//前二_直选和值
          case 'ssc_he_zxhz':	//后二_直选和值
          case 'ffc_qe_zxhz':
          case 'ffc_he_zxhz':
          case 'ssc_rx2_zxhz':	//任二_直选和值
          case 'ffc_rx2_zxhz':
            randomArray = MathArray(1, 0, 18);
            randomArray = randomArray.join("");
            save(this.selectArr[0], randomArray, "reverse");
            break;
          case 'ssc_rx2_zuxhz':	//任二_组选和值
          case 'ffc_rx2_zuxhz':
            randomArray = MathArray(1, 2, 17);
            save(this.selectArr[0], randomArray, "reverse");
            break;
          case 'ssc_dwd_wxdwd':	//五星_定位胆
          case 'ffc_dwd_wxdwd':
            randomArray = MathArray(1, 0, 9);
            randomFor = MathArray(1, 0, 4) / 1;
            save(this.selectArr[randomFor], "" + randomArray[0], "reverse");
            break;
          case 'pk10_dwd_wxdwd':
            randomArray = MathArray(1, 0, 9);
            randomFor = MathArray(1, 0, 9) / 1;
            save(this.selectArr[randomFor], "" + randomArray[0], "reverse");
            break;
          case 'ssc_rx2_zxfs':	//任二_直选复式
          case 'ffc_rx2_zxfs':
            randomArray = MathArray(2, 0, 9)
            randomFor = MathArray(2, 0, 4);
            for (i = 0; i < 2; i++) {
              save(this.selectArr[randomFor[i]], "" + randomArray[i], "reverse");
            }
            break;
          case 'ssc_rx3_zxfs':	//任三_直选复式
          case 'ffc_rx3_zxfs':
            randomArray = MathArray(3, 0, 9)
            randomFor = MathArray(3, 0, 4);
            for (i = 0; i < 3; i++) {
              save(this.selectArr[randomFor[i]], "" + randomArray[i], "reverse");
            }
            break;
          case 'ssc_rx4_zxfs':	//任四_直选复式
          case 'ffc_rx4_zxfs':
            randomArray = MathArray(4, 0, 9)
            randomFor = MathArray(4, 0, 4);
            for (i = 0; i < 4; i++) {
              save(this.selectArr[randomFor[i]], "" + randomArray[i], "reverse");
            }
            break;

          //十一选五
          case '11x5_qs_zxfs':	//前三_直选复式
          case '11x5_zs_zxfs':	//中三_直选复式
          case '11x5_hs_zxfs':	//后三_直选复式
            randomArray = MathArray(3, 1, 11);
            for (j = 0; j < 3; j++) {
              newRandomArray.push(randomArray[j] < 10 ? "" + randomArray[j] : "" + randomArray[j]);
            }
            for (i = 0; i < 3; i++) {
              save(this.selectArr[i], newRandomArray[i], "reverse");
            }
            break;
          case '11x5_qs_zxds':	//前三_直选单式
          case '11x5_zs_zxds':	//中三_直选单式
          case '11x5_hs_zxds':	//后三_直选单式
          case '11x5_qs_zuxds':	//前三_组选单式
          case '11x5_zs_zuxds':	//中三_组选单式
          case '11x5_hs_zuxds':	//后三_组选单式
            randomArray = MathArray(3, 1, 11);
            for (j = 0; j < 3; j++) {
              newRandomArray.push(randomArray[j] < 10 ? "0" + randomArray[j] : "" + randomArray[j]);
            }
            newRandomArray = newRandomArray.join("");
            save(this.selectArr[0], newRandomArray, "reverse");
            break;
          case '11x5_qs_zuxfs':	//前三_组选复式
          case '11x5_zs_zuxfs':	//中三_组选复式
          case '11x5_hs_zuxfs':	//后三_组选复式
            randomArray = MathArray(3, 1, 11);
            wei0 = randomArray[0] < 10 ? "" + randomArray[0] : "" + randomArray[0];
            wei1 = randomArray[1] < 10 ? "" + randomArray[1] : "" + randomArray[1];
            wei2 = randomArray[2] < 10 ? "" + randomArray[2] : "" + randomArray[2];
            this.selectArr[0].unshift(wei0, wei1, wei2);
            break;
          case '11x5_qs_zxdt':	//前三_组选胆拖
          case '11x5_zs_zxdt':	//中三_组选胆拖
          case '11x5_hs_zxdt':	//后三_组选胆拖
            wei0 = MathArray(1, 1, 11);
            wei1 = MathArray(2, 1, 11);
            while (wei1.indexOf(wei0 / 1) !== -1) {
              wei0 = MathArray(1, 1, 11);
            }
            wei0 = wei0 < 10 ? "0" + wei0 : "" + wei0;
            for (i = 0; i < 2; i++) {
              wei1[i] = wei1[i] < 10 ? "0" + wei1[i] : "" + wei1[i];
            }
            this.selectArr[0].push(wei0);
            this.selectArr[1].push(wei1[0], wei1[1]);
            break;
          case '11x5_qe_zxfs':	//前二_直选复式
          case '11x5_he_zxfs':	//后二_直选复式
          case '11x5_qe_zxdt':	//前二_组选胆拖
          case '11x5_he_zxdt':	//后二_组选胆拖
            randomArray = MathArray(2, 1, 11);
            for (j = 0; j < 2; j++) {
              newRandomArray.push(randomArray[j] < 10 ? "0" + randomArray[j] : "" + randomArray[j]);
            }
            for (i = 0; i < 2; i++) {
              save(this.selectArr[i], newRandomArray[i], "reverse");
            }
            break;
          case '11x5_qe_zxds':	//前二_直选单式
          case '11x5_he_zxds':	//后二_直选单式
          case '11x5_qe_zuxds':	//前二_组选单式
          case '11x5_he_zuxds':	//后二_组选单式
            randomArray = MathArray(2, 1, 11);
            for (j = 0; j < 2; j++) {
              newRandomArray.push(randomArray[j] < 10 ? "0" + randomArray[j] : "" + randomArray[j]);
            }
            newRandomArray = newRandomArray.join("");
            save(this.selectArr[0], newRandomArray, "reverse");
            break;
          case '11x5_qe_zuxfs':	//前二_组选复式
          case '11x5_he_zuxfs':	//后二_组选复式
            randomArray = MathArray(2, 1, 11);
            wei0 = randomArray[0] < 10 ? "0" + randomArray[0] : "" + randomArray[0];
            wei1 = randomArray[1] < 10 ? "0" + randomArray[1] : "" + randomArray[1];
            this.selectArr[0].unshift(wei0, wei1);
            break;
          case '11x5_bdwd_qsbdwd':	//不定位
          case '11x5_bdwd_zsbdwd':
          case '11x5_bdwd_hsbdwd':
            randomArray = MathArray(1, 1, 11);
            newRandomArray.push(randomArray[0] < 10 ? "0" + randomArray[0] : "" + randomArray[0]);
            this.selectArr[0].unshift(newRandomArray[0]);
            break;
          case '11x5_dwd_wxdwd':	//定位胆
            randomArray = MathArray(1, 1, 11);
            randomFor = MathArray(1, 0, 4) / 1;
            newRandomArray.push(randomArray[0] < 10 ? "0" + randomArray[0] : "" + randomArray[0]);
            save(this.selectArr[randomFor], newRandomArray[0], "reverse");
            break;
          case '11x5_rxfs_rxyzy':	//一中一
            randomArrayL = MathArray(1, 1, 11);
            wei0 = randomArrayL[0] < 10 ? "0" + randomArrayL[0] : "" + randomArrayL[0];
            randomArray.push(wei0);
            for (i = 0; i < 1; i++) {
              save(this.selectArr[0], randomArray[i], "reverse");
            }
            break;
          case '11x5_rxfs_rxeze':	//二中二
            randomArrayL = MathArray(2, 1, 11);
            randomArray = [];
            for (i = 0; i < 2; i++) {
              randomArray[i] = randomArrayL[i] < 10 ? "0" + randomArrayL[i] : "" + randomArrayL[i];
              save(this.selectArr[0], randomArray[i], "reverse");
            }
            break;
          case '11x5_rxfs_rxszs':	//三中三
            randomArrayL = MathArray(3, 1, 11);
            randomArray = [];
            for (i = 0; i < 3; i++) {
              randomArray[i] = randomArrayL[i] < 10 ? "0" + randomArrayL[i] : "" + randomArrayL[i];
              save(this.selectArr[0], randomArray[i], "reverse");
            }
            break;
          case '11x5_rxfs_rxsizsi':	//四中四
            randomArrayL = MathArray(4, 1, 11);
            randomArray = [];
            for (i = 0; i < 4; i++) {
              randomArray[i] = randomArrayL[i] < 10 ? "0" + randomArrayL[i] : "" + randomArrayL[i];
              save(this.selectArr[0], randomArray[i], "reverse");
            }
            break;
          case '11x5_rxfs_rxwzw':	//五中五
            randomArrayL = MathArray(5, 1, 11);
            randomArray = [];
            for (i = 0; i < 5; i++) {
              randomArray[i] = randomArrayL[i] < 10 ? "0" + randomArrayL[i] : "" + randomArrayL[i];
              save(this.selectArr[0], randomArray[i], "reverse");
            }
            break;
          case '11x5_rxfs_rxlzw':	//六中五
            randomArrayL = MathArray(6, 1, 11);
            randomArray = [];
            for (i = 0; i < 6; i++) {
              randomArray[i] = randomArrayL[i] < 10 ? "0" + randomArrayL[i] : "" + randomArrayL[i];
              save(this.selectArr[0], randomArray[i], "reverse");
            }
            break;
          case '11x5_rxfs_rxqzw':	//七中五
            randomArrayL = MathArray(7, 1, 11);
            randomArray = [];
            for (i = 0; i < 7; i++) {
              randomArray[i] = randomArrayL[i] < 10 ? "0" + randomArrayL[i] : "" + randomArrayL[i];
              save(this.selectArr[0], randomArray[i], "reverse");
            }
            break;
          case '11x5_rxfs_rxbzw':	//八中五
            randomArrayL = MathArray(8, 1, 11);
            randomArray = [];
            for (i = 0; i < 8; i++) {
              randomArray[i] = randomArrayL[i] < 10 ? "0" + randomArrayL[i] : "" + randomArrayL[i];
              save(this.selectArr[0], randomArray[i], "reverse");
            }
            break;
          case '11x5_rxds_rxyzy':	//单式一中一
            randomArrayL = MathArray(1, 1, 11);
            wei0 = randomArrayL[0] < 10 ? "0" + randomArrayL[0] : "" + randomArrayL[0];
            randomArray.push(wei0);
            newRandomArray = randomArray.join("");
            save(this.selectArr[0], newRandomArray, "reverse");
            break;
          case '11x5_rxds_rxeze':	//单式二中二
            randomArrayL = MathArray(2, 1, 11);
            wei0 = randomArrayL[0] < 10 ? "0" + randomArrayL[0] : "" + randomArrayL[0];
            wei1 = randomArrayL[1] < 10 ? "0" + randomArrayL[1] : "" + randomArrayL[1];
            randomArray.push(wei0, wei1);
            newRandomArray = randomArray.join("");
            save(this.selectArr[0], newRandomArray, "reverse");
            break;
          case '11x5_rxds_rxszs':	//单式三中三
            randomArrayL = MathArray(3, 1, 11);
            wei0 = randomArrayL[0] < 10 ? "0" + randomArrayL[0] : "" + randomArrayL[0];
            wei1 = randomArrayL[1] < 10 ? "0" + randomArrayL[1] : "" + randomArrayL[1];
            wei2 = randomArrayL[2] < 10 ? "0" + randomArrayL[2] : "" + randomArrayL[2];
            randomArray.push(wei0, wei1, wei2);
            newRandomArray = randomArray.join("");
            save(this.selectArr[0], newRandomArray, "reverse");
            break;
          case '11x5_rxds_rxsizsi':	//单式四中四
            randomArrayL = MathArray(4, 1, 11);
            wei0 = randomArrayL[0] < 10 ? "0" + randomArrayL[0] : "" + randomArrayL[0];
            wei1 = randomArrayL[1] < 10 ? "0" + randomArrayL[1] : "" + randomArrayL[1];
            wei2 = randomArrayL[2] < 10 ? "0" + randomArrayL[2] : "" + randomArrayL[2];
            wei3 = randomArrayL[3] < 10 ? "0" + randomArrayL[3] : "" + randomArrayL[3];
            randomArray.push(wei0, wei1, wei2, wei3);
            newRandomArray = randomArray.join("");
            save(this.selectArr[0], newRandomArray, "reverse");
            break;
          case '11x5_rxds_rxwzw':	//单式五中五
            randomArrayL = MathArray(5, 1, 11);
            wei0 = randomArrayL[0] < 10 ? "0" + randomArrayL[0] : "" + randomArrayL[0];
            wei1 = randomArrayL[1] < 10 ? "0" + randomArrayL[1] : "" + randomArrayL[1];
            wei2 = randomArrayL[2] < 10 ? "0" + randomArrayL[2] : "" + randomArrayL[2];
            wei3 = randomArrayL[3] < 10 ? "0" + randomArrayL[3] : "" + randomArrayL[3];
            wei4 = randomArrayL[4] < 10 ? "0" + randomArrayL[4] : "" + randomArrayL[4];
            randomArray.push(wei0, wei1, wei2, wei3, wei4, wei5);
            newRandomArray = randomArray.join("");
            save(this.selectArr[0], newRandomArray, "reverse");
            break;
          case '11x5_rxds_rxlzw':	//单式六中五
            randomArrayL = MathArray(6, 1, 11);
            wei0 = randomArrayL[0] < 10 ? "0" + randomArrayL[0] : "" + randomArrayL[0];
            wei1 = randomArrayL[1] < 10 ? "0" + randomArrayL[1] : "" + randomArrayL[1];
            wei2 = randomArrayL[2] < 10 ? "0" + randomArrayL[2] : "" + randomArrayL[2];
            wei3 = randomArrayL[3] < 10 ? "0" + randomArrayL[3] : "" + randomArrayL[3];
            wei4 = randomArrayL[4] < 10 ? "0" + randomArrayL[4] : "" + randomArrayL[4];
            wei5 = randomArrayL[5] < 10 ? "0" + randomArrayL[5] : "" + randomArrayL[5];
            randomArray.push(wei0, wei1, wei2, wei3, wei4, wei5);
            newRandomArray = randomArray.join("");
            save(this.selectArr[0], newRandomArray, "reverse");
            break;
          case '11x5_rxds_rxqzw':	//单式七中五
            randomArrayL = MathArray(7, 1, 11);
            wei0 = randomArrayL[0] < 10 ? "0" + randomArrayL[0] : "" + randomArrayL[0];
            wei1 = randomArrayL[1] < 10 ? "0" + randomArrayL[1] : "" + randomArrayL[1];
            wei2 = randomArrayL[2] < 10 ? "0" + randomArrayL[2] : "" + randomArrayL[2];
            wei3 = randomArrayL[3] < 10 ? "0" + randomArrayL[3] : "" + randomArrayL[3];
            wei4 = randomArrayL[4] < 10 ? "0" + randomArrayL[4] : "" + randomArrayL[4];
            wei5 = randomArrayL[5] < 10 ? "0" + randomArrayL[5] : "" + randomArrayL[5];
            wei6 = randomArrayL[6] < 10 ? "0" + randomArrayL[6] : "" + randomArrayL[6];
            randomArray.push(wei0, wei1, wei2, wei3, wei4, wei5, wei6);
            newRandomArray = randomArray.join("");
            save(this.selectArr[0], newRandomArray, "reverse");
            break;
          case '11x5_rxds_rxbzw':	//单式八中五
            randomArrayL = MathArray(8, 1, 11);
            wei0 = randomArrayL[0] < 10 ? "0" + randomArrayL[0] : "" + randomArrayL[0];
            wei1 = randomArrayL[1] < 10 ? "0" + randomArrayL[1] : "" + randomArrayL[1];
            wei2 = randomArrayL[2] < 10 ? "0" + randomArrayL[2] : "" + randomArrayL[2];
            wei3 = randomArrayL[3] < 10 ? "0" + randomArrayL[3] : "" + randomArrayL[3];
            wei4 = randomArrayL[4] < 10 ? "0" + randomArrayL[4] : "" + randomArrayL[4];
            wei5 = randomArrayL[5] < 10 ? "0" + randomArrayL[5] : "" + randomArrayL[5];
            wei6 = randomArrayL[6] < 10 ? "0" + randomArrayL[6] : "" + randomArrayL[6];
            wei7 = randomArrayL[7] < 10 ? "0" + randomArrayL[7] : "" + randomArrayL[7];
            randomArray.push(wei0, wei1, wei2, wei3, wei4, wei5, wei6, wei7);
            newRandomArray = randomArray.join("");
            save(this.selectArr[0], newRandomArray, "reverse");
            break;

          //福彩3D
          case '3d/p3_sx_zxfs':	//三星_直选复式
            randomArray = MathArray(3, 0, 9);
            for (i = 0; i < 3; i++) {
              save(this.selectArr[i], "" + randomArray[i], "reverse");
            }
            break;
          case '3d/p3_sx_zxds':	//三星_直选单式
          case '3d/p3_sx_zxhh':	//三星_组选混合
            randomArray = MathArray(3, 0, 9);
            randomArray = randomArray.join("");
            save(this.selectArr[0], randomArray, "reverse");
            break;
          case '3d/p3_sx_zxzs':	//三星_组三复式
            wei0 = MathArray(1, 0, 9);
            wei1 = MathArray(1, 0, 9);
            while (wei0 / 1 === wei1 / 1) {
              wei0 = MathArray(1, 0, 9);
            }
            randomArray.push(wei0, wei1);
            for (i = 0; i < 2; i++) {
              save(this.selectArr[0], "" + randomArray[i], "reverse");
            }
            break;
          case '3d/p3_sx_zxzl':	//三星_组六复式
            randomArrayL = MathArray(3, 0, 9);
            wei0 = randomArrayL[0];
            wei1 = randomArrayL[1];
            wei2 = randomArrayL[2];
            randomArray.push(wei0, wei1, wei2);
            for (i = 0; i < 3; i++) {
              save(this.selectArr[0], "" + randomArray[i], "reverse");
            }
            break;
          case '3d/p3_qe_zxfs':	//前二_直选复式
          case '3d/p3_he_zxfs':	//后二_直选复式
            wei0 = MathArray(1, 0, 9);
            wei1 = MathArray(1, 0, 9);
            while (wei0 / 1 === wei1 / 1) {
              wei0 = MathArray(1, 0, 9);
            }
            randomArray.push(wei0, wei1);
            for (i = 0; i < 2; i++) {
              save(this.selectArr[i], "" + randomArray[i], "reverse");
            }
            break;
          case '3d/p3_qe_zxds':	//前二_直选单式
          case '3d/p3_he_zxds':	//后二_直选单式
          case 102:	//前二_组选单式
          case 106:	//后二_组选单式
            randomArray = MathArray(2, 0, 9);
            randomArray = randomArray.join("");
            save(this.selectArr[0], randomArray, "reverse");
            break;
          case 101:	//前二_组选复式
          case 105:	//后二_组选复式
            wei0 = MathArray(1, 0, 9);
            wei1 = MathArray(1, 0, 9);
            while (wei0 / 1 === wei1 / 1) {
              wei0 = MathArray(1, 0, 9);
            }
            randomArray.push(wei0, wei1);
            for (i = 0; i < 2; i++) {
              save(this.selectArr[0], "" + randomArray[i], "reverse");
            }
            break;
          case '3d/p3_dwd_dwd':	//定位胆
            randomArray = MathArray(1, 0, 9);
            randomFor = MathArray(1, 0, 2) / 1;
            save(this.selectArr[randomFor], "" + randomArray[0], "reverse");
            break;
          case '3d/p3_bdwd_ymbdwd':	//二码不定位胆
            wei0 = MathArray(1, 0, 9);
            wei1 = MathArray(1, 0, 9);
            while (wei0 / 1 === wei1 / 1) {
              wei0 = MathArray(1, 0, 9);
            }
            randomArray.push(wei0, wei1);
            for (i = 0; i < 2; i++) {
              save(this.selectArr[0], "" + randomArray[i], "reverse");
            }
            break;
          case '3d/p3_bdwd_embdwd':	//一码不定位胆
            randomArray = MathArray(1, 0, 9);
            randomArray = randomArray.join("");
            save(this.selectArr[0], randomArray, "reverse");
            break;

          //快乐8
          case 'klc_rx_rx1':	//任选一
            randomArray = MathArray(1, 1, 80);
            newRandomArray = randomArray[0] < 10 ? "0" + randomArray[0] : "" + randomArray[0];
            save(this.selectArr[0], newRandomArray, "reverse");
            break;
          case 'klc_rx_rx2':	//任选二
            randomArray = MathArray(2, 1, 80);
            wei0 = randomArray[0] < 10 ? "0" + randomArray[0] : "" + randomArray[0];
            wei1 = randomArray[1] < 10 ? "0" + randomArray[1] : "" + randomArray[1];
            newRandomArray.push(wei0, wei1);
            for (i = 0; i < 2; i++) {
              save(this.selectArr[0], newRandomArray[i], "reverse");
            }
            break;
          case 'klc_rx_rx3':	//任选三
            randomArray = MathArray(3, 1, 80);
            wei0 = randomArray[0] < 10 ? "0" + randomArray[0] : "" + randomArray[0];
            wei1 = randomArray[1] < 10 ? "0" + randomArray[1] : "" + randomArray[1];
            wei2 = randomArray[2] < 10 ? "0" + randomArray[2] : "" + randomArray[2];
            newRandomArray.push(wei0, wei1, wei2);
            for (i = 0; i < 3; i++) {
              save(this.selectArr[0], newRandomArray[i], "reverse");
            }
            break;
          case 'klc_rx_rx4':	//任选四
            randomArray = MathArray(4, 1, 80);
            wei0 = randomArray[0] < 10 ? "0" + randomArray[0] : "" + randomArray[0];
            wei1 = randomArray[1] < 10 ? "0" + randomArray[1] : "" + randomArray[1];
            wei2 = randomArray[2] < 10 ? "0" + randomArray[2] : "" + randomArray[2];
            wei3 = randomArray[3] < 10 ? "0" + randomArray[3] : "" + randomArray[3];
            newRandomArray.push(wei0, wei1, wei2, wei3);
            for (i = 0; i < 4; i++) {
              save(this.selectArr[0], newRandomArray[i], "reverse");
            }
            break;
          case 'klc_rx_rx5':	//任选五
            randomArray = MathArray(5, 1, 80);
            wei0 = randomArray[0] < 10 ? "0" + randomArray[0] : "" + randomArray[0];
            wei1 = randomArray[1] < 10 ? "0" + randomArray[1] : "" + randomArray[1];
            wei2 = randomArray[2] < 10 ? "0" + randomArray[2] : "" + randomArray[2];
            wei3 = randomArray[3] < 10 ? "0" + randomArray[3] : "" + randomArray[3];
            wei4 = randomArray[4] < 10 ? "0" + randomArray[4] : "" + randomArray[4];
            newRandomArray.push(wei0, wei1, wei2, wei3, wei4);
            for (i = 0; i < 5; i++) {
              save(this.selectArr[0], newRandomArray[i], "reverse");
            }
            break;
          case 'klc_rx_rx6':	//任选六
            randomArray = MathArray(6, 1, 80);
            wei0 = randomArray[0] < 10 ? "0" + randomArray[0] : "" + randomArray[0];
            wei1 = randomArray[1] < 10 ? "0" + randomArray[1] : "" + randomArray[1];
            wei2 = randomArray[2] < 10 ? "0" + randomArray[2] : "" + randomArray[2];
            wei3 = randomArray[3] < 10 ? "0" + randomArray[3] : "" + randomArray[3];
            wei4 = randomArray[4] < 10 ? "0" + randomArray[4] : "" + randomArray[4];
            wei5 = randomArray[5] < 10 ? "0" + randomArray[5] : "" + randomArray[5];
            newRandomArray.push(wei0, wei1, wei2, wei3, wei4, wei5);
            for (i = 0; i < 6; i++) {
              save(this.selectArr[0], newRandomArray[i], "reverse");
            }
            break;
          case 'klc_rx_rx7':	//任选七
            randomArray = MathArray(7, 1, 80);
            wei0 = randomArray[0] < 10 ? "0" + randomArray[0] : "" + randomArray[0];
            wei1 = randomArray[1] < 10 ? "0" + randomArray[1] : "" + randomArray[1];
            wei2 = randomArray[2] < 10 ? "0" + randomArray[2] : "" + randomArray[2];
            wei3 = randomArray[3] < 10 ? "0" + randomArray[3] : "" + randomArray[3];
            wei4 = randomArray[4] < 10 ? "0" + randomArray[4] : "" + randomArray[4];
            wei5 = randomArray[5] < 10 ? "0" + randomArray[5] : "" + randomArray[5];
            wei6 = randomArray[6] < 10 ? "0" + randomArray[6] : "" + randomArray[6];
            newRandomArray.push(wei0, wei1, wei2, wei3, wei4, wei5, wei6);
            for (i = 0; i < 7; i++) {
              save(this.selectArr[0], newRandomArray[i], "reverse");
            }
            break;
          case 'klc_qw_sxp':	//上下盘
          case 'klc_qw_jop':	//奇偶盘
            randomArray = MathArray(1, 0, 2);
            save(this.selectArr[0], "" + randomArray, "reverse")
            break;
          case 'klc_qw_hzdxds':	//和值大小单双
            randomArray = MathArray(1, 0, 3);
            save(this.selectArr[0], "" + randomArray, "reverse")
            break;

          //北京pk10
          case 'pk10_qy_zxfs':	//前一
            randomArray = MathArray(1, 1, 10);
            wei0 = randomArray[0] < 10 ? "" + randomArray[0] : "" + randomArray[0];
            save(this.selectArr[0], wei0, "reverse");
            break;
          case 'pk10_qe_zxfs':	//前二复式
            wei0 = MathArray(1, 1, 10);
            wei1 = MathArray(1, 1, 10);
            while (wei0 / 1 === wei1 / 1) {
              wei0 = MathArray(1, 1, 10);
            }
            wei0 = wei0 < 10 ? "" + wei0 : "" + wei0;
            wei1 = wei1 < 10 ? "" + wei1 : "" + wei1;
            randomArray.push(wei0, wei1);
            for (i = 0; i < 2; i++) {
              save(this.selectArr[i], "" + randomArray[i], "reverse");
            }
            break;
          case 'pk10_qe_zxds':	//前二单式
            randomArray = MathArray(2, 1, 10);
            while (randomArray[0] / 1 === randomArray[1] / 1) {
              randomArray = MathArray(2, 1, 10);
            }
            for (j = 0; j < 2; j++) {
              newRandomArray.push(randomArray[j] < 10 ? "0" + randomArray[j] : "" + randomArray[j]);
            }
            newRandomArray = newRandomArray.join("");
            save(this.selectArr[0], newRandomArray, "reverse");
            break;
          case 'pk10_qs_zxfs':	//前三复式
            wei0 = MathArray(1, 1, 10);
            wei1 = MathArray(1, 1, 10);
            wei2 = MathArray(1, 1, 10);
            while (wei0 / 1 === wei1 / 1 || wei0 / 1 === wei2 / 1 || wei1 / 1 === wei2 / 1) {
              wei0 = MathArray(1, 1, 10);
              wei1 = MathArray(1, 1, 10);
              wei2 = MathArray(1, 1, 10);
            }
            wei0 = wei0 < 10 ? wei0 : wei0;
            wei1 = wei1 < 10 ? wei1 : wei1;
            wei2 = wei2 < 10 ? wei2 : wei2;
            randomArray.push(wei0, wei1, wei2);
            for (i = 0; i < 3; i++) {
              save(this.selectArr[i], "" + randomArray[i], "reverse");
            }
            break;
          case 'pk10_qs_zxds':	//前三单式
            randomArray = MathArray(3, 1, 10);
            while (randomArray[0] / 1 === randomArray[1] / 1 || randomArray[0] / 1 === randomArray[2] / 1 || randomArray[1] / 1 === randomArray[2] / 1) {
              randomArray = MathArray(3, 1, 10);
            }
            for (j = 0; j < 3; j++) {
              newRandomArray.push(randomArray[j] < 10 ? "0" + randomArray[j] : "" + randomArray[j]);
            }
            newRandomArray = newRandomArray.join("");
            save(this.selectArr[0], newRandomArray, "reverse");
            break;
          case 'pk10_dwd_dwd':	//定位胆
            randomArray = MathArray(1, 1, 10);
            randomFor = MathArray(1, 1, 9) / 1;
            randomArray[0] = randomArray[0] < 10 ? "0" + randomArray[0] : "" + randomArray[0];
            save(this.selectArr[randomFor], randomArray[0], "add");
            break;
          //江苏快三
          case 306:
            randomArray = MathArray(1, 3, 18);
            randomArray = randomArray.join("");
            save(this.selectArr[0], randomArray, "reverse");
            break;
          case 307:
          case 309:
            randomArray = MathArray(1, 0, 5);
            randomArray = randomArray.join("");
            save(this.selectArr[0], randomArray, "reverse");
            break;
          case 308:
            randomArray = MathArray(2, 1, 6);
            for (i = 0; i < 2; i++) {
              save(this.selectArr[0], '' + randomArray[i], "reverse");
            }
            break;
          case 311:
            randomArray = MathArray(3, 1, 6);
            for (i = 0; i < 3; i++) {
              save(this.selectArr[0], '' + randomArray[i], "reverse");
            }
            break;
          case 312:
            randomArray = MathArray(1, 0, 3);
            randomArray = randomArray.join("");
            save(this.selectArr[0], randomArray, "reverse");
            break;
          default:
            console.log(`code:${this.playDetailCode} mapping random function is not found`);
        }
      },
      requestLotteryDrawInfo: function () {
        const target = this.$refs['lotteryDraw'];
        if (target) {
          target.timerClean();
        }
        getGameOneResult({lotteryGameId: this.gameId}).then(res => {
          if (res.currentStatus === 0 && res.currentData.gameResultNum) {
            const target = this.$refs['lotteryDraw'];
            if (target) {
              target.setTimerOptions(res.currentData);
              target.timerStart();
            }
          }
        }).catch(err => {

        });
      },
      requestLotteryBetDetail: function () {
        const _this = this;
        getMasterList({masterId: _this.playId}).then(res => {
          if (res.currentStatus === 0) {
            let tempArr = res.currentData;
            let tempMap = {};
            tempArr.forEach(item => {
              if (!tempMap[item.layoutType]) {
                let arr = [];
                arr.push(item);
                tempMap[item.layoutType] = {name: item.layoutType, list: arr};
              } else {
                tempMap[item.layoutType].list.push(item);
              }
            });
            tempArr = [];
            Object.keys(tempMap).forEach((group, x) => {
              tempMap[group].list.forEach((item, y) => {
                const {id, name, masterCode, monetaryUnit, icon, gameRuleDetailList, remark} = item;
                if (monetaryUnit) {
                  item.monetaryUnit = monetaryUnit.split(',');
                }
                if (icon === 'ball') {
                  gameRuleDetailList.forEach(item => {
                    item.betDetail = item.betDetail.split(',');
                  });
                }
                if (x === 0 && y === 0) {
                  _this.showType = icon === 'ball';
                  _this.playDetailId = id;
                  _this.playDetailCode = masterCode;
                  _this.playDescription = remark;
                  _this.playDetailGroupName = tempMap[group].name;
                  _this.playDetailName = item.ruleMasterName;
                  _this.scaleList = item.monetaryUnit;
                  _this.playBetContent = item.gameRuleDetailList;
                  _this.betPositionIsShow = _this.positionToolShowDic.indexOf(masterCode) !== -1;
                }
              });
              tempArr.push(tempMap[group]);
            });
            _this.lotteryPlayDetailList = tempArr;
          }
        }).catch(err => {
          console.log(`requestLotteryBetDetail error:${err}`)
        });
      },
      requestLotteryPlaysData: function () {
        getLotteryPlays({lotteryGameId: this.gameId}).then(res => {
          if (res.currentStatus === 0) {
            this.lotteryPlays = res.currentData;
            this.playId = res.currentData[0].id;
            this.requestLotteryBetDetail();
          }
        }).catch(error => {
          this.$message.error(`error:${error}`);
        });
      },
      init: function (obj) {
        const _this = this;
        _this.initBaseData(obj);
        _this.requestLotteryPlaysData();
        _this.getMenuGroup();
        _this.getMenuGames();
        _this.requestLotteryDrawInfo();
      },
      initBaseData: function (obj) {
        const _this = this, {typeId, groupId, gameId, gameName} = obj;
        _this.typeId = typeId;
        _this.groupId = groupId;
        _this.gameId = gameId;
        _this.gameName = gameName;
        document.title = '官方玩法';
      },
      getMenuGames: function () {
        const _this = this;
        _this.lotteryGroupList.some(item => {
          if (item.id == _this.groupId) {
            _this.lotteryGameList = item.childrenList;
            return true;
          }
          return false;
        });
      },
      getMenuGroup: function () {
        const _this = this;
        _this.$parent.menuList.some(item => {
          if (item.id == _this.typeId) {
            _this.lotteryGroupList = item.childrenList;
            return true;
          }
          return false;
        });
      },
      simplexInit: function (playDetailCode) {
        switch (playDetailCode) {
          case 'ssc_qs_zxds'://前三,中三,后三(单式,混合)
          case 'ssc_qs_zxhh':
          case 'ssc_qs_zlds':
          case 'ssc_qs_zsds':
          case 'ssc_zs_zxds':
          case 'ssc_zs_zlds':
          case 'ssc_zs_zsds':
          case 'ssc_zs_zxhh':
          case 'ssc_hs_zxds':
          case 'ssc_hs_zxhh':
          case 'ssc_hs_zlds':
          case 'ssc_hs_zsds':
          case 'ffc_qs_zxds':
          case 'ffc_zs_zxds':
          case 'ffc_hs_zxds':
          case 'ffc_qs_zxhh':
          case 'ffc_zs_zxhh':
          case 'ffc_hs_zxhh':
          case 'ffc_qs_zlds':
          case 'ffc_zs_zlds':
          case 'ffc_hs_zlds':
          case 'ffc_qs_zsds':
          case 'ffc_zs_zsds':
          case 'ffc_hs_zsds':
            this.maxCustomChoice = 3;
            this.customChoice = 3;
            this.minCustomChoice = 3;
            this.isAlterNum = true;
            break;
          case 'ssc_qe_zxds'://前二,后二(单式,混合)
          case 'ssc_qe_zxhh':
          case 'ssc_he_zxds':
          case 'ssc_he_zxhh':
          case 'ffc_qe_zxds':
          case 'ffc_he_zxds':
          case 'ffc_qe_zxhh':
          case 'ffc_he_zxhh':
            this.maxCustomChoice = 2;
            this.customChoice = 2;
            this.minCustomChoice = 2;
            this.isAlterNum = true;
            break;
          case 'ssc_wx_zxds'://五星(直选单式)
          case 'ffc_wx_zxds':
            this.maxCustomChoice = 5;
            this.customChoice = 5;
            this.minCustomChoice = 5;
            this.isAlterNum = true;
            break;
          case 'ssc_sx_zxds'://四星(直选单式)
          case 'ffc_sx_zxds':
            this.maxCustomChoice = 4;
            this.customChoice = 4;
            this.minCustomChoice = 4;
            this.isAlterNum = true;
            break;
          case 'ssc_rx2_zxds'://任选二(直选单式,直选和值,组选各项)
          case 'ssc_rx2_zxhz':
          case 'ssc_rx2_zuxfs':
          case 'ssc_rx2_zuxds':
          case 'ssc_rx2_zuxhz':
          case 'ffc_rx2_zxds':
          case 'ffc_rx2_zxhz':
          case 'ffc_rx2_zuxfs':
          case 'ffc_rx2_zuxds':
          case 'ffc_rx2_zuxhz':
            this.maxCustomChoice = 5;
            this.customChoice = 2;
            this.minCustomChoice = 2;
            this.isAlterNum = true;
            break;
          case 'ssc_rx3_zxds'://任选三(直选单式,直选和值,组选各项)
          case 'ffc_rx3_zxds':
          case 'ssc_rx3_zxhz':
          case 'ffc_rx3_zxhz':
          case 'ssc_rx3_zsfs':
          case 'ffc_rx3_zsfs':
          case 'ssc_rx3_zsds':
          case 'ffc_rx3_zsds':
          case 'ssc_rx3_zlfs':
          case 'ffc_rx3_zlfs':
          case 'ssc_rx3_zlds':
          case 'ffc_rx3_zlds':
          case 'ssc_rx3_hhzx':
          case 'ffc_rx3_hhzx':
            this.maxCustomChoice = 5;
            this.customChoice = 3;
            this.minCustomChoice = 3;
            this.isAlterNum = true;
            break;
          case 'ssc_rx4_zxds'://任选四(直选单式,直选和值,组选各项)
          case 'ffc_rx4_zxds':
          case 'ssc_rx4_zx4':
          case 'ffc_rx4_zx4':
          case 'ssc_rx4_zx24':
          case 'ffc_rx4_zx24':
          case 'ssc_rx4_zx12':
          case 'ffc_rx4_zx12':
          case 'ssc_rx4_zx6':
          case 'ffc_rx4_zx6':
            this.maxCustomChoice = 5;
            this.customChoice = 4;
            this.minCustomChoice = 4;
            this.isAlterNum = true;
            break;
          // ---------------   十一选五      -------------------//
          case '11x5_qs_zxds'://前三,中三,后三(单式)
          case '11x5_qs_zuxds':
          case '11x5_zs_zxds':
          case '11x5_zs_zuxds':
          case '11x5_hs_zxds':
          case '11x5_hs_zuxds':
            this.customChoice = 6;
            break;
          case '11x5_qe_zxds'://前二,后二(单式)
          case '11x5_qe_zuxds':
          case '11x5_he_zxds':
          case '11x5_he_zuxds':
            this.customChoice = 4;
            break;
          case '11x5_rxds_rxyzy'://任选单式(任选一中一)
            this.customChoice = 2;
            break;
          case '11x5_rxds_rxeze'://任选单式(任选二中二)
            this.customChoice = 4;
            break;
          case '11x5_rxds_rxszs'://任选单式(任选三中三)
            this.customChoice = 6;
            break;
          case '11x5_rxds_rxsizsi'://任选单式(任选四中四)
            this.customChoice = 8;
            break;
          case '11x5_rxds_rxwzw'://任选单式(任选五中五)
            this.customChoice = 10;
            break;
          case '11x5_rxfs_rxlzw'://任选单式(任选六中五)
            this.customChoice = 12;
            break;
          case '11x5_rxfs_rxqzw'://任选单式(任选七中五)
            this.customChoice = 14;
            break;
          case '11x5_rxfs_rxbzw'://任选单式(任选八中五)
            this.customChoice = 16;
            break;
          // ----------------------  PK10    ---------------------//
          case 'pk10_qe_zxds'://前二直选单式
            this.customChoice = 4;
            break;
          case 'pk10_qs_zxds'://前三(直选单式)
            this.customChoice = 6;
            break;
          // ----------------------  福彩3D,排列3   ---------------//
          case '3d/p3_sx_zxds':
          case '3d/p3_sx_zxhh':
            this.customChoice = 3;
            break;
          case '3d/p3_qe_zxds':
          case '3d/p3_qe_zxhh':
          case '3d/p3_he_zxds':
          case '3d/p3_he_zxhh':
            this.customChoice = 2;
            break;
          default:
            this.maxCustomChoice = 0;
            this.customChoice = 0;
            this.minCustomChoice = 0;
            this.isAlterNum = true;
        }
        console.log('simplexInit:%s,maxCustomChoice:%s', playDetailCode, this.maxCustomChoice);
        if (this.maxCustomChoice !== 0 && this.betPositionIsShow) {
          this.$nextTick(function () {
            this.$refs['positionToolBar'].checkedPosition(this.minCustomChoice);
          });
        }
      },
      chaseSetDialogCloseFun: function () {
        this.chaseSetDialogIsShow = false;
      },
      countstat: function (playDetailCode) {
        let _this = this, i = 0, j = 0, k = 0, x = 0, zhu = 0, count = 0, len = 0, inter = 0, arr = [], arrTemp = [],
          index, value, jsonData = {};
        //时时彩组选
        function groupSelect(arr1, arr2, num1, num2, call) {
          if (arr1.length >= num1 && arr2.length >= num2) {
            inter = 0; //交集个数
            for (index in arr1) {
              value = arr1[index];
              if (arr2.indexOf(value) !== -1) inter++;
            }
            count = Cnm(arr1.length, num1) * Cnm(arr2.length, num2);
            if (inter > 0) {
              if (!!call) {
                call();
              }
            }
          }
        }

        //任选复式
        function randomDuplex(num) {
          let index;
          for (index = 0; index < _this.selectArr.length; index++) {
            if (_this.selectArr[index].length > 0) {
              arr.push(_this.selectArr[index]);
            }
          }
          let CmnArray = Combination(arr, num);
          for (index = 0; index < CmnArray.length; index++) {
            count = 1;
            arrTemp = CmnArray[index].split("|");
            for (let i = 0; i < arrTemp.length; i++) {
              count *= arrTemp[i].split(",").length;
            }
            zhu += count;
          }
        }

        switch (playDetailCode) {
          // ------------------时时彩  -----------------//
          case 'ssc_wx_zxfs'://五星直选(直选复式)
          case 'ffc_wx_zxfs':
            zhu = this.selectArr[0].length * this.selectArr[1].length * this.selectArr[2].length * this.selectArr[3].length * this.selectArr[4].length;
            break;
          case 'ssc_wx_zxds'://五星直选(直选单式)
          case 'ffc_wx_zxds':
            arr = unique(this.selectArr[0], 5);
            this.selectArr[0] = arr[0];
            this.errorArray = arr[1];
            zhu = this.selectArr[0].length;
            break;
          case 'ssc_wx_wxzh'://五星直选(五星组合)
          case 'ffc_wx_wxzh':
            count = 1;
            arr = [this.selectArr[0], this.selectArr[1], this.selectArr[2], this.selectArr[3], this.selectArr[4]];
            for (i in arr) {
              count *= this.selectArr[i].length;
            }
            zhu = count * 5;
            break;
          case 'ssc_wx_zx120'://五星组选(组选120)
          case 'ffc_wx_zx120':
            if (this.selectArr[0].length > 4) {
              zhu = Cnm(this.selectArr[0].length, 5);
            }
            break;
          case 'ssc_wx_zx60'://五星组选(组选60)
          case 'ffc_wx_zx60':
            groupSelect(this.selectArr[0], this.selectArr[1], 1, 3, function () {
              count -= Cnm(inter, 1) * Cnm(_this.selectArr[1].length - 1, 2);
            });
            zhu = count;
            break;
          case 'ssc_wx_zx30'://五星组选(组选30)
          case 'ffc_wx_zx30':
            groupSelect(this.selectArr[0], this.selectArr[1], 2, 1, function () {
              count -= Cnm(inter, 2) * Cnm(2, 1);
              if (_this.selectArr[0].length - inter > 0) {
                count -= Cnm(inter, 1) * Cnm(_this.selectArr[0].length - inter, 1);
              }
            });
            zhu = count;
            break;
          case 'ssc_wx_zx20'://五星组选(组选20)
          case 'ffc_wx_zx20':
            groupSelect(this.selectArr[0], this.selectArr[1], 1, 2, function () {
              count -= Cnm(inter, 1) * Cnm(_this.selectArr[1].length - 1, 1);
            });
            zhu = count;
            break;
          case 'ssc_wx_zx10'://五星组选(组选10)
          case 'ffc_wx_zx10':
            groupSelect(this.selectArr[0], this.selectArr[1], 1, 1, function () {
              count -= Cnm(inter, 1);
            });
            zhu = count;
            break;
          case 'ssc_wx_zx5'://五星组选 组选5
          case 'ffc_wx_zx5':
            groupSelect(this.selectArr[0], this.selectArr[1], 1, 1, function () {
              count -= Cnm(inter, 1);
            });
            zhu = count;
            break;
          case 'ssc_sx_zxfs'://四星直选(直选复式)
          case 'ffc_sx_zxfs':
            zhu = this.selectArr[0].length * this.selectArr[1].length * this.selectArr[2].length * this.selectArr[3].length;
            break;
          case 'ssc_sx_zxds'://四星直选(直选单式)
          case 'ffc_sx_zxds':
            arr = unique(this.selectArr[0], 4);
            this.selectArr[0] = arr[0];
            this.errorArray = arr[1];
            zhu = this.selectArr[0].length;
            break;
          case 'ssc_sx_sxzh'://四星直选(四星组合)
          case 'ffc_sx_sxzh':
            zhu = this.selectArr[0].length * this.selectArr[1].length * this.selectArr[2].length * this.selectArr[3].length * 4;
            break;
          case 'ssc_sx_zx24'://四星组选 组选24
          case 'ffc_sx_zx24':
            if (this.selectArr[0].length > 3) {
              zhu += Cnm(this.selectArr[0].length, 4);
            }
            break;
          case 'ssc_sx_zx12'://四星组选 组选12
          case 'ffc_sx_zx12':
            groupSelect(this.selectArr[0], this.selectArr[1], 1, 2, function () {
              count -= Cnm(inter, 1) * Cnm(_this.selectArr[1].length - 1, 1);
            });
            zhu = count;
            break;
          case 'ssc_sx_zx6'://四星组选 组选6
          case 'ffc_sx_zx6':
            if (this.selectArr[0].length >= 2) {
              zhu += Cnm(this.selectArr[0].length, 2);
            }
            break;
          case 'ssc_sx_zx4'://四星组选 组选4
          case 'ffc_sx_zx4':
            groupSelect(this.selectArr[0], this.selectArr[1], 1, 1, function () {
              count -= Cnm(inter, 1);
            });
            zhu = count;
            break;
          case 'ssc_hs_zxkd'://前三,中三,后三(直选跨度)
          case 'ssc_zs_zxkd':
          case 'ssc_qs_zxkd':
          case 'ffc_hs_zxkd':
          case 'ffc_zs_zxkd':
          case 'ffc_qs_zxkd':
            jsonData = {0: 10, 1: 54, 2: 96, 3: 126, 4: 144, 5: 150, 6: 144, 7: 126, 8: 96, 9: 54};
            for (i = 0; i < this.selectArr[0].length; i++) {
              zhu += jsonData[parseInt(this.selectArr[0][i])];
            }
            break;
          case 'ssc_qs_zxfs'://前三,中三,后三(直选复式)
          case 'ssc_zs_zxfs':
          case 'ssc_hs_zxfs':
          case 'ffc_qs_zxfs':
          case 'ffc_zs_zxfs':
          case 'ffc_hs_zxfs':
            zhu = this.selectArr[0].length * this.selectArr[1].length * this.selectArr[2].length;
            break;
          case 'ssc_qs_zxds'://前三,中三,后三(直选单式)
          case 'ssc_zs_zxds':
          case 'ssc_hs_zxds':
          case 'ffc_qs_zxds':
          case 'ffc_zs_zxds':
          case 'ffc_hs_zxds':
            arr = unique(this.selectArr[0], 3);
            this.selectArr[0] = arr[0];
            this.errorArray = arr[1];
            zhu = this.selectArr[0].length;
            break;
          case 'ssc_qs_zxhz'://前三,中三,后三(直选和值)
          case 'ssc_zs_zxhz':
          case 'ssc_hs_zxhz':
          case 'ffc_qs_zxhz':
          case 'ffc_zs_zxhz':
          case 'ffc_hs_zxhz':
            for (i = 0; i < this.selectArr[0].length; i += 1) {
              count = 0;
              for (j = 0; j < 10; j += 1) {
                for (k = 0; k < 10; k += 1) {
                  for (x = 0; x < 10; x += 1) {
                    if (j + k + x == this.selectArr[0][i]) {
                      count = count + 1;
                    }
                  }
                }
              }
              zhu += count;
            }
            break;
          case 'ssc_qs_zlfs'://前三,中三,后三(组六复式)
          case 'ssc_zs_zlfs':
          case 'ssc_hs_zlfs':
          case 'ffc_qs_zlfs':
          case 'ffc_zs_zlfs':
          case 'ffc_hs_zlfs':
            zhu = Cnm(this.selectArr[0].length, 3);
            break;
          case 'ssc_qs_zsfs'://前三,中三,后三(组三复式)
          case 'ssc_zs_zsfs':
          case 'ssc_hs_zsfs':
          case 'ffc_qs_zsfs':
          case 'ffc_zs_zsfs':
          case 'ffc_hs_zsfs':
            zhu = Cnm(this.selectArr[0].length, 2) * 2;
            break;
          case 'ssc_qs_zxhh'://前三,中三,后三(组选混合)
          case 'ssc_zs_zxhh':
          case 'ssc_hs_zxhh':
          case 'ffc_qs_zxhh':
          case 'ffc_zs_zxhh':
          case 'ffc_hs_zxhh':
            arr = uniqueCnm(this.selectArr[0], 3);
            this.selectArr[0] = arr[0];
            this.errorArray = arr[1];
            zhu = this.selectArr[0].length;
            break;
          case 'ssc_qs_zlds'://前三,中三,后三(组六单式)
          case 'ssc_zs_zlds':
          case 'ssc_hs_zlds':
          case 'ffc_qs_zlds':
          case 'ffc_zs_zlds':
          case 'ffc_hs_zlds':
            arr = uniqueCnm6(this.selectArr[0], 3);
            this.selectArr[0] = arr[0];
            this.errorArray = arr[1];
            zhu = this.selectArr[0].length;
            break;
          case 'ssc_qs_zsds'://前三,中三,后三(组三单式)
          case 'ssc_zs_zsds':
          case 'ssc_hs_zsds':
          case 'ffc_qs_zsds':
          case 'ffc_zs_zsds':
          case 'ffc_hs_zsds':
            arr = this.uniqueCnm3(this.selectArr[0], 3);
            this.selectArr[0] = arr[0];
            this.errorArray = arr[1];
            zhu = this.selectArr[0].length;
            break;
          case 'ssc_qe_zxfs'://前二,后二(直选复式)
          case 'ssc_he_zxfs':
          case 'ffc_qe_zxfs':
          case 'ffc_he_zxfs':
            zhu = this.selectArr[0].length * this.selectArr[1].length;
            break;
            zhu = Cnm(this.selectArr[0].length, 2);
            break;
          case 'ssc_qe_zxds'://前二,后二(直选单式)
          case 'ssc_he_zxds':
          case 'ffc_qe_zxds':
          case 'ffc_he_zxds':
            arr = unique(this.selectArr[0], 2);
            this.selectArr[0] = arr[0];
            this.errorArray = arr[1];
            zhu = this.selectArr[0].length;
            break;
          case 'ssc_qe_zxhz'://前二,后二(直选和值)
          case 'ssc_he_zxhz':
          case 'ffc_qe_zxhz':
          case 'ffc_he_zxhz':
            for (i = 0; i < this.selectArr[0].length; i += 1) {
              count = 0;
              for (j = 0; j < 10; j += 1) {
                for (k = 0; k < 10; k += 1) {
                  if (j + k == this.selectArr[0][i]) {
                    count = count + 1;
                  }
                }
              }
              zhu += count;
            }
            break;
          case 'ssc_qe_zxkd'://前二,后二(直选跨度)
          case 'ssc_he_zxkd':
          case 'ffc_qe_zxkd':
          case 'ffc_he_zxkd':
            jsonData = {0: 10, 1: 18, 2: 16, 3: 14, 4: 12, 5: 10, 6: 8, 7: 6, 8: 4, 9: 2};
            for (i = 0; i < this.selectArr[0].length; i++) {
              zhu += jsonData[parseInt(this.selectArr[0][i])];
            }
            break;
          case 'ssc_qe_zxhh'://前二,后二(组选混合)(改为组选单式)
          case 'ssc_he_zxhh':
          case 'ffc_qe_zxhh':
          case 'ffc_he_zxhh':
            arr = uniqueCnm(this.selectArr[0], 2);
            this.selectArr[0] = arr[0];
            this.errorArray = arr[1];
            zhu = this.selectArr[0].length;
            break;
          case 'ssc_qe_zxbd'://前二,后二(组选包胆)
          case 'ssc_he_zxbd':
          case 'ffc_qe_zxbd':
          case 'ffc_he_zxbd':
            zhu = this.selectArr[0].length * 9;
            break;
          case 'ssc_bdwd_qsym'://不定位胆(三星一码,四星一码)
          case 'ssc_bdwd_sxym':
          case 'ssc_bdwd_zsym':
          case 'ssc_bdwd_hsym':
          case 'ffc_bdwd_qsym':
          case 'ffc_bdwd_sxym':
          case 'ffc_bdwd_zsym':
          case 'ffc_bdwd_hsym':
            zhu = this.selectArr[0].length;
            break;
          case 'ssc_bdwd_qsem'://不定位胆(三星二码,四星二码,五星二码)
          case 'ssc_bdwd_zsem':
          case 'ssc_bdwd_hsem':
          case 'ssc_bdwd_sxem':
          case 'ssc_bdwd_wxem':
          case 'ffc_bdwd_qsem':
          case 'ffc_bdwd_zsem':
          case 'ffc_bdwd_hsem':
          case 'ffc_bdwd_sxem':
          case 'ffc_bdwd_wxem':
            zhu = this.selectArr[0].length * (this.selectArr[0].length - 1) / 2;
            break;
          case 'ssc_bdwd_wxsm'://不定位胆(五星三码)
          case 'ffc_bdwd_wxsm':
            zhu = Cnm(this.selectArr[0].length, 3);
            break;
          case 'ssc_dwd_wxdwd'://定位胆(五星定位胆)
          case 'ffc_dwd_wxdwd':
            arr = [this.selectArr[0], this.selectArr[1], this.selectArr[2], this.selectArr[3], this.selectArr[4]];
            for (index in arr) {
              zhu += this.selectArr[index].length;
            }
            break;
          case 'ssc_qw_yffs'://趣味(一帆风顺,好事成双,三星报喜,四季发财)
          case 'ssc_qw_hscs':
          case 'ssc_qw_sxbx':
          case 'ssc_qw_sjfc':
          case 'ssc_dxds_dxds'://大小单双总和
          case 'ssc_lh_wq':	//龙虎
          case 'ssc_lh_wb':
          case 'ssc_lh_ws':
          case 'ssc_lh_wg':
          case 'ssc_lh_qb':
          case 'ssc_lh_qs':
          case 'ssc_lh_qg':
          case 'ssc_lh_bs':
          case 'ssc_lh_bg':
          case 'ssc_lh_sg':
          case 'ffc_qw_yffs'://趣味(一帆风顺,好事成双,三星报喜,四季发财)
          case 'ffc_qw_hscs':
          case 'ffc_qw_sxbx':
          case 'ffc_qw_sjfc':
          case 'ffc_dxds_dxds'://大小单双总和
          case 'ffc_lh_wq':	//龙虎
          case 'ffc_lh_wb':
          case 'ffc_lh_ws':
          case 'ffc_lh_wg':
          case 'ffc_lh_qb':
          case 'ffc_lh_qs':
          case 'ffc_lh_qg':
          case 'ffc_lh_bs':
          case 'ffc_lh_bg':
          case 'ffc_lh_sg':
          case 'ks_hz_zx':	//快三总和
          case 'ks_eth_fs':	//快三2T
          case 'ks_sth_dx':	//快三3T
          case 'ks_sth_tx':	//快三3T
          case 'ks_slh_dx':	//快三3L
          case 'ks_slh_tx':	//快三3L全
            zhu = this.selectArr[0].length;
            break;
          case 'ks_ebth_bz':	//快三2BT
            len = this.selectArr[0].length;
            if (len >= 2) {
              zhu = len * (len - 1) / 2;
            } else {
              zhu = 0;
            }
            break;
          case 'ks_sbth_bz':	//快三3BT
            len = this.selectArr[0].length;
            if (len >= 3) {
              zhu = len * (len - 1) * (len - 2) / 6;
            } else {
              zhu = 0;
            }
            break;
          case 'ssc_rx2_zxfs'://任选二(直选复式)
          case 'ffc_rx2_zxfs':
            randomDuplex(2);
            break;
          case 'ssc_rx2_zxds'://任选二(直选单式)
          case 'ffc_rx2_zxds':
            arr = unique(this.selectArr[0], 2);
            this.selectArr[0] = arr[0];
            this.errorArray = arr[1];
            zhu = this.selectArr[0].length * Cnm(this.customChoice, 2) * this.positionPlan;
            break;
          case 'ssc_rx2_zxhz'://任选二(直选和值)
          case 'ffc_rx2_zxhz':
            count = 0;
            jsonData = {
              0: 1,
              1: 2,
              2: 3,
              3: 4,
              4: 5,
              5: 6,
              6: 7,
              7: 8,
              8: 9,
              9: 10,
              10: 9,
              11: 8,
              12: 7,
              13: 6,
              14: 5,
              15: 4,
              16: 3,
              17: 2,
              18: 1
            };
            for (index in this.selectArr[0]) {
              count += jsonData[this.selectArr[0][index] / 1];
            }
            zhu = count * Cnm(this.customChoice, 2) * this.positionPlan;
            break;
          case 'ssc_rx2_zuxfs'://任选二(组选复式)
          case 'ffc_rx2_zuxfs':
            count = this.selectArr[0].length * (this.selectArr[0].length - 1) / 2;
            zhu = count * Cnm(this.customChoice, 2) * this.positionPlan;
            break;
          case 'ssc_rx2_zuxds'://任选二(组选单式)
          case 'ffc_rx2_zuxds':
            arr = uniqueCnm(this.selectArr[0], 2);
            this.selectArr[0] = arr[0];
            this.errorArray = arr[1];
            zhu = this.selectArr[0].length * Cnm(this.customChoice, 2) * this.positionPlan;
            break;
          case 'ssc_rx3_zxfs'://任选三(直选复式)
          case 'ffc_rx3_zxfs':
            randomDuplex(3);
            break;
          case 'ssc_rx3_zxds'://任选三(直选单式)
          case 'ffc_rx3_zxds':
            arr = unique(this.selectArr[0], 3);
            this.selectArr[0] = arr[0];
            this.errorArray = arr[1];
            zhu = this.selectArr[0].length * Cnm(this.customChoice, 3) * this.positionPlan;
            break;
          case 'ssc_rx3_zxhz'://任选三(直选和值)
          case 'ffc_rx3_zxhz':
            jsonData = {
              0: 1,
              1: 3,
              2: 6,
              3: 10,
              4: 15,
              5: 21,
              6: 28,
              7: 36,
              8: 45,
              9: 55,
              10: 63,
              11: 69,
              12: 73,
              13: 75,
              14: 75,
              15: 73,
              16: 69,
              17: 63,
              18: 55,
              19: 45,
              20: 36,
              21: 28,
              22: 21,
              23: 15,
              24: 10,
              25: 6,
              26: 3,
              27: 1
            };
            count = 0;
            let s = 0;
            for (index in this.selectArr[0]) {
              s = this.selectArr[0][index] / 1;
              count += jsonData[s];
            }
            zhu = count * Cnm(this.customChoice, 3) * this.positionPlan;
            break;
          case 'ssc_rx3_zsfs'://任选三(组三复式)
          case 'ffc_rx3_zsfs':
            let n = this.selectArr[0].length;
            count = n * (n - 1);
            zhu = count * Cnm(this.customChoice, 3) * this.positionPlan;
            break;
          case 'ssc_rx3_zsds'://任选三(组三单式)
          case 'ffc_rx3_zsds':
            arr = this.uniqueCnm3(this.selectArr[0], 3);
            this.selectArr[0] = arr[0];
            this.errorArray = arr[1];
            zhu = this.selectArr[0].length * Cnm(this.customChoice, 3) * this.positionPlan;
            break;
          case 'ssc_rx3_zlfs'://任选三(组六复式)
          case 'ffc_rx3_zlfs':
            zhu = Cnm(this.selectArr[0].length, 3) * Cnm(this.customChoice, 3) * this.positionPlan;
            break;
          case 'rx3_zlds'://任选三(组六单式)
            arr = uniqueCnm6(this.selectArr[0], 3);
            this.selectArr[0] = arr[0];
            this.errorArray = arr[1];
            zhu = this.selectArr[0].length * Cnm(this.customChoice, 3) * this.positionPlan;
            break;
          case 'ssc_rx3_hhzx'://任选三(混合组选)
          case 'ffc_rx3_hhzx':
            arr = uniqueCnm(this.selectArr[0], 3);
            this.selectArr[0] = arr[0];
            this.errorArray = arr[1];
            zhu = this.selectArr[0].length * Cnm(this.customChoice, 3) * this.positionPlan;
            break;
          case 'ssc_rx4_zxfs'://任选四(直选复式)
          case 'ffc_rx4_zxfs':
            randomDuplex(4);
            break;
          case 'ssc_rx4_zxds'://任选四(直选单式)
          case 'ffc_rx4_zxds':
            arr = unique(this.selectArr[0], 4);
            this.selectArr[0] = arr[0];
            this.errorArray = arr[1];
            zhu = this.selectArr[0].length * Cnm(this.customChoice, 4) * this.positionPlan;
            break;
          case 'ssc_rx4_zx24'://任选四(组选24)
          case 'ffc_rx4_zx24':
            count = this.selectArr[0].length < 4 ? 0 : Cnm(this.selectArr[0].length, 4);
            zhu = count * Cnm(this.customChoice, 4) * this.positionPlan;
            break;
          case 'ssc_rx4_zx12'://任选四(组选12)
          case 'ffc_rx4_zx12':
            groupSelect(this.selectArr[0], this.selectArr[1], 1, 2, function () {
              count -= Cnm(inter, 1) * Cnm(_this.selectArr[1].length - 1, 1);
            });
            zhu = count * Cnm(this.customChoice, 4) * this.positionPlan;
            break;
          case 'ssc_rx4_zx6'://任选四(组选6)
          case 'ffc_rx4_zx6':
            count = this.selectArr[0].length < 2 ? 0 : Cnm(this.selectArr[0].length, 2);
            zhu = count * Cnm(this.customChoice, 4) * this.positionPlan;
            break;
          case 'ssc_rx4_zx4'://任选四(组选4)
          case 'ffc_rx4_zx4':
            groupSelect(this.selectArr[0], this.selectArr[1], 1, 1, function () {
              count -= Cnm(inter, 1);
            });
            zhu = count * Cnm(this.customChoice, 4) * this.positionPlan;
            break;
          //------------------11选5 -----------------//
          case '11x5_qs_zxfs'://前三,中三,后三(直选复式)-11选五
          case '11x5_zs_zxfs':
          case '11x5_hs_zxfs':
            for (i = 0; i < this.selectArr[0].length; i++) {
              for (j = 0; j < this.selectArr[1].length; j++) {
                for (k = 0; k < this.selectArr[2].length; k++) {
                  if (this.selectArr[0][i] != this.selectArr[1][j] && this.selectArr[0][i] != this.selectArr[2][k] && this.selectArr[1][j] != this.selectArr[2][k]) {
                    zhu++;
                  }
                }
              }
            }
            break;
          case '11x5_qs_zxds'://前三,中三,后三(直选单式)-11选五
          case '11x5_zs_zxds':
          case '11x5_hs_zxds':
            arr = unique11X5ZhiXuan(this.selectArr[0], 6);
            this.selectArr[0] = arr[0];
            this.errorArray = arr[1];
            zhu = this.selectArr[0].length;
            break;
          case '11x5_qs_zuxfs'://前三,中三,后三(组选复式)-11选五
          case '11x5_zs_zuxfs':
          case '11x5_hs_zuxfs':
            zhu = Cnm(this.selectArr[0].length, 3);
            break;
          case '11x5_qs_zuxds'://前三,中三,后三(组选单式)-11选五
          case '11x5_zs_zuxds':
          case '11x5_hs_zuxds':
            arr = unique11X5ZuXuan(this.selectArr[0], 6);
            this.selectArr[0] = arr[0];
            this.errorArray = arr[1];
            zhu = this.selectArr[0].length;
            break;
          case '11x5_qs_zxdt'://前三,中三,后三(组选胆拖)-11选五
          case '11x5_zs_zxdt':
          case '11x5_hs_zxdt':
            let danlen = this.selectArr[0].length;
            let tuolen = this.selectArr[1].length;
            if (danlen < 1 || tuolen < 1 || danlen >= 3) {
              zhu = 0;
            } else {
              zhu = Cnm(tuolen, 3 - danlen);
            }
            break;
          case '11x5_qe_zxfs'://前二,后二(直选复式)-11选五
          case '11x5_he_zxfs':
            for (i = 0; i < this.selectArr[0].length; i++) {
              for (j = 0; j < this.selectArr[1].length; j++) {
                if (this.selectArr[0][i] != this.selectArr[1][j]) {
                  zhu++;
                }
              }
            }
            break;
          case '11x5_qe_zxds'://前二,后二(直选单式)-11选五
          case '11x5_he_zxds':
            arr = unique11X5ZhiXuan(this.selectArr[0], 4);
            this.selectArr[0] = arr[0];
            this.errorArray = arr[1];
            zhu = this.selectArr[0].length;
            break;
          case '11x5_qe_zuxfs'://前二,后二(组选复式)-11选五
          case '11x5_he_zuxfs':
          case 'ffc_he_zxze':
          case 'ssc_he_zxze':
          case 'ssc_qe_zxze':
          case 'ffc_qe_zxze':
            zhu = Cnm(this.selectArr[0].length, 2);
            break;
          case '11x5_qe_zuxds'://前二,后二(组选单式)-11选五
          case '11x5_he_zuxds':
            arr = unique11X5ZuXuan(this.selectArr[0], 4);
            this.selectArr[0] = arr[0];
            this.errorArray = arr[1];
            zhu = this.selectArr[0].length;
            break;
          case '11x5_qe_zxdt'://前二,后二(组选胆拖)-11选五
          case '11x5_he_zxdt':
            let tempDanlen = this.selectArr[0].length;
            let tempTuolen = this.selectArr[1].length;
            if (tempDanlen < 1 || tempTuolen < 1 || tempDanlen >= 2) {
              zhu = 0;
            } else {
              zhu = Cnm(tempTuolen, 2 - tempDanlen);
            }
            break;
          case '11x5_rxfs_rxyzy': //任选复式 (任选一中一)-11选五
            if (this.selectArr[0].length < 1) return 0;
            zhu = Cnm(this.selectArr[0].length, 1);
            break;
          case '11x5_rxfs_rxeze'://任选复式(任选二中二)-11选五
            if (this.selectArr[0].length < 2) return 0;
            zhu = Cnm(this.selectArr[0].length, 2);
            break;
          case '11x5_rxfs_rxszs'://任选复式(任选三中三)-11选五
            if (this.selectArr[0].length < 3) return 0;
            zhu = Cnm(this.selectArr[0].length, 3);
            break;
          case '11x5_rxfs_rxsizsi'://任选复式(任选四中四)-11选五
            if (this.selectArr[0].length < 4) return 0;
            zhu = Cnm(this.selectArr[0].length, 4);
            break;
          case '11x5_rxfs_rxwzw'://任选复式(任选五中五)-11选五
            if (this.selectArr[0].length < 5) return 0;
            zhu = Cnm(this.selectArr[0].length, 5);
            break;
          case '11x5_rxfs_rxlzw'://任选复式(任选六中五)-11选五
            if (this.selectArr[0].length < 6) return 0;
            zhu = Cnm(this.selectArr[0].length, 6);
            break;
          case '11x5_rxfs_rxqzw'://任选复式(任选七中五)-11选五
            if (this.selectArr[0].length < 7) return 0;
            zhu = Cnm(this.selectArr[0].length, 7);
            break;
          case '11x5_rxfs_rxbzw'://任选复式(任选八中五)-11选五
            if (this.selectArr[0].length < 8) return 0;
            zhu = Cnm(this.selectArr[0].length, 8);
            break;
          case '11x5_rxds_rxyzy'://任选单式(任选一中一)-11选五
            arr = unique11X5ZuXuan(this.selectArr[0], 2);
            this.selectArr[0] = arr[0];
            this.errorArray = arr[1];
            zhu = this.selectArr[0].length;
            break;
          case '11x5_rxds_rxeze'://任选单式(任选二中二)-11选五
            arr = unique11X5ZuXuan(this.selectArr[0], 4);
            this.selectArr[0] = arr[0];
            this.errorArray = arr[1];
            zhu = this.selectArr[0].length;
            break;
          case '11x5_rxds_rxszs'://任选单式(任选三中三)-11选五
            arr = unique11X5ZuXuan(this.selectArr[0], 6);
            this.selectArr[0] = arr[0];
            this.errorArray = arr[1];
            zhu = this.selectArr[0].length;
            break;
          case '11x5_rxds_rxsizsi'://任选单式(任选四中四)-11选五
            arr = unique11X5ZuXuan(this.selectArr[0], 8);
            this.selectArr[0] = arr[0];
            this.errorArray = arr[1];
            zhu = this.selectArr[0].length;
            break;
          case '11x5_rxds_rxwzw'://任选单式(任选五中五)-11选五
            arr = unique11X5ZuXuan(this.selectArr[0], 10);
            this.selectArr[0] = arr[0];
            this.errorArray = arr[1];
            zhu = this.selectArr[0].length;
            break;
          case '11x5_rxds_rxlzw'://任选单式(任选六中五)-11选五
            arr = unique11X5ZuXuan(selectArr[0], 12);
            this.selectArr[0] = arr[0];
            this.errorArray = arr[1];
            zhu = this.selectArr[0].length;
            break;
          case '11x5_rxds_rxqzw'://任选单式(任选七中五)-11选五
            arr = unique11X5ZuXuan(this.selectArr[0], 14);
            this.selectArr[0] = arr[0];
            this.errorArray = arr[1];
            zhu = this.selectArr[0].length;
            break;
          case '11x5_rxds_rxbzw'://任选单式(任选八中五)-11选五
            arr = unique11X5ZuXuan(this.selectArr[0], 16);
            this.selectArr[0] = arr[0];
            this.errorArray = arr[1];
            zhu = this.selectArr[0].length;
            break;
          case '11x5_bdwd_qsbdwd'://不定位胆(前三不定位胆,中三不定位胆,后三不定位胆)-11选五
          case '11x5_bdwd_zsbdwd':
          case '11x5_bdwd_hsbdwd':
            zhu = this.selectArr[0].length;
            break;
          case '11x5_dwd_wxdwd'://定位胆(五星定位胆)-11选五
            arr = new Array(this.selectArr[0], this.selectArr[1], this.selectArr[2], this.selectArr[3], this.selectArr[4]);
            for (index in arr) {
              zhu = zhu + arr[index].length;
            }
            break;
          // ------------------福彩3D,排列三 -----------------//
          case '3d/p3_sx_zxfs'://三星(直选复式)-福彩3D,排列三
            zhu = this.selectArr[0].length * this.selectArr[1].length * this.selectArr[2].length;
            break;
          case '3d/p3_sx_zxds'://三星(直选单式)-福彩3D,排列三
            arr = unique(this.selectArr[0], 3);
            this.selectArr[0] = arr[0];
            this.errorArray = arr[1];
            zhu = this.selectArr[0].length;
            break;
          case '3d/p3_sx_zxzl'://三星(组选组六)-福彩3D,排列三
            zhu = Cnm(this.selectArr[0].length, 3);
            break;
          case '3d/p3_sx_zxzs'://三星(组选组三)-福彩3D,排列三
            zhu = this.selectArr[0].length * (this.selectArr[0].length - 1);
            break;
          case '3d/p3_sx_zxhh'://三星(组选混合)-福彩3D,排列三
            arr = uniqueCnm(this.selectArr[0], 3);
            this.selectArr[0] = arr[0];
            this.errorArray = arr[1];
            zhu = this.selectArr[0].length;
            break;
          case '3d/p3_qe_zxfs'://前二,后二(直选复式)-福彩3D,排列三
          case '3d/p3_he_zxfs':
          case 'ssc_dxds_qe':
          case 'ssc_dxds_he':
            zhu = this.selectArr[0].length * this.selectArr[1].length;
            break;
          case '3d/p3_qe_zxds'://前二,后二(直选单式)-福彩3D,排列三
          case '3d/p3_he_zxds':
            arr = unique(this.selectArr[0], 2);
            this.selectArr[0] = arr[0];
            this.errorArray = arr[1];
            zhu = this.selectArr[0].length;
            break;
          case '3d/p3_qe_zxze'://前二,后二(组选组二)-福彩3D,排列三
          case '3d/p3_he_zxze':
            zhu = Cnm(this.selectArr[0].length, 2);
            break;
          case '3d/p3_qe_zxhh'://前二,后二(组选混合)-福彩3D,排列三
          case '3d/p3_he_zxhh':
            arr = uniqueCnm(this.selectArr[0], 2);
            this.selectArr[0] = arr[0];
            this.errorArray = arr[1];
            zhu = this.selectArr[0].length;
            break;
          case '3d/p3_dwd_dwd'://定位胆(三星定位胆)-福彩3D,排列三
            arr = new Array(this.selectArr[0], this.selectArr[1], this.selectArr[2]);
            for (index in arr) {
              zhu += arr[index].length;
            }
            break;
          case '3d/p3_bdwd_ymbdwd'://不定位胆(二码不定位胆)-福彩3D,排列三
            if (this.selectArr[0].length >= 2) {
              zhu = this.selectArr[0].length * (this.selectArr[0].length - 1) / 2;
            }
            break;
          case '3d/p3_bdwd_embdwd'://不定位胆(一码不定位胆)-福彩3D,排列三
            zhu = this.selectArr[0].length;
            break;
          // ------------------北京快乐8-----------------//
          case 'klc_rx_rx1'://任选(任选一)-北京快乐8
            zhu = Cnm(this.selectArr[0].length, 1);
            break;
          case 'klc_rx_rx2'://任选(任选二)-北京快乐8
            if (this.selectArr[0].length >= 2) {
              zhu = Cnm(this.selectArr[0].length, 2);
            }
            break;
          case 'klc_rx_rx3'://任选(任选三)-北京快乐8
            if (this.selectArr[0].length >= 3) {
              zhu = Cnm(this.selectArr[0].length, 3);
            }
            break;
          case 'klc_rx_rx4'://任选(任选四)-北京快乐8
            if (this.selectArr[0].length >= 4) {
              zhu = Cnm(this.selectArr[0].length, 4);
            }
            break;
          case 'klc_rx_rx5'://任选(任选五)-北京快乐8
            if (this.selectArr[0].length >= 5) {
              zhu = Cnm(this.selectArr[0].length, 5);
            }
            break;
          case 'klc_rx_rx6'://任选(任选六)-北京快乐8
            if (this.selectArr[0].length >= 6) {
              zhu = Cnm(this.selectArr[0].length, 6);
            }
            break;
          case 'klc_rx_rx7'://任选(任选七)-北京快乐8
            if (this.selectArr[0].length >= 7) {
              zhu = Cnm(this.selectArr[0].length, 7);
            }
            break;
          case 'klc_qw_sxp'://趣味(上下盘,奇偶盘,和值大小单双)-北京快乐8
          case 'klc_qw_jop':
          case 'klc_qw_hzdxds':
            zhu = this.selectArr[0].length;
            break;
          // --------------- PK10  -----------//
          case 'pk10_qy_zxfs'://前一(直选复式)-PK10
            zhu = this.selectArr[0].length;
            break;
          case 'pk10_qe_zxfs'://前二(直选复式)-PK10
            for (i = 0; i < this.selectArr[0].length; i++) {
              for (j = 0; j < this.selectArr[1].length; j++) {
                if (this.selectArr[0][i] !== this.selectArr[1][j]) {
                  zhu++;
                }
              }
            }
            break;
          case 'pk10_qe_zxds'://前二(直选单式)-PK10
            arr = uniquePK10(this.selectArr[0], 4);
            this.selectArr[0] = arr[0];
            this.errorArray = arr[1];
            zhu = this.selectArr[0].length;
            break;
          case 'pk10_qs_zxfs'://前三(直选复式)-PK10
            for (i = 0; i < this.selectArr[0].length; i++) {
              for (j = 0; j < this.selectArr[1].length; j++) {
                for (k = 0; k < this.selectArr[2].length; k++) {
                  if (this.selectArr[0][i] !== this.selectArr[1][j] && this.selectArr[0][i] !== this.selectArr[2][k] && this.selectArr[1][j] !== this.selectArr[2][k]) {
                    zhu++;
                  }
                }
              }
            }
            break;
          case 'pk10_qs_zxds'://前三(直选单式)-PK10
            arr = uniquePK10(this.selectArr[0], 6);
            this.selectArr[0] = arr[0];
            this.errorArray = arr[1];
            zhu = this.selectArr[0].length;
            break;
          case 'pk10_dwd_wxdwd'://定位胆(定位胆)-PK10
            for (index in this.selectArr) {
              zhu += this.selectArr[index].length;
            }
            break;
          default:
            console.log(`code:${playDetailCode} mapping function is not found`);
        }
        return zhu;
      }
    },
    watch: {
      $route (to, from) {
        if (to.path !== from.path) {
          let _this = this;
          let obj = {
            typeId: _this.$route.params.typeId,
            groupId: _this.$route.params.groupId,
            gameId: _this.$route.params.gameId,
            gameName: _this.$route.params.gameName
          };
          _this.resetSelectBalls();
          _this.resetBetCount();
          _this.init(obj);
        }
      }
    }
  }
</script>
