<template>
  <div class="menuMod">
    <ul>
      <li v-for="item in playTypeList" @click="handleOnChange(item.id)" class="ripple red_ripple"
          :class="{cur:item.id==playId}">{{item.ruleMasterName}}
      </li>
    </ul>
  </div>
</template>
<script>
  function noop() {
  }
  export default {
    name: 'PlayNavBar',
    components: {},
    props: {
      playId: {
        type: [String, Number]
      },
      playTypeList: {
        type: Array,
        default: function () {
          return [];
        }
      },
      onChange: {
        type: Function,
        default: noop
      }
    },
    data(){
      return {}
    },
    methods: {
      handleOnChange: function (playId) {
        this.onChange(playId);
      }
    }
  }
</script>
