<template>
  <div class="total">
    <div class="money-units pull-left">
      <a v-for="(item,index) in scaleList" class="ripple red_ripple" :class="{ active: item.value==caiScale }"
         @click="scaleSel(item.text,item.value)">{{item.text}}</a>
    </div>
    <div class="input-group spinner pull-left cf">
      <div class="input-group-addon ripple red_ripple" @click=cutMultiple>-</div>
      <input type="text" class="form-control" v-model="caiMultiple" @change=multipleSw maxlength="5">
      <div class="input-group-addon ripple red_ripple" @click=addMultiple>+</div>
    </div>
    <div class="total-word pull-left">
      倍
    </div>
    <div class="total-word pull-left margin1em-left">
      奖金/返点：<span class="user_rebate">{{userRebate}}</span>
    </div>
    <div class="fandian pull-left">
      <el-select v-model="userRebate" class="form-control selectpicker bs-select-hidden">
        <el-option v-for="option in rebateList" :key="option.value" :label="option.text" :value="option.value"></el-option>
      </el-select>
    </div>
    <div class="total-word pull-left margin1em-left">
      已选 <span class="text-red">{{betAmount}}</span> 注
    </div>
    <div class="total-word pull-left margin1em-left">
      共 <span class="text-red">￥<i v-amount="betMoney"></i></span>
    </div>
    <div class="pull-right">
      <a v-if="betAmount>0&&isOpening" class="btn btn-red ripple" @click="bet(1)">直接投注</a>
      <a v-else class="btn btn-red btn_disabled ripple">直接投注</a>
    </div>
    <div class="pull-right">
      <a v-if="betAmount>0" class="btn btn-red-ling ripple" @click="addBet()">加入投注篮</a>
      <a v-else class="btn btn-red-ling btn_disabled ripple">加入投注篮</a>
    </div>
  </div>
</template>
<script>
  export default {
    name: 'BetTotal',
    components: {},
    props: {
      scaleList: {
        type: Array,
        default: function () {
          return [];
        }
      }
    },
    data(){
      return {
        caiScale: '',
        caiMultiple: 0,
        userRebate:0,
        rebateList:[],
        betAmount:0,
        betMoney:0,
        //开盘状态
        isOpening: true,
      }
    },
    methods: {
      scaleSel: function (name, caiScale) {

      },
      cutMultiple: function () {
        if (caiMultiple > 1) {
          this.caiMultiple--;
        }
      },
      addMultiple: function () {
        if (this.caiMultiple < 99999) {
          this.caiMultiple = this.caiMultiple / 1 + 1;
        }
      },
      bet:function () {

      },
      addBet:function () {

      }
    }
  }
</script>
