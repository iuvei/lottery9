<template>
  <div class="shuaixuan" style="min-height: 45px">
    <div v-for="(item,x) in betTypeList" class="xuan-item">
      <span>{{item.name}}：</span>
      <a @click="handleOnChange(detail.id,x,y)" v-for="(detail,y) in item.list" class="ripple red_ripple"
         :class="{active:detail.id==playDetailId}">{{detail.ruleMasterName}}</a>
    </div>
    <a class="bet_type_show" @click="handleOnClose()">收起</a>
  </div>
</template>
<script>
  function noop() {
  }
  export default {
    components: {},
    props: {
      betTypeList: {
        type: Array,
        default: function () {
          return [];
        }
      },
      playDetailId: {
        type: [String, Number]
      },
      onClose: {
        type: Function,
        default: noop
      },
      onChange: {
        type: Function,
        default: noop
      }
    },
    data(){
      return {}
    },
    methods: {
      handleOnChange: function (playDetailId, x, y) {
        this.onChange(playDetailId, x, y);
      },
      handleOnClose: function () {
        this.onClose();
      }
    }
  }
</script>
