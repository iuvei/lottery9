<template>
  <div>跳转中,请稍后...</div>
</template>
<script>
  import {setToken, setResource} from  '../utils/auth'
  export default {
    name: 'Redirect',
    data () {
      return {}
    },
    methods: {
      validation: function (option) {
        const {token, groupCode, gameCode, resource} = option;
        console.log(`【system】:validation...`);
        this.$store.dispatch('LoadInfoByToken', token).then(() => {
          console.log(`【system】:validation success!start redirect...`);
          setToken(token);
          setResource(resource);
          this.redirect(groupCode, gameCode);
        }).catch(err => {

        });
      },
      redirect: function (RGroupCode, RGameCode) {
        console.log(`【system】:start get menus...`);
        this.$store.dispatch('LoadingMenus').then(result => {
          console.log(`【system】:get menus success...`);
          const _this = this;
          let flag = false;
          if (result && result.length > 0) {
            console.log(`【system】:start match menus,params:RGroupCode:${RGroupCode},RGameCode:${RGameCode}...`);
            for (let x = 0; x < result.length; x++) {
              const {typeId, typeCode, children} = result[x];
              if (typeCode === RGroupCode && children && children instanceof Array) {
                for (let y = 0; y < children.length; y++) {
                  const {gameId, gameCode, gameName} = children[y];
                  if (gameCode === RGameCode) {
                    flag = true;
                    console.log(`【system】:match menus success,start redirect page,params:typeId:${typeId},typeCode:${typeCode},gameId:${gameId},gameCode:${gameCode},gameName:${gameName}...`);
                    _this.$router.push({
                      name: 'lotteryKgList',
                      params: {
                        typeId: typeId,
                        typeCode: typeCode,
                        gameId: gameId,
                        gameCode: gameCode,
                        gameName: gameName
                      }
                    });
                    break;
                  }
                }
                break;
              }
            }
            if (!flag) {
              _this.$router.push({path: '/'});
            }
          } else {
            console.log(`【error】:menus is null...`);
          }
        }).catch(err => {
          this.$message.error(err);
        });
      }
    },
    beforeRouteEnter(to, from, next){
      console.log(`【system】:from.path:${from.path}`)
      if (!from.path)  return false;
      next(vm => {
        console.log(`【system】:redirect...`);
        vm.validation(to.params)
      });
    },
  }
</script>
