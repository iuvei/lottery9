const getters = {
  userName: state => state.user.userName,
  account: state => state.user.account,
  balance: state => state.user.balance,
  userId: state => state.user.userId,
  isOnline: state => state.user.isOnline,
  proxyId: state => state.user.proxyId,
  lotteryKgMenus: state => state.user.lotteryKgMenus,
  integrationArr: state => state.lottery.integrationArr,
  betRecordsNotList: state => state.lottery.gameBetNotOpen,
  betRecordsByList: state => state.lottery.gameBetAlreadyOpen
};
export default getters
