import {login, getUserBalance, loginOut, getUserInfoByToken}from '../../api/user'
import {setToken, removeToken, getToken, getMenus, setMenus, removeMenus}from'../../utils/auth'
import {getGameList}from '../../api/app'
import {isDouble} from '../../utils/index'
const header = {
  state: {
    userId: '',
    userName: '',
    account: '',
    status: '',
    token: '',
    proxyId: '',
    balance: 0,
    isOnline: false,
    lotteryKgMenus: []
  },
  mutations: {
    setProxyId: (state, proxyId) => {
      state.proxyId = proxyId
    },
    setUserId: (state, userId) => {
      state.userId = userId
    },
    setUserName: (state, userName) => {
      state.userName = userName
    },
    setAccount: (state, account) => {
      state.account = account
    },
    setStatus: (state, status) => {
      state.status = status
    },
    setToken: (state, token) => {
      state.token = token
    },
    setBalance: (state, amount) => {
      state.balance = amount
    },
    setIsOnlin: (state, isOnlin) => {
      state.isOnline = isOnlin
    },
    setLotteryMenus: (state, menus) => {
      state.lotteryKgMenus = menus
    }
  },
  actions: {
    LoadingMenus: ({commit}) => {
      return new Promise((resolve, reject) => {
        getGameList().then(res => {
          const {currentStatus, currentData} = res;
          if (currentStatus === 0) {
            commit('setLotteryMenus', currentData);
            setMenus(currentData);
            resolve(currentData)
          } else {
            reject(false)
          }
        }).catch(() => {
          reject(false)
        });
      });
    },
    LoginByAccount: ({commit}, loginInfo) => {
      return new Promise((resolve, reject) => {
        login(loginInfo).then(res => {
          if (res.currentStatus === 0) {
            const {token, userContext} = res.currentData;
            const {id, userAccount, userAmount, parentProxyId} = userContext;
            commit('setToken', token);
            commit('setAccount', userAccount);
            commit('setBalance', userAmount);
            commit('setUserId', id);
            commit('setProxyId', parentProxyId);
            commit('setIsOnlin', true);
            setToken(token);
            resolve();
          } else {
            reject(res);
          }
        }).catch(error => {
          reject(error);
        });
      });
    },
    LoadUserBalance: ({commit}, userId) => {
      return new Promise((resolve, reject) => {
        const info = {proxyGameUserId: userId};
        getUserBalance(info).then(res => {
          if (res.currentStatus === 0) {
            commit('setBalance', isDouble(res.currentData) ? res.currentData : 0);
            resolve()
          } else {
            reject(res)
          }
        }).catch(error => {
          reject(error)
        });
      });
    },
    LoginOut: ({commit}) => {
      return new Promise((resolve, reject) => {
        commit('setToken', '');
        commit('setAccount', '');
        commit('setBalance', 0);
        commit('setUserId', '');
        commit('setProxyId', '');
        commit('setIsOnlin', false);
        commit('setLotteryMenus', []);
        removeToken();
        removeMenus();
        resolve();
      });
    },
    LoadInfoByToken: function ({commit}, token) {
      return new Promise((resolve, reject) => {
        getUserInfoByToken({token: token}).then(res => {
          const {currentStatus, currentData} = res;
          if (currentStatus === 0 && currentData.userContext) {
            const {id, userAccount, parentProxyId} = currentData.userContext;
            commit('setToken', token);
            commit('setAccount', userAccount);
            commit('setBalance', 0);
            commit('setUserId', id);
            commit('setProxyId', parentProxyId);
            commit('setIsOnlin', true);
            commit('setLotteryMenus', getMenus());
            resolve();
          } else {
            reject(res)
          }
        }).catch(error => {
          reject(error)
        });
      });
    }
  }
};

export default header;
