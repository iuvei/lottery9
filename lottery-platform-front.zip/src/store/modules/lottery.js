import {queryGameBetRightList, queryAlreadySettledList} from '../../api/lotteryKg'
const lottery = {
  state: {
    integrationArr: Array(14 * 5),
    gameBetNotOpen: {
      total: 0,
      list: []
    },
    gameBetAlreadyOpen: {
      total: 0,
      list: []
    }
  },
  mutations: {
    set_IntegrationArr: (state, arr) => {
      state.integrationArr = arr
    },
    gameBetNotOpen: (state, param) => {
      state.gameBetNotOpen = param
    },
    gameBetAlreadyOpen: (state, param) => {
      state.gameBetAlreadyOpen = param
    }
  },
  actions: {
    setIntegrationArr: ({commit}, arr) => {
      commit('set_IntegrationArr', arr);
    },
    queryGameBet: ({commit}, param) => {
      queryGameBetRightList(param).then(res => {
        const {currentStatus, currentData} = res;
        if (currentStatus === 0 && currentData) {
          const {list, total} = currentData;
          commit('gameBetNotOpen', {list, total});
        }
      }).catch(error => {
        console.error(`【error】:${error}`)
      })
      queryAlreadySettledList(param).then(res => {
        const {currentStatus, currentData} = res;
        if (currentStatus === 0 && currentData) {
          const {list, total} = currentData;
          commit('gameBetAlreadyOpen', {list, total});
        }
      }).catch(error => {
        console.error(`【error】:${error}`)
      })
    }

  }
};

export default lottery;
