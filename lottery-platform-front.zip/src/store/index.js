import Vue from 'vue';
import Vuex from 'vuex';
import user from './modules/user';
import lottery from './modules/lottery';
import getters from './getters';

Vue.use(Vuex);

const store = new Vuex.Store({
  modules: {
    user,
    lottery
  },
  getters
});

export default store
