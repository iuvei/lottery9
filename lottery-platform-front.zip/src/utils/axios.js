import axios from 'axios';
import {Message} from 'element-ui'
import store from '../store';
import {assembleParam} from '../utils/auth'

const service = axios.create({
  baseURL: process.env.BASE_API,
  timeout: 600000,
  headers: {
    post: {
      "Content-Type": "application/json"
    }
  }
});

function isJsonObject(obj) {
  return typeof(obj) === "object" && Object.prototype.toString.call(obj).toLowerCase() === "[object object]" && !obj.length;
}

service.interceptors.request.use(config => {
  config.data = assembleParam(config.url.replace(config.baseURL, ''), config.data);
  return config;
}, error => {
  console.log('request err:' + error);// for debug
  Promise.reject(error);
});

service.interceptors.response.use(
  response => {
    const resJsonData = !isJsonObject(response.data) ? JSON.parse(response.data) : response.data,
      {currentStatus, errorInformation} = resJsonData;
    if (currentStatus === 2 && errorInformation.errCode === '非法用户访问') {
      Message({
        message: "登录失效....",
        type: 'error',
        duration: 5 * 1000,
        onClose: function () {
          store.dispatch('LoginOut').then(() => {
            location.reload();
          });
        }
      });
    }
    return resJsonData;
  },
  error => {
    Message({
      message: "服务器繁忙...",
      type: 'error',
      duration: 5 * 1000
    });
    return Promise.reject('服务器繁忙...');
  }
);

export default service;
