const menusKey = '__whh_menus__';
const tokenKey = '__whh_token__';
const resourceKey = '__whh_resource__';

export function getToken() {
  return localStorage.getItem(tokenKey);
}

export function setToken(token) {
  return localStorage.setItem(tokenKey, token)
}

export function removeToken() {
  return localStorage.removeItem(tokenKey)
}

export function setResource(resource) {
  return localStorage.setItem(resourceKey, resource);
}

export function getResource() {
  return localStorage.getItem(resourceKey);
}

export function removeResource() {
  return localStorage.removeItem(resourceKey);
}

export function getMenus() {
  return JSON.parse(localStorage.getItem(menusKey));
}

export function setMenus(menus) {
  return localStorage.setItem(menusKey, JSON.stringify(menus))
}

export function removeMenus() {
  return localStorage.removeItem(menusKey)
}

export function assembleParam(url, param) {
  return {
    uri: url,
    token: getToken(),
    paramData: param
  }
}
