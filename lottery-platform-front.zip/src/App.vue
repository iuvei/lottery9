<template>
  <div id="app">
    <transition name="fade" mode="out-in" appear>
      <router-view></router-view>
    </transition>

    <transition name="fade" mode="out-in" appear>
      <div class="load_in" v-if="loadMask">
        <div class="load_animation"></div>
      </div>
    </transition>
  </div>
</template>

<script>
  import "../static/assets/css/common.css"
  /*import "../static/assets/css/index.css"*/
  import "../static/assets/css/lottery.css"
  import "../static/assets/css/user.css"
  import {getGameList, removeGameUserCurrentToken}from './api/app'
  import {getMenus, setMenus}from './utils/auth'
  import {mapGetters, mapActions} from 'vuex'
  export default {
    name: 'app',
    data(){
      return {
        notOnline: false,
        //平台配置文件
        plantConfig: {},
        picture: [
          {imgName: 'banner_2', link: {name: "lottery", params: {gameId: 3, groupId: 1, gameName: "重庆时时彩"}}},
          {imgName: 'banner_1', link: {name: "lottery", params: {gameId: 3, groupId: 1, gameName: "重庆时时彩"}}},
          {imgName: 'banner_3', link: {name: "lottery", params: {gameId: 3, groupId: 1, gameName: "重庆时时彩"}}},
          {imgName: 'banner_4', link: {name: "lottery", params: {gameId: 3, groupId: 1, gameName: "重庆时时彩"}}}
        ],
        //是否显示遮罩
        loadMask: false,
        headHtmlShow: true,
        footHtmlShow: true,
        //验证码图片
        vCodes: "",
        //用户名
        userName: "",
        //绑定用户密码
        passwordTxt: "",
        //验证码
        codeText: "",
        loginBox: false,
        //Kg彩种列表
        lotteryKg: []
      }
    },
    methods: {
      ...mapActions([
        'setLotteryKgMenus'
      ]),
      //返回头部
      backTop: function () {
        $('body,html').animate({scrollTop: 0}, 500);
      },
      initConfig: function () {
        const _this = this, dev = 'PCNew';
        for (let item in configObj) {
          if (dev == item) {
            _this.plantConfig = configObj[item];
            document.title = '8号彩票';
            $.each(_this.picture, function (i, e) {
              e.url = _this.plantConfig.CAROUSEL_PATH + e.imgName + ".jpg";
            });
            break;
          }
        }
      },
      /*removeGameUserCurrentTokenFn(){
        removeGameUserCurrentToken().then(res => {

        }).catch(err => {

        })
      }*/
    },
    created(){
      /*window.onunload = () => {
        this.removeGameUserCurrentTokenFn()
      }*/
    },
    mounted(){
      $('#loadIn').remove();
      this.initConfig()
    }
  }

</script>
