import Vue from 'vue'
import App from './App.vue'
import router from './router';
import ElementUI from 'element-ui';
import store from './store';
import 'element-ui/lib/theme-default/index.css'
import {getToken, getMenus} from './utils/auth'
//开启debug模式
Vue.config.debug = true;
Vue.use(ElementUI);
//自定义金额格式化指令
Vue.directive('amount', {
  bind: function (el, binding, vnode, oldVnode) {
    var bit = binding.arg ? binding.arg : vnode.context.$root.$children[0].decimalCon ? vnode.context.$root.$children[0].decimalCon : 3;
    el.innerHTML = !isNaN(binding.value / 1) ? (binding.value / 1).toFixed(bit) : binding.value;
  },
  update: function (el, binding, vnode, oldVnode) {
    if (binding.oldValue != binding.value) {
      var bit = binding.arg ? binding.arg : vnode.context.$root.$children[0].decimalCon ? vnode.context.$root.$children[0].decimalCon : 3;
      el.innerHTML = !isNaN(binding.value / 1) ? (binding.value / 1).toFixed(bit) : binding.value;
    }
  }
});

const whiteList = ['/'];
router.beforeEach((to, from, next) => {
  if (to.path.indexOf('/redirect') !== -1 || to.path.indexOf('/login') !== -1) {
    next();
  } else {
    if (getToken()) {
      if (getMenus()) {
        if (store.getters.account === '') {
          store.dispatch('LoadInfoByToken', getToken()).then(() => {
            if( to.params.typeId ){
              next({
                name: 'lotteryKgList', params: {
                  typeId: to.params.typeId,
                  typeCode: to.params.typeCode,
                  gameId: to.params.gameId,
                  gameCode: to.params.gameCode,
                  gameName: to.params.gameName
                }
              });
            }else{
              next({});
            }
          }).catch(err => {
            console.log(`【error】:${err}`);
            store.dispatch('LoginOut').then(() => {
              next({path: '/'});
            });
          });
        } else {
          next();
        }
      } else {
        store.dispatch('LoginOut').then(() => {
          next({path: '/'});
        });
      }
    } else {
      if (whiteList.indexOf(to.path) !== -1) {
        next();
      } else {
        next({path: '/'});
      }
    }
  }
});

Date.prototype.Format = function (fmt) {
  let o = {
    "M+": this.getMonth() + 1, //月份
    "d+": this.getDate(), //日
    "h+": this.getHours(), //小时
    "m+": this.getMinutes(), //分
    "s+": this.getSeconds(), //秒
    "q+": Math.floor((this.getMonth() + 3) / 3), //季度
    "S": this.getMilliseconds() //毫秒
  };
  if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
  for (let k in o)
    if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
  return fmt;
};

new Vue({
  el: '#app',
  router: router,
  store: store,
  render: h => h(App)
});
