import httpRequest from '../utils/axios';

export function getLotteryPlays(data) {
  return httpRequest({
    url: '/task/lotteryGameKgController/LotteryGameInitData',
    method: 'post',
    data
  });
}

export function getMasterList(data) {
  return httpRequest({
    url: '/task/lotteryGameKgController/getMasterList',
    method: 'post',
    data
  });
}

export function getLotterysDraw(data) {
  return httpRequest({
    url: '/task/lotteryGameKgController/PcLoadKgGameResult',
    method: 'post',
    data
  });
}

export function getBetDetail(data) {
  return httpRequest({
    url: '/task/lotteryGameKgController/getBetInfo',
    method: 'post',
    data
  });
}



export function getLotteryDraw(data) {
  return httpRequest({
    url: '/task/lotteryGameKgController/getLotteryGameResult',
    method: 'post',
    data
  });
}

/**
 * 查询最近历史号码记录
 * @param data
 * @returns {*}
 */
export function getNumberHistory(data) {
  return httpRequest({
    url: '/task/lotteryGameKgController/getNumberHistory',
    method: 'post',
    data
  });
}

/**
 * 查询露珠走势
 * @param data
 * @returns {*}
 */
export function getDewdropList(data) {
  return httpRequest({
    url: '/task/lotteryGameKgController/getDewdropList',
    method: 'post',
    data
  });
}

/**
 * 游戏下注
 * @param data
 * @returns {*}
 */
export function lotteryBet(data) {
  return httpRequest({
    url: '/task/gameBetManger/lotteryBet',
    method: 'post',
    data
  });
}

/**
 * 未开奖号码
 * @returns {*}
 */
export function queryGameBetRightList(data) {
  return httpRequest({
    url: '/task/lotteryGameKgController/queryGameBetRightList',
    method: 'post',
    data
  });
}
/**
 * 已开奖号码
 * @param query
 * @returns {*}
 */
export function queryAlreadySettledList(data) {
  return httpRequest({
    url: '/task/lotteryGameKgController/queryAlreadySettledList',
    method: 'post',
    data
  });
}

export function getDataFromGameCode(data) {
  return httpRequest({
    url: '/task/lotteryGameKgController/queryOddsByCode',
    method: 'post',
    data
  });
}