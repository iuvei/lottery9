import httpRequest from '../utils/axios';

export function getUserBetRecord(query) {
  return httpRequest({
    url: '/game/userManager/userBetRecord',
    method: 'post',
    data: query
  });
}
/*查询列表*/
export function getUserGameBetInfo(query) {
  return httpRequest({
    url: '/task/lotteryGameKgController/getUserGameBetInfo',
    method: 'post',
    data: query
  });
}
/*查询彩种*/
export function getUserGameList() {
  return httpRequest({
    url: '/task/lotteryGameKgController/getUserGameList',
    method: 'post',
  });
}
/*选择游戏加载顶层玩法*/
export function getUserMasterTop(query) {
  return httpRequest({
    url: '/task/lotteryGameKgController/getUserMasterTop',
    method: 'post',
    data:query
  });
}
/*选择顶层玩法加载下层玩法*/
export function getUserMasterList(query) {
  return httpRequest({
    url: '/task/lotteryGameKgController/getUserMasterList',
    method: 'post',
    data:query
  });
}
