import httpRequest from '../utils/axios';

export function login(params) {
  return httpRequest({
    url: '/game/userManager/gameUserLogin',
    method: 'post',
    data:params
  });
}

export function getUserBalance(params) {
  return httpRequest({
    url: '/game/userManager/userAmount',
    method: 'post',
    data:params
  });
}

export function loginOut(params) {
  return httpRequest({
    url: '/game/userManager/loginOut',
    method: 'post',
    data:params
  });
}

export function getUserInfoByToken(params) {
  return httpRequest({
    url: '/game/userManager/getUserInfoByToken',
    method: 'post',
    data:params
  });
}

