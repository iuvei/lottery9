import httpRequest from '../utils/axios';

export function getGameList() {
  return httpRequest({
    url: '/task/lotteryGameKgController/getGameList',
    method: 'post'
  });
}
/*export function removeGameUserCurrentToken(data) {
  return httpRequest({
    url: '/admin/proxyGameUserManager/removeGameUserCurrentToken',
    method: 'post',
    data
  });
}*/


