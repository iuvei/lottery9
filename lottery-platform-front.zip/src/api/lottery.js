import httpRequest from '../utils/axios';

export function getGameOneResult(query) {
  return httpRequest({
    url: '/task/lotteryGameKgController/getGameOneResult',
    method: 'post',
    data: query
  });
}

export function getLotteryDraw(query) {
  return httpRequest({
    url: '/task/lotteryGameKgController/getLotteryGameResult',
    method: 'post',
    data: query
  });
}

/**
 * 获取用户url信息，根据token获取
 * @returns {*}
 */
export function getUrlByToken (data) {
  return httpRequest({
    url: '/task/lotteryGameKgController/getUrlByToken',
    method: 'post',
    data
  })
}
