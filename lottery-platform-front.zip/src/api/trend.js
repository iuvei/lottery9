import httpRequest from '../utils/axios';

export function getChartList(query) {
  return httpRequest({
    url: '/task/lotteryGameKgController/getChartList',
    method: 'post',
    data: query
  });
}

