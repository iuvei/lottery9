import Vue from 'vue'
import Router from 'vue-router'
const _import = require('./_import_' + process.env.NODE_ENV)
Vue.use(Router);

const routes = [
  {path: '/', component: _import('components/content')},
  {path: '/login/:token/:resource', name: 'login', component: _import('components/login')},
  {
    path: '/redirect/:groupCode/:gameCode/:token/:resource',
    name: 'redirect',
    component: _import('components/redirect')
  },
  {
    path: '/lotteryLayout/:typeId/group/:groupId/game/:gameId/name/:gameName',
    name: 'lotteryLayout',
    component: _import('components/lottery/lottery/index')
  },
  {
    path: '/lotteryKgList/:typeId/:typeCode/:gameId/:gameCode/:gameName',
    name: 'lotteryKgList',
    component: _import('components/lottery/kg/index')
  },
  {
    path: '/betRecord',
    name: 'betRecord',
    component: _import('components/lottery/kg/betRecord/betRecord')
  }
];

export default new Router({
  routes
})
