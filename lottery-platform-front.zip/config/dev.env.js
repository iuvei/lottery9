/*var merge = require('webpack-merge')
var prodEnv = require('./prod.env')

module.exports = merge(prodEnv, {
  NODE_ENV: '"development"'
})*/

module.exports = {
  NODE_ENV: '"development"',
  ENV_CONFIG: '"dev"',
  // BASE_API: '"http://169.56.12.110:9399"'
  //BASE_API: '"http://169.56.12.76:9999"'
  //BASE_API: '"http://172.16.28.31:9999"'
  //BASE_API: '"http://172.16.1.67:9999"'
  // BASE_API: '"http://172.16.28.63:9999"'
  BASE_API: '"http://169.56.12.110:9999"'
}

