/*module.exports = {
  NODE_ENV: '"production"'
}*/
module.exports = {
  NODE_ENV: '"production"',
  ENV_CONFIG: '"prod"',
  BASE_API: '"http://169.56.12.110:9999"'
  //BASE_API: '"http://169.56.12.76:9999"'
};
